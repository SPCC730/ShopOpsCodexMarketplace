from __future__ import annotations

from datetime import UTC, datetime
from dataclasses import replace
import hashlib
import json
import sqlite3
import sys
from pathlib import Path
from types import SimpleNamespace
from uuid import UUID, uuid4

from shopops_reporter.config import IdentityStore, ProjectConfig, reporter_home
from shopops_reporter.client import ReporterClient
from shopops_reporter.onboarding.discovery import checked_scope, digest, discover
from shopops_reporter.task_context import TaskContext, atomic_json, confined_path, file_lock, read_json
from shopops_reporter.result_mapping import load_result_contract
from shopops_reporter.project import project_fingerprint


def now():
    return datetime.now(UTC).isoformat()


def state_path(session_id: str) -> Path:
    if str(UUID(session_id)) != session_id:
        raise ValueError('onboarding_session_invalid')
    return confined_path(reporter_home(), f'onboarding/{session_id}.json')


def load(session_id: str) -> dict:
    value = read_json(state_path(session_id))
    if (not isinstance(value, dict) or value.get('version') != 1
            or value.get('session_id') != session_id or not isinstance(value.get('tasks'), list)):
        raise ValueError('onboarding_state_invalid_preserve_for_recovery')
    return value


def save(state):
    atomic_json(state_path(state['session_id']), state)


def task_in(state, task_key):
    found = next((item for item in state['tasks'] if item['task_key'] == task_key), None)
    if found is None:
        raise ValueError('onboarding_task_not_in_confirmed_selection')
    return found


def context_of(task):
    return TaskContext(Path(task['root']), None if task['task_key'] == 'default' else task['task_key'])


def prepare(scope: Path, selection: dict, *, scope_digest: str, experienced=False) -> dict:
    observed = discover(scope)
    if observed['scope_kind'] != 'directory':
        raise ValueError('confirm_project_directory_before_preparation')
    if observed['digest'] != scope_digest or observed['limited']:
        raise ValueError('discovery_changed_or_incomplete_preview_again')
    if (not isinstance(selection, dict) or set(selection) != {'tasks'}
            or not isinstance(selection['tasks'], list) or not 1 <= len(selection['tasks']) <= 100):
        raise ValueError('onboarding_selection_invalid')
    paths = {item['path'] for item in observed['files']}
    tasks, seen, selected_keys = [], set(), set()
    for item in selection['tasks']:
        if not isinstance(item, dict) or set(item) - {'entry', 'variant', 'task_key'}:
            raise ValueError('onboarding_selection_invalid')
        entry, variant = item.get('entry'), item.get('variant', '')
        if entry not in paths or not isinstance(variant, str) or len(variant) > 80:
            raise ValueError('onboarding_entry_outside_confirmed_scope')
        if any(not (c.isalnum() or c in '._-') for c in variant) or (entry, variant) in seen:
            raise ValueError('onboarding_duplicate_or_invalid_variant')
        seen.add((entry, variant))
        key = item.get('task_key') or str(uuid4())
        if key in selected_keys:
            raise ValueError('onboarding_duplicate_task_selection')
        selected_keys.add(key)
        context = TaskContext(Path(observed['root']), None if key == 'default' else key)
        existing = ProjectConfig.load(context.root, task_key=context.task_key) if context.config_path.exists() else None
        if item.get('task_key') and not existing:
            raise ValueError('onboarding_existing_config_missing_restore_required')
        tasks.append({'root': str(context.root), 'task_key': key, 'entry': entry,
                      'variant': variant, 'phase': 'ready_to_submit' if existing else 'environment_pending',
                      'project_key': existing.project_key if existing else None,
                      'integration_id': existing.integration_id if existing else None,
                      'run_key': None, 'verification': None})
    state = {'version': 1, 'session_id': str(uuid4()), 'scope': observed['scope'],
             'scope_digest': scope_digest, 'experienced': bool(experienced),
             'created_at': now(), 'tasks': tasks, 'plans': {}}
    save(state)
    return state


def local_evidence(task) -> dict:
    context = context_of(task)
    observed = discover(checked_scope(context.root))
    if observed['limited']:
        raise ValueError('onboarding_scope_too_large_narrow_scope')
    files = {}
    for name in ('integration.yaml', 'result-contract.yaml', 'identity.json', 'dashboard.json',
                 'schedule-map.json', 'run.command', 'run.ps1', 'windows-task-wrapper.ps1'):
        path = context.file(name)
        if path.exists():
            if path.stat().st_size > 1024 * 1024:
                raise ValueError('onboarding_declaration_too_large')
            files[name] = hashlib.sha256(path.read_bytes()).hexdigest()
        else:
            files[name] = None
    config = ProjectConfig.load(context.root, task_key=context.task_key) if context.config_path.exists() else None
    contract = load_result_contract(context.root, task_key=context.task_key) if context.contract_path.exists() else None
    fingerprint = project_fingerprint(context.root, config=config,
                    policy=contract.payload.get('fingerprint') if contract else None) if config else None
    contract_current = False
    if config and contract:
        try:
            contract.validate_project(config, fingerprint)
            contract_current = True
        except ValueError:
            pass
    return {'source_digest': observed['digest'], 'files': files,
            'project_key': config.project_key if config else None,
            'integration_id': config.integration_id if config else None,
            'fingerprint': fingerprint, 'contract_current': contract_current,
            'contract_digest': contract.digest if contract else None}


def output_conflicts(state) -> list[dict]:
    owners = {}
    contexts = {context_of(task) for task in state['tasks']}
    # Include already declared siblings, not their actual output contents.
    for root in {context.root for context in contexts}:
        default = TaskContext(root)
        if default.config_path.exists():
            contexts.add(default)
        directory = default.file('tasks')
        if directory.is_dir():
            for entry in directory.iterdir():
                context = TaskContext(root, entry.name)
                if context.config_path.exists():
                    contexts.add(context)
    for context in contexts:
        paths = set()
        if context.config_path.exists():
            config = ProjectConfig.load(context.root, task_key=context.task_key)
            paths.update(config.artifacts + config.html_reports)
            if config.result_json:
                paths.add(config.result_json)
            if config.diagnostics:
                paths.add(config.diagnostics['file'])
        if context.contract_path.exists():
            contract = load_result_contract(context.root, task_key=context.task_key)
            paths.update(item['path'] for item in contract.payload['sources'].values())
            paths.update(item['path'] for item in contract.payload.get('artifacts', []))
        for path in paths:
            owners.setdefault((str(context.root), path), set()).add(context.task_key or 'default')
    return [{'root': root, 'path': path, 'tasks': sorted(keys)}
            for (root, path), keys in sorted(owners.items()) if len(keys) > 1]


def validate_spec(spec, root: Path):
    if (not isinstance(spec, dict) or set(spec) - {'name', 'platform', 'command', 'artifacts', 'html_reports', 'result_json'}
            or not all(isinstance(spec.get(key), str) and spec[key].strip() for key in ('name', 'platform'))
            or not isinstance(spec.get('command'), list) or not spec['command']
            or not all(isinstance(part, str) and part for part in spec['command'])):
        raise ValueError('onboarding_init_spec_invalid')
    if any(any(word in part.casefold() for word in ('password', 'token', 'secret', 'cookie', 'authorization'))
           for part in spec['command']):
        raise ValueError('onboarding_command_credentials_not_allowed')
    for key in ('artifacts', 'html_reports'):
        if not isinstance(spec.get(key, []), list) or not all(isinstance(x, str) for x in spec.get(key, [])):
            raise ValueError('onboarding_upload_spec_invalid')
    for path in spec.get('artifacts', []) + spec.get('html_reports', []) + ([spec['result_json']] if spec.get('result_json') else []):
        if not isinstance(path, str) or any(c in path for c in '*?[]'):
            raise ValueError('onboarding_requires_exact_output_paths')
        confined_path(root, path)


def preview(session_id: str, task_key: str, operation: str, spec=None) -> dict:
    if operation not in {'initialize', 'repair', 'submit', 'run'}:
        raise ValueError('onboarding_operation_invalid')
    with file_lock(state_path(session_id).with_suffix('.lock')):
        state = load(session_id)
        task = task_in(state, task_key)
        if not state['experienced'] and task != state['tasks'][0] and state['tasks'][0]['phase'] != 'verified':
            raise ValueError('verify_first_task_or_explicitly_choose_experienced_mode')
        context = context_of(task)
        evidence = local_evidence(task)
        if operation == 'initialize':
            if context.config_path.exists():
                raise ValueError('existing_task_use_sync_not_initialize')
            validate_spec(spec, context.root)
        elif not context.config_path.exists():
            raise ValueError('onboarding_configuration_required')
        elif spec is not None:
            raise ValueError('onboarding_unexpected_spec')
        if operation in {'submit', 'run'}:
            if not evidence['contract_digest']:
                raise ValueError('onboarding_output_contract_required')
            if output_conflicts(state):
                raise ValueError('onboarding_output_path_conflict')
        config = ProjectConfig.load(context.root, task_key=context.task_key) if context.config_path.exists() else None
        launchers = [context.file(name) for name in ('run.command', 'run.ps1', 'windows-task-wrapper.ps1')]
        registry = reporter_home() / ('task-profiles.json' if context.task_key else 'projects.json')
        if operation == 'initialize':
            files = [context.config_path, context.file('identity.json'),
                     TaskContext(context.root).file('workspace.json'), context.file('init-receipt.json'),
                     *launchers, registry]
        elif operation == 'repair':
            files = [*[path for path in launchers if not path.exists()], registry]
        elif operation == 'submit':
            files = [context.config_path]
            snapshot = load_result_contract(context.root, task_key=context.task_key)
            if snapshot.is_v2:
                suffix = snapshot.digest.split(':')[1] + '.yaml'
                files.extend(path for path in (context.file('result-contract.' + suffix),
                             context.file('result-contract.backup-' + suffix)) if not path.exists())
        else:
            files = []
        uploads = (spec.get('artifacts', []) + spec.get('html_reports', [])
                   + ([spec['result_json']] if spec.get('result_json') else [])) if spec else (
                   config.artifacts + config.html_reports + ([config.result_json] if config.result_json else []))
        if operation in {'submit', 'run'}:
            snapshot = load_result_contract(context.root, task_key=context.task_key)
            uploads += [item['path'] for item in snapshot.payload.get('artifacts', [])
                        if item['visibility'] in {'public', 'internal'}]
        plan = {'version': 1, 'plan_id': str(uuid4()), 'task_key': task_key,
                'operation': operation, 'evidence': evidence, 'spec': spec,
                'commands': [{'category': operation, 'working_directory': str(config.resolved_working_directory(context.root) if config else context.root),
                              'command': (spec['command'] if spec else config.command) if operation in {'initialize', 'run'} else None}],
                'files': [str(path) for path in files],
                'upload_scope': [] if operation == 'repair' else sorted(set(uploads)),
                'contract_digest': evidence['contract_digest'], 'created_at': now()}
        plan['digest'] = digest(plan)
        state['plans'][plan['plan_id']] = {'plan': plan, 'status': 'prepared'}
        save(state)
        return plan


def client_for_onboarding():
    return ReporterClient(IdentityStore(create=False).load())


def apply(session_id: str, plan_id: str, confirmation_digest: str, *, client=None) -> dict:
    with file_lock(state_path(session_id).with_suffix('.lock')):
        state = load(session_id)
        record = state['plans'].get(plan_id)
        if record is None:
            raise ValueError('onboarding_plan_not_found')
        plan = record['plan']
        if (plan['digest'] != confirmation_digest
                or digest({k: v for k, v in plan.items() if k != 'digest'}) != confirmation_digest):
            raise ValueError('onboarding_confirmation_mismatch')
        if record['status'] == 'applied':
            return {'already_applied': True, 'task': task_in(state, plan['task_key'])}
        if record['status'] == 'superseded':
            raise ValueError('onboarding_plan_superseded_use_current_plan')
        if plan['operation'] == 'run' and record['status'] != 'prepared':
            raise ValueError('onboarding_run_already_attempted_verify_before_new_confirmation')
        task = task_in(state, plan['task_key'])
        context = context_of(task)
        with file_lock(context.file('operation.lock')):
            if local_evidence(task) != plan['evidence']:
                raise ValueError('onboarding_plan_stale_preview_again')
            if plan['operation'] != 'repair':
                client = client or client_for_onboarding()
                capabilities = client.signed_get('/reporter/v1/capabilities')
                if capabilities.get('task_profiles') != 1 or capabilities.get('onboarding_verification') != 1:
                    raise ValueError('onboarding_server_upgrade_required')
            record['status'] = 'attempted'
            save(state)
            try:
                if plan['operation'] == 'initialize':
                    from shopops_reporter.project import _initialize_project
                    spec = plan['spec']
                    config, _ = _initialize_project(client=client, project_dir=context.root,
                        task_key=context.task_key, entry=task['entry'], variant=task['variant'],
                        display_name=spec['name'], platform_name=spec['platform'], command=spec['command'],
                        artifacts=spec.get('artifacts', []), html_reports=spec.get('html_reports', []),
                        result_json=spec.get('result_json'), diagnostics=None, ai_readable_artifacts=[])
                    task.update(project_key=config.project_key, integration_id=config.integration_id,
                                phase='output_pending')
                elif plan['operation'] == 'repair':
                    from shopops_reporter.project import write_launchers
                    from shopops_reporter.schedule_map import register_project
                    config = ProjectConfig.load(context.root, task_key=context.task_key)
                    if task['integration_id'] and task['integration_id'] != config.integration_id:
                        raise ValueError('onboarding_identity_changed_restore_required')
                    write_launchers(context.root, task_key=context.task_key, preserve_existing=True)
                    register_project(context.root, task_key=context.task_key)
                    task.update(project_key=config.project_key, integration_id=config.integration_id,
                                phase='output_pending' if not plan['contract_digest'] else 'verification_pending')
                elif plan['operation'] == 'submit':
                    from shopops_reporter.cli import _manage_result_contract
                    receipt = _manage_result_contract(SimpleNamespace(contract_action='submit'), context, client=client)
                    task.update(contract_digest=receipt['digest'], phase='review_pending')
                else:
                    status = client.signed_get(f"/reporter/v1/projects/{task['integration_id']}/status")['onboarding']
                    if (status['integration_status'] != 'active' or status['binding_status'] != 'active'
                            or not status['contract'] or status['contract']['status'] != 'approved'
                            or status['contract']['digest'] != plan['contract_digest']):
                        raise ValueError('onboarding_approval_required')
                    from shopops_reporter.runner import run_project
                    config = ProjectConfig.load(context.root, task_key=context.task_key)
                    reference = config.result_contract
                    if (not reference or reference.get('digest') != status['contract']['digest']
                            or reference.get('version') != status['contract']['version']):
                        raise ValueError('onboarding_contract_receipt_mismatch')
                    # Freeze the approval just observed for this run, without rewriting
                    # the declaration whose bytes are bound to the confirmed plan.
                    config = replace(config, result_contract={**reference, 'status': 'approved'})
                    task.update(run_key=uuid4().hex, phase='report_pending', verification=None)
                    save(state)
                    # Daemon lifecycle has its own confirmation; run never starts it here.
                    code = run_project(project_dir=context.root, config=config, start_daemon=False,
                                       local_run_key=task['run_key'], require_tracking=True,
                                       output_stream=sys.stderr.buffer)
                    task['exit_code'] = code
                if plan['operation'] in {'initialize', 'repair'}:
                    for previous in state['plans'].values():
                        if (previous['plan']['task_key'] == task['task_key']
                                and previous['plan']['operation'] == 'initialize'
                                and previous['status'] == 'attempted'):
                            previous['status'] = 'superseded'
                record['status'] = 'applied'
                task.pop('error_code', None)
            except Exception as error:
                task.update(phase='needs_repair', error_code=type(error).__name__)
                save(state)
                raise
            save(state)
            return {'task': task, 'operation': plan['operation']}


def spool_receipt(run_key: str) -> dict | None:
    path = reporter_home() / 'spool.db'
    if not path.exists():
        return None
    with sqlite3.connect(path.as_uri() + '?mode=ro', uri=True) as connection:
        connection.row_factory = sqlite3.Row
        row = connection.execute('SELECT config_json, server_run_id, upload_state, local_status FROM local_run WHERE local_run_key = ?',
                                 (run_key,)).fetchone()
    return dict(row) if row else None


def check(session_id: str, task_key: str, *, client=None) -> dict:
    with file_lock(state_path(session_id).with_suffix('.lock')):
        state = load(session_id)
        task = task_in(state, task_key)
        try:
            evidence = local_evidence(task)
            if task['integration_id'] and task['integration_id'] != evidence['integration_id']:
                raise ValueError('onboarding_identity_changed_restore_required')
        except Exception as error:
            task.update(phase='needs_repair', check_state='unavailable', error_code=type(error).__name__)
            save(state)
            return task
        if not evidence['integration_id']:
            task['phase'] = 'environment_pending'
            save(state)
            return task
        task.update(integration_id=evidence['integration_id'], project_key=evidence['project_key'])
        if any(record['plan']['task_key'] == task_key
               and record['plan']['operation'] == 'initialize' and record['status'] == 'attempted'
               for record in state['plans'].values()):
            task.update(phase='needs_repair', error_code='onboarding_local_setup_incomplete')
            save(state)
            return task
        try:
            client = client or client_for_onboarding()
            status = client.signed_get(f"/reporter/v1/projects/{task['integration_id']}/status")['onboarding']
            contract = status['contract']
            if status['binding_status'] != 'active' or status['integration_status'] not in {'active', 'pending'}:
                task['phase'] = 'needs_repair'
            elif status['integration_status'] == 'pending':
                task['phase'] = 'review_pending'
            elif not evidence['contract_digest']:
                task['phase'] = 'output_pending'
            elif not contract or contract['digest'] != evidence['contract_digest']:
                task['phase'] = 'ready_to_submit'
            elif not evidence['contract_current']:
                task['phase'] = 'ready_to_submit'
            elif contract['status'] != 'approved':
                task['phase'] = 'review_pending' if contract['status'] == 'pending' else 'needs_repair'
            elif not task['run_key']:
                task['phase'] = 'run_pending'
            else:
                receipt = spool_receipt(task['run_key'])
                if receipt is None:
                    task['phase'] = 'needs_repair'
                elif (json.loads(receipt['config_json'])['integration_id'] != task['integration_id']
                      or json.loads(receipt['config_json']).get('task_key') != context_of(task).task_key):
                    raise ValueError('onboarding_run_identity_mismatch')
                elif not receipt['server_run_id'] or receipt['upload_state'] != 'complete':
                    task['phase'] = 'report_pending'
                else:
                    run_id = str(UUID(receipt['server_run_id']))
                    verified = client.signed_get(f"/reporter/v1/projects/{task['integration_id']}/runs/{run_id}/verification")
                    if (verified.get('version') != 1 or verified.get('run_id') != run_id
                            or verified.get('integration_id') != task['integration_id']):
                        raise ValueError('onboarding_verification_response_invalid')
                    task['verification'] = verified
                    matching = verified['contract']['digest'] == evidence['contract_digest']
                    task['phase'] = 'verified' if verified['complete'] and matching else 'verification_pending'
            task['last_checked_at'] = now()
            task['check_state'] = 'current'
            task.pop('error_code', None)
        except Exception as error:
            # Preserve previous evidence and its timestamp without claiming it is current.
            task.update(check_state='unavailable', phase='verification_pending', error_code=type(error).__name__)
        save(state)
        return task
