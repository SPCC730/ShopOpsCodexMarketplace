from __future__ import annotations

import argparse
import contextlib
import getpass
import json
import os
import shlex
import sys
import time
import copy
import yaml
from pathlib import Path
from typing import Any
from uuid import uuid4

from shopops_reporter.client import ReporterApiError, ReporterClient, generate_private_key
from shopops_reporter.config import (
    IdentityStore,
    NotPairedError,
    ProjectConfig,
    default_device_name,
    find_project_dir,
    normalize_server_url,
    reporter_home,
)
from shopops_reporter.daemon import (
    Uploader,
    ensure_daemon_running,
    serve,
    stop_daemon,
)
from shopops_reporter.diagnostics import validate_ai_readable_paths
from shopops_reporter.project import initialize_project
from shopops_reporter.project import project_fingerprint
from shopops_reporter.result_mapping import evaluate_result_contract, load_result_contract
from shopops_reporter.schedule_map import accept_mapping, registered_tasks
from shopops_reporter.protocol import emit_error, emit_success
from shopops_reporter.runner import run_project
from shopops_reporter.spool import Spool
from shopops_reporter.project_sync import ProjectSynchronizer, read_sync_status
from shopops_reporter.fingerprint import validate_fingerprint_policy
from shopops_reporter.result_mapping.loader import snapshot_from_payload, canonical_digest
from shopops_reporter.result_mapping.policy import CONTRACT_V2, reporting_policy
from shopops_reporter.daemon_control import inspect_daemon
from shopops_reporter.task_context import TaskContext, file_lock, atomic_json, confined_path


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(
        prog="shopops-report",
        description="在开发者电脑运行原脚本，并向 ShopOps 上报运行记录。",
    )
    root.add_argument("--json", action="store_true", dest="json_output")
    commands = root.add_subparsers(dest="action", required=True)

    enroll = commands.add_parser("enroll", help="使用一次性配对码登记这台电脑")
    enroll.add_argument("--server", required=True, help="ShopOps 后端地址")
    enroll.add_argument("--pairing-code", help="管理台生成的一次性配对码")
    enroll.add_argument("--name", default=default_device_name(), help="设备显示名称")
    enroll.add_argument("--operator", help="开发者声明名称")
    enroll.add_argument("--force", action="store_true", help="覆盖本机已有设备身份")

    init = commands.add_parser("init", help="接入当前脚本项目")
    init.add_argument("--name", required=True, help="SOP/项目名称")
    init.add_argument("--platform", default="通用", help="业务平台")
    init.add_argument("--command", required=True, help="原脚本启动命令")
    init.add_argument("--artifact", action="append", default=[], help="附件相对 glob，可重复")
    init.add_argument("--html-report", action="append", default=[], help="HTML 相对 glob，可重复")
    init.add_argument("--result-json", help="结构化结果 JSON 相对路径")
    init.add_argument("--diagnostics-file", help="诊断信封 JSON 相对路径")
    init.add_argument(
        "--ai-readable",
        action="append",
        default=[],
        help="允许 AI 读取的文本产物相对路径，可重复",
    )
    init.add_argument("--project-dir", type=Path, default=Path.cwd())
    init.add_argument('--task', help='具名任务 UUID；省略时保留原默认任务')
    init.add_argument('--entry', help='新具名任务的项目相对入口路径')
    init.add_argument('--variant', default='', help='同入口不同任务的已确认非敏感标识')

    sync = commands.add_parser("sync", help="同步当前项目的接入配置和看板声明")
    sync.add_argument('--task')
    sync.add_argument(
        "--project-dir",
        type=Path,
        default=Path.cwd(),
        help="项目目录或其子目录，默认使用当前目录",
    )

    map_schedule = commands.add_parser('map-schedule', help='声明 macOS launchd 计划所属的 SOP')
    map_schedule.add_argument('--label', required=True)
    map_schedule.add_argument('--domain', help='Label 不唯一时指定 gui/UID 或 system')
    map_schedule.add_argument('--project-dir', type=Path, default=Path.cwd())
    map_schedule.add_argument('--task')

    accept_schedule = commands.add_parser("accept-schedule", help="接受一条外部任务计划映射")
    accept_schedule.add_argument("--schedule-key", required=True)
    accept_schedule.add_argument("--mapping-hash", required=True)
    accept_schedule.add_argument("--project-fingerprint", required=True)
    accept_schedule.add_argument("--project-dir", type=Path, default=Path.cwd())
    accept_schedule.add_argument("--expected-on-each-run", action="store_true")
    accept_schedule.add_argument('--task')

    run = commands.add_parser("run", help="运行当前项目并上报")
    run.add_argument('--task')
    run.add_argument('--project-dir', type=Path, default=Path.cwd())
    run.add_argument("command", nargs=argparse.REMAINDER, help="可选命令覆盖，写在 -- 后")

    result_contract = commands.add_parser(
        "result-contract",
        help="验证、预览或提交当前项目的运行结果契约",
    )
    result_contract.add_argument(
        "contract_action",
        choices=("validate", "preview", "submit", "migrate-fingerprint", "migrate-schema"),
    )
    result_contract.add_argument("--project-dir", type=Path, default=Path.cwd())
    result_contract.add_argument('--task')
    result_contract.add_argument('--contract-file', type=Path, help='项目内候选契约路径')
    result_contract.add_argument('--to', choices=['v2'], dest='target_schema')
    result_contract.add_argument(
        "--output", action="append", default=[],
        help="迁移 v2 指纹时显式声明动态输出文件，可重复；不支持目录或通配符",
    )

    commands.add_parser("start", help="启动 Reporter 后台服务")
    commands.add_parser("stop", help="停止 Reporter 后台服务")
    commands.add_parser("status", help="查看设备、后台服务和离线队列状态")
    serve_parser = commands.add_parser("serve", help=argparse.SUPPRESS)
    serve_parser.add_argument("--once", action="store_true")
    flush = commands.add_parser("flush", help="立即补传本地队列")
    flush.add_argument("--timeout", type=float, default=30)
    onboarding = commands.add_parser('onboarding', help='显式接入向导：发现、操作预览和验收')
    guided = onboarding.add_subparsers(dest='onboarding_action', required=True)
    guided.add_parser('capabilities')
    discovery = guided.add_parser('discover')
    discovery.add_argument('--path', type=Path, required=True)
    preparation = guided.add_parser('prepare')
    preparation.add_argument('--path', type=Path, required=True)
    preparation.add_argument('--selection', type=Path, required=True)
    preparation.add_argument('--scope-digest', required=True)
    preparation.add_argument('--experienced', action='store_true')
    preview = guided.add_parser('preview')
    preview.add_argument('--session', required=True)
    preview.add_argument('--task', required=True)
    preview.add_argument('--operation', choices=['initialize', 'repair', 'submit', 'run'], required=True)
    preview.add_argument('--spec', type=Path)
    apply = guided.add_parser('apply')
    apply.add_argument('--session', required=True)
    apply.add_argument('--plan', required=True)
    apply.add_argument('--confirm-digest', required=True)
    batch = guided.add_parser('apply-batch')
    batch.add_argument('--session', required=True)
    batch.add_argument('--confirmations', type=Path, required=True)
    for action in ('status', 'check'):
        command = guided.add_parser(action)
        command.add_argument('--session', required=True)
        if action == 'check':
            command.add_argument('--task', required=True)
    return root


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        return dispatch(args)
    except ReporterApiError as error:
        if args.json_output:
            emit_error(args.action, "api_error", str(error.detail))
            return 2
        print(f"Reporter API 请求失败：{error.detail}（HTTP {error.status_code}）", file=sys.stderr)
        return 2
    except NotPairedError as error:
        if args.json_output:
            emit_error(args.action, "not_paired", str(error))
            return 2
        print(f"ShopOps Reporter：{error}", file=sys.stderr)
        return 2
    except (OSError, RuntimeError, ValueError) as error:
        if args.json_output:
            code = "validation_error" if isinstance(error, ValueError) else "runtime_error"
            emit_error(args.action, code, str(error))
            return 2
        print(f"ShopOps Reporter：{error}", file=sys.stderr)
        return 2


def dispatch(args: argparse.Namespace) -> int:
    if args.action == 'onboarding':
        from shopops_reporter.onboarding.commands import dispatch_onboarding
        data = dispatch_onboarding(args)
        if args.json_output:
            emit_success('onboarding', data)
        else:
            print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0
    if args.action == "enroll":
        data = enroll(args)
        if args.json_output:
            emit_success("enroll", data)
        else:
            print(f"设备配对成功：{data['device']}")
            print(f"设备 ID：{data['device_id']}")
            print(f"私钥存储：{data['private_key_storage']}")
        return 0
    if args.action == "init":
        if args.json_output:
            with contextlib.redirect_stdout(sys.stderr):
                exit_code = init_project(args)
            emit_success("init", {"exit_code": exit_code})
            return exit_code
        return init_project(args)
    if args.action == "sync":
        if args.json_output:
            with contextlib.redirect_stdout(sys.stderr):
                exit_code = sync_project(args)
            sync_status = read_sync_status(selected_project_dir(args), task_key=args.task)
            if exit_code:
                emit_error("sync", str(sync_status.get("sync_state", "sync_failed")),
                           str(sync_status.get("error_code", "Project sync requires attention")))
            else:
                emit_success("sync", {"exit_code": exit_code, "sync": sync_status})
            return exit_code
        return sync_project(args)
    if args.action == 'map-schedule':
        from shopops_reporter.macos_scheduler import declare_launchd_mapping
        data = declare_launchd_mapping(selected_project_dir(args), args.label,
                                       task_key=args.task, domain=args.domain)
        if args.json_output:
            emit_success('map-schedule', data)
        else:
            print(f"已声明计划归属，下一次同步后可确认：{data['schedule_key']}")
        return 0
    if args.action == "accept-schedule":
        data = accept_schedule_mapping(args)
        if args.json_output:
            emit_success("accept-schedule", data)
        else:
            print(f"已接受任务计划映射：{data['schedule_key']}")
            print(f"映射文件：{data['mapping_path']}")
        return 0
    if args.action == "run":
        project_dir = selected_project_dir(args)
        config = ProjectConfig.load(project_dir, task_key=args.task)
        override = list(args.command)
        if override and override[0] == "--":
            override.pop(0)
        if args.json_output:
            exit_code = run_project(
                project_dir=project_dir,
                config=config,
                command_override=override or None,
                output_stream=sys.stderr.buffer,
            )
            emit_success("run", {"exit_code": exit_code})
            return exit_code
        return run_project(project_dir=project_dir, config=config, command_override=override or None)
    if args.action == "result-contract":
        data = manage_result_contract(args)
        if args.json_output:
            emit_success("result-contract", data)
        else:
            print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0
    if args.action == "start":
        data = start()
        if args.json_output:
            emit_success("start", data)
        else:
            print(f"Reporter 已启动，PID {data['daemon']['pid']}")
        return 0
    if args.action == "stop":
        data = stop()
        if args.json_output:
            emit_success("stop", data)
        else:
            print("Reporter 已停止" if data["stopped"] else "Reporter 当前未运行")
        return 0
    if args.action == "status":
        data = status()
        if args.json_output:
            emit_success("status", data)
        else:
            print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0
    if args.action == "serve":
        serve(once=args.once)
        if args.json_output:
            emit_success("serve", {"exit_code": 0})
        return 0
    if args.action == "flush":
        data = flush(args.timeout)
        if args.json_output:
            emit_success("flush", data)
        else:
            print(json.dumps(data, ensure_ascii=False))
        return 0 if data["pending_runs"] == 0 else 1
    raise RuntimeError(f"未知命令: {args.action}")


def enroll(args: argparse.Namespace) -> dict[str, Any]:
    store = IdentityStore()
    if store.exists() and not args.force:
        raise RuntimeError("这台电脑已经配对；如需替换身份请使用 --force")
    pairing_code = args.pairing_code or getpass.getpass("一次性配对码：").strip()
    if not pairing_code:
        raise ValueError("配对码不能为空")
    server_url = normalize_server_url(args.server)
    installation_id = str(uuid4())
    private_key, public_key = generate_private_key()
    response = ReporterClient.enroll(
        server_url=server_url,
        pairing_code=pairing_code,
        installation_id=installation_id,
        display_name=args.name,
        declared_operator=args.operator,
        public_key=public_key,
    )
    identity = store.save(
        server_url=server_url,
        device_id=str(response["id"]),
        installation_id=installation_id,
        display_name=args.name,
        declared_operator=args.operator,
        private_key=private_key,
    )
    return {
        "device": identity.display_name,
        "device_id": identity.device_id,
        "private_key_storage": identity.private_key_storage,
    }


def init_project(args: argparse.Namespace) -> int:
    identity = IdentityStore().load()
    command = split_command(args.command)
    if not command:
        raise ValueError("启动命令不能为空")
    ai_readable_artifacts = validate_ai_readable_paths(
        args.ai_readable,
        args.artifact,
    )
    diagnostics = (
        {"schema_version": 1, "file": args.diagnostics_file}
        if args.diagnostics_file
        else None
    )
    config, created = initialize_project(
        client=ReporterClient(identity),
        project_dir=args.project_dir,
        display_name=args.name,
        platform_name=args.platform,
        command=command,
        artifacts=args.artifact,
        html_reports=args.html_report,
        result_json=args.result_json,
        diagnostics=diagnostics,
        ai_readable_artifacts=ai_readable_artifacts,
        task_key=getattr(args, 'task', None),
        entry=getattr(args, 'entry', None),
        variant=getattr(args, 'variant', ''),
    )
    print("已创建待确认 SOP" if created else "已更新现有外部 SOP 接入")
    print(f"Integration ID：{config.integration_id}")
    print(f"配置文件：{TaskContext(args.project_dir, getattr(args, 'task', None)).config_path}")
    return 0


def selected_project_dir(args: argparse.Namespace) -> Path:
    task_key = getattr(args, 'task', None)
    if task_key is None:
        return find_project_dir(args.project_dir)
    return find_project_dir(args.project_dir, task_key=task_key)


def sync_project(args: argparse.Namespace) -> int:
    """Refresh an existing integration without re-uploading the project."""
    project_dir = selected_project_dir(args)
    existing = ProjectConfig.load(project_dir, task_key=getattr(args, 'task', None))
    identity = IdentityStore().load()
    config, created = initialize_project(
        client=ReporterClient(identity),
        project_dir=project_dir,
        display_name=existing.display_name,
        platform_name=existing.platform,
        command=existing.command,
        artifacts=existing.artifacts,
        html_reports=existing.html_reports,
        result_json=existing.result_json,
        diagnostics=existing.diagnostics,
        ai_readable_artifacts=existing.ai_readable_artifacts,
        task_key=existing.task_key,
    )
    if created:
        # This should only happen when the server-side integration was removed;
        # keep the message explicit so the operator knows a new review is needed.
        print("已重新创建待确认 SOP 接入")
    else:
        print("已同步现有外部 SOP 接入")
    if config.dashboard:
        print(
            f"看板：{config.dashboard['title']} "
            f"（{config.dashboard['kind']}）"
        )
    else:
        print("看板：未声明（如需看板，请先添加 .shopops/dashboard.json）")
    print(f"Integration ID：{config.integration_id}")
    print(f"配置文件：{TaskContext(project_dir, config.task_key).config_path}")
    synced = ProjectSynchronizer(ReporterClient(identity)).sync_one(project_dir, task_key=config.task_key)
    status = read_sync_status(project_dir, task_key=config.task_key)
    if synced:
        print("项目资料已同步")
        return 0
    if status.get("sync_state") == "unsupported_server":
        print("当前服务端不支持项目资料同步；原接入配置已更新")
        return 0
    if status.get("sync_state") == "pending_migration":
        print("设备迁移待管理员确认；当前设备尚未获得该项目上传权限")
    else:
        print(f"项目资料同步失败：{status.get('error_code', 'sync_failed')}")
    return 1


def manage_result_contract(args: argparse.Namespace) -> dict[str, Any]:
    project_dir = selected_project_dir(args)
    context = TaskContext(project_dir, getattr(args, 'task', None))
    client = None
    if args.contract_action == 'migrate-schema':
        client = ReporterClient(IdentityStore().load())
        require_contract_v2(client)
    if args.contract_action in {'submit', 'migrate-fingerprint', 'migrate-schema'}:
        with file_lock(context.file('operation.lock')):
            return _manage_result_contract(args, context, client=client)
    return _manage_result_contract(args, context)


def _manage_result_contract(args, context: TaskContext, *, client=None) -> dict[str, Any]:
    project_dir = context.root
    config = ProjectConfig.load(project_dir, task_key=context.task_key)
    selected_file = getattr(args, 'contract_file', None)
    if selected_file is not None:
        selected_file = Path(selected_file)
        relative = selected_file.relative_to(project_dir).as_posix() if selected_file.is_absolute() else selected_file.as_posix()
        selected_file = confined_path(project_dir, relative)
        selected_file.relative_to(context.config_dir)
        if context.task_key is None and 'tasks' in selected_file.relative_to(context.config_dir).parts:
            raise ValueError('result_contract_file_wrong_task')
    snapshot = load_result_contract(project_dir, path=selected_file, task_key=context.task_key)
    if args.contract_action == 'migrate-schema':
        if getattr(args, 'target_schema', None) != 'v2':
            raise ValueError('result_contract_target_schema_required')
        require_contract_v2(client or ReporterClient(IdentityStore().load()))
        if snapshot.is_v2:
            return {'changed': False, 'schema': CONTRACT_V2, 'contract_file': str(snapshot.path)}
        candidate = copy.deepcopy(snapshot.payload)
        for key in ('project_fingerprint', 'script_version', 'fingerprint'):
            candidate.pop(key, None)
        candidate.update(schema=CONTRACT_V2, business_meaning='', reporting_policy=reporting_policy(config))
        target = context.file('result-contract.v2.candidate.yaml')
        if target.exists():
            raise ValueError('result_contract_candidate_exists_preserve_and_review')
        atomic_json(target, candidate)
        return {'changed': True, 'submitted': False, 'contract_file': str(target),
                'active_contract_file': str(snapshot.path), 'schema': CONTRACT_V2,
                'required_fields': ['business_meaning'], 'candidate': candidate}
    migrating = args.contract_action == "migrate-fingerprint"
    if migrating:
        if snapshot.is_v2:
            raise ValueError('result_contract_v2_fingerprint_is_project_metadata')
        policy = validate_fingerprint_policy({"version": 2, "outputs": args.output})
        payload = copy.deepcopy(snapshot.payload)
        payload["fingerprint"] = policy
        payload["project_fingerprint"] = project_fingerprint(project_dir, config=config, policy=policy)
        snapshot = snapshot_from_payload(payload, project_dir, path=snapshot.path)
    fingerprint = project_fingerprint(
        project_dir, config=config, policy=snapshot.payload.get("fingerprint"),
    )
    if not snapshot.is_v2 and snapshot.project_fingerprint != fingerprint:
        raise ValueError(
            "结果契约绑定的项目指纹与当前代码不一致，请重新生成并审核契约"
        )
    if snapshot.is_v2:
        snapshot.validate_project(config, fingerprint)
    _validate_contract_sample_files(snapshot.payload, project_dir)
    if args.contract_action == "validate":
        return {
            "valid": True,
            "digest": snapshot.digest,
            "project_fingerprint": fingerprint,
            "sample_count": len(snapshot.payload["samples"]),
            "schema": snapshot.payload['schema'],
            "contract_file": str(snapshot.path),
        }
    if args.contract_action == "preview":
        outcome = evaluate_result_contract(snapshot, project_dir)
        if (config.result_contract and config.result_contract.get('digest') == snapshot.digest
                and isinstance(config.result_contract.get("version"), int)):
            outcome.result["contract"]["version"] = config.result_contract["version"]
        return {"result": outcome.result, "warnings": list(outcome.warnings)}

    client = client or ReporterClient(IdentityStore().load())
    body = {"contract": snapshot.payload, "digest": snapshot.digest}
    if snapshot.is_v2:
        require_contract_v2(client)
        body.update(project_fingerprint=fingerprint, script_version=config.project_version)
    response = client.signed_json(
        "POST",
        f"/reporter/v1/integrations/{config.integration_id}/result-contracts",
        body,
    )
    if response.get('digest') != snapshot.digest:
        raise ValueError('result_contract_submission_receipt_mismatch')
    if migrating:
        backup = snapshot.path.with_name("result-contract.pre-fingerprint-v2.yaml")
        if not backup.exists():
            with backup.open("x", encoding="utf-8") as handle:
                handle.write(snapshot.path.read_text(encoding="utf-8"))
        temporary = snapshot.path.with_suffix(".yaml.tmp")
        temporary.write_text(yaml.safe_dump(snapshot.payload, allow_unicode=True), encoding="utf-8")
        temporary.replace(snapshot.path)
    if not snapshot.is_v2:
        config.fingerprint = snapshot.payload.get("fingerprint")
    active_name = None
    if selected_file is not None or snapshot.is_v2:
        old_path = context.contract_path
        if old_path.is_file():
            backup = context.file('result-contract.backup-' + canonical_digest(yaml.safe_load(old_path.read_text(encoding='utf-8'))).split(':')[1] + '.yaml')
            if not backup.exists():
                atomic_json(backup, yaml.safe_load(old_path.read_text(encoding='utf-8')))
        active_name = 'result-contract.' + snapshot.digest.split(':')[1] + '.yaml'
        active_path = context.file(active_name)
        if active_path.exists():
            if load_result_contract(project_dir, path=active_path).digest != snapshot.digest:
                raise ValueError('result_contract_snapshot_conflict')
        else:
            atomic_json(active_path, snapshot.payload)
    config.result_contract = {
        "id": str(response["id"]),
        "version": int(response["version"]),
        "digest": str(response["digest"]),
        "status": str(response["status"]),
        "project_fingerprint": fingerprint,
        "snapshot": snapshot.payload,
    }
    if active_name:
        config.result_contract.update(file=active_name, schema=snapshot.payload['schema'],
                                      integration_id=config.integration_id)
    config.save(project_dir)
    return {
        "submitted": True,
        "created": bool(response.get("created")),
        **{key: value for key, value in config.result_contract.items() if key != "snapshot"},
    }


def require_contract_v2(client) -> None:
    try:
        capabilities = client.signed_get('/reporter/v1/capabilities')
    except ReporterApiError as error:
        if error.status_code in {404, 405}:
            raise ValueError('result_contract_v2_server_upgrade_required') from error
        raise
    if CONTRACT_V2 not in capabilities.get('result_contract_schemas', []):
        raise ValueError('result_contract_v2_server_upgrade_required')


def _validate_contract_sample_files(payload: dict[str, Any], project_dir: Path) -> None:
    missing = [
        sample["fixture"]
        for sample in payload["samples"]
        if not (project_dir / sample["fixture"]).is_file()
    ]
    if missing:
        raise ValueError(f"结果契约样例文件不存在: {', '.join(missing)}")


def accept_schedule_mapping(args: argparse.Namespace) -> dict[str, str]:
    project_dir = selected_project_dir(args)
    config = ProjectConfig.load(project_dir, task_key=getattr(args, 'task', None))
    definition_digest = None
    if sys.platform == 'darwin':
        from shopops_reporter.macos_scheduler import MacOSLaunchdScheduler
        scan = MacOSLaunchdScheduler().scan()
        task = next((task for task in scan.tasks if task['schedule_key'] == args.schedule_key), None)
        if task is None or not any(project['project_fingerprint'] == args.project_fingerprint
                                   and project['integration_id'] == config.integration_id
                                   for project in task['projects']):
            raise ValueError('本机计划或项目关联已变化，请重新同步并确认')
        if task['mapping_hash'] != args.mapping_hash:
            raise ValueError('计划映射已变化，请重新同步并确认')
        definition_digest = task['definition_hash']
    identity = IdentityStore().load()
    ReporterClient(identity).accept_schedule(
        {
            "schedule_key": args.schedule_key,
            "mapping_hash": args.mapping_hash,
            "projects": [
                {
                    "project_fingerprint": args.project_fingerprint,
                    **({'integration_id': config.integration_id} if config.task_key else {}),
                    "expected_on_each_run": bool(args.expected_on_each_run),
                }
            ],
        }
    )
    path = accept_mapping(
        project_dir,
        schedule_key=args.schedule_key,
        project_fingerprint=args.project_fingerprint,
        integration_id=config.integration_id,
        task_name=config.display_name,
        definition_hash=definition_digest,
        mapping_hash_value=args.mapping_hash,
        expected_on_each_run=bool(args.expected_on_each_run),
        task_key=config.task_key,
    )
    return {"schedule_key": args.schedule_key, "mapping_path": str(path)}


def _is_windows() -> bool:
    return os.name == "nt"


def split_command(value: str) -> list[str]:
    """Split a configured command with the native host quoting rules."""
    if not value.strip():
        return []
    if _is_windows():
        return _split_windows_command(value)
    return shlex.split(value)


def _split_windows_command(value: str) -> list[str]:
    """Use CommandLineToArgvW so quoted Windows executable paths stay intact."""
    import ctypes
    from ctypes import wintypes

    shell32 = ctypes.WinDLL("shell32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    command_line_to_argv = shell32.CommandLineToArgvW
    command_line_to_argv.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_int)]
    command_line_to_argv.restype = ctypes.POINTER(wintypes.LPWSTR)
    kernel32.LocalFree.argtypes = [wintypes.HLOCAL]
    kernel32.LocalFree.restype = wintypes.HLOCAL

    argument_count = ctypes.c_int()
    arguments = command_line_to_argv(value, ctypes.byref(argument_count))
    if not arguments:
        raise ValueError("无法解析 Windows 启动命令")
    try:
        return [arguments[index] for index in range(argument_count.value)]
    finally:
        kernel32.LocalFree(arguments)


def start() -> dict[str, dict[str, int | bool]]:
    pid = ensure_daemon_running()
    return {"daemon": {"running": True, "pid": pid}}


def stop() -> dict[str, Any]:
    stopped = stop_daemon()
    return {"daemon": {"running": False}, "stopped": stopped}


def status() -> dict[str, Any]:
    identity = IdentityStore(create=False).load()
    daemon_status = inspect_daemon()
    summary = Spool.queue_summary_read_only()
    projects = registered_project_summaries()
    payload = {
        "device": identity.display_name,
        "device_id": identity.device_id,
        "server": identity.server_url,
        "daemon": daemon_status,
        "queue": summary,
        "projects": projects,
        "schedule_sync": {
            "pending": (reporter_home() / "schedule-sync.pending.json").exists(),
            "pending_acceptances": (reporter_home() / "schedule-acceptance.pending.json").exists(),
            "interval_seconds": 60,
        },
        "home": str(reporter_home()),
    }
    return payload


def registered_project_summaries() -> list[dict[str, Any]]:
    summaries: list[dict[str, Any]] = []
    for context in registered_tasks():
        project_dir = context.root
        try:
            config = ProjectConfig.load(project_dir, task_key=context.task_key)
        except (OSError, RuntimeError, TypeError, ValueError):
            continue
        summaries.append(
            {
                "project_dir": str(project_dir.resolve()),
                **({'task_key': context.task_key} if context.task_key else {}),
                "display_name": config.display_name,
                "integration_id": config.integration_id,
                "sync": read_sync_status(project_dir, task_key=context.task_key),
                "dashboard": config.dashboard,
                "windows_wrapper": (
                    context.file('windows-task-wrapper.ps1')
                ).is_file(),
            }
        )
    return summaries


def flush(timeout: float) -> dict[str, int]:
    uploader = Uploader()
    deadline = time.monotonic() + max(0, timeout)
    while uploader.spool.has_pending() and time.monotonic() < deadline:
        processed = uploader.process_once()
        if not processed:
            time.sleep(0.5)
        else:
            time.sleep(0.1)
    return uploader.spool.queue_summary()
