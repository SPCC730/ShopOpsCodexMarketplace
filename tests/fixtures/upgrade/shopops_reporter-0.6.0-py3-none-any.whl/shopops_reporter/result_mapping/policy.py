"""Reviewed reporting configuration, independent of executable source bytes."""

from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

from shopops_reporter.dashboard import validate_dashboard_descriptor
from shopops_reporter.diagnostics import validate_ai_readable_paths


CONTRACT_V2 = "shopops.result_contract.v2"
POLICY_DEFAULTS = {
    "working_directory": ".", "result_json": None, "artifacts": [],
    "html_reports": [], "dashboard": None, "diagnostics": None,
    "ai_readable_artifacts": [],
}


def relative_policy_path(value: Any, *, directory=False, glob=False) -> str:
    if directory and value == ".":
        return value
    if (not isinstance(value, str) or not value or len(value) > 500
            or any(c in value for c in "\\\x00:") or value.startswith("/")
            or any(p in {"", ".", ".."} for p in value.split("/"))
            or (not glob and any(c in value for c in "*?[]"))):
        raise ValueError("result_reporting_policy_path_invalid")
    return value


def validate_reporting_policy(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) - POLICY_DEFAULTS.keys():
        raise ValueError("result_reporting_policy_invalid")
    policy = copy.deepcopy({**POLICY_DEFAULTS, **value})
    relative_policy_path(policy["working_directory"], directory=True)
    if policy["result_json"] is not None:
        relative_policy_path(policy["result_json"])
    for name, maximum in (("artifacts", 100), ("html_reports", 100), ("ai_readable_artifacts", 20)):
        paths = policy[name]
        if not isinstance(paths, list) or len(paths) > maximum:
            raise ValueError("result_reporting_policy_invalid")
        for path in paths:
            relative_policy_path(path, glob=name != "ai_readable_artifacts")
    if policy["dashboard"] is not None:
        dashboard = validate_dashboard_descriptor(policy["dashboard"])
        if dashboard["kind"] == "html":
            relative_policy_path(dashboard["path"])
    diagnostic = policy["diagnostics"]
    if diagnostic is not None:
        if (not isinstance(diagnostic, dict) or set(diagnostic) != {"schema_version", "file"}
                or type(diagnostic["schema_version"]) is not int or diagnostic["schema_version"] != 1):
            raise ValueError("result_reporting_policy_diagnostics_invalid")
        relative_policy_path(diagnostic["file"])
        if Path(diagnostic["file"]).suffix.lower() not in {".json", ".txt", ".log"}:
            raise ValueError("result_reporting_policy_diagnostics_invalid")
    policy["ai_readable_artifacts"] = validate_ai_readable_paths(policy["ai_readable_artifacts"], policy["artifacts"])
    return policy


def reporting_policy(config) -> dict[str, Any]:
    return validate_reporting_policy({key: getattr(config, key) for key in POLICY_DEFAULTS})


def is_v2_reference(reference: Any) -> bool:
    return isinstance(reference, dict) and (
        reference.get("schema") == CONTRACT_V2
        or (isinstance(reference.get("snapshot"), dict)
            and reference["snapshot"].get("schema") == CONTRACT_V2)
    )
