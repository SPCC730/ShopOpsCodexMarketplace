"""Read only explicitly registered application snapshots; stale is never an empty scan."""

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path
from urllib.parse import quote
from shopops_reporter.config import reporter_home
from shopops_reporter.task_context import atomic_json, file_lock


def read_application_snapshot(path: Path, *, now: datetime) -> dict:
    if path.is_symlink() or path.stat().st_size > 10 * 1024 * 1024:
        raise ValueError("application_snapshot_invalid_file")
    value = json.loads(path.read_text(encoding="utf-8"))
    required = {
        "version",
        "source",
        "instance_id",
        "generation",
        "sequence",
        "observed_at",
        "complete",
        "scheduler_state",
        "tasks",
    }
    if (
        not isinstance(value, dict)
        or set(value) != required
        or value["version"] != 2
        or value["source"] != "apscheduler"
    ):
        raise ValueError("application_snapshot_invalid")
    if (
        not isinstance(value["tasks"], list)
        or len(value["tasks"]) > 500
        or type(value["complete"]) is not bool
        or type(value["sequence"]) is not int
        or value["sequence"] < 0
    ):
        raise ValueError("application_snapshot_invalid")
    timestamp = datetime.fromisoformat(value["observed_at"].replace("Z", "+00:00"))
    if timestamp.utcoffset() is None or timestamp > now + timedelta(minutes=5):
        raise ValueError("application_snapshot_invalid_timestamp")
    value["freshness"] = "stale" if now - timestamp > timedelta(minutes=3) else "fresh"
    return value


def registry_path():
    return reporter_home() / "application-schedulers.json"


def register_application_source(*, instance_id, export_file, job_id, integration_id):
    snapshot = read_application_snapshot(Path(export_file), now=datetime.now(UTC))
    if snapshot["instance_id"] != instance_id or job_id not in {
        t["source_schedule_id"] for t in snapshot["tasks"]
    }:
        raise ValueError("application_schedule_identity_mismatch")
    path = registry_path()
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with file_lock(path.with_suffix(".lock")):
        data = json.loads(path.read_text()) if path.exists() else {}
        source = data.setdefault(
            instance_id, {"export_file": str(Path(export_file).resolve()), "mappings": {}}
        )
        if source["export_file"] != str(Path(export_file).resolve()):
            raise ValueError("application_schedule_instance_conflict")
        source["mappings"].setdefault(job_id, [])
        if integration_id not in source["mappings"][job_id]:
            source["mappings"][job_id].append(integration_id)
        atomic_json(path, data)
    return {
        "source": "apscheduler",
        "instance_id": instance_id,
        "job_id": job_id,
        "integration_id": integration_id,
        "binding_status": "pending_admin",
        "trigger_correlation": "unsupported_without_explicit_occurrence_context",
    }


class ApplicationScheduler:
    def __init__(self, client=None):
        self.client = client
        self.leases = {}
        self.last_errors = {}

    def scan_sources(self):
        path = registry_path()
        data = json.loads(path.read_text()) if path.exists() else {}
        result = []
        for instance, registration in data.items():
            try:
                value = read_application_snapshot(
                    Path(registration["export_file"]), now=datetime.now(UTC)
                )
                if value["instance_id"] != instance:
                    raise ValueError("application_schedule_identity_mismatch")
                for task in value["tasks"]:
                    ids = registration["mappings"].get(task["source_schedule_id"])
                    if ids is not None:
                        task["projects"] = [
                            {
                                "integration_id": i,
                                "source": "declared",
                                "expected_on_each_run": True,
                            }
                            for i in ids
                        ]
                result.append(value)
            except (OSError, ValueError, KeyError, TypeError) as error:
                self.last_errors[instance] = type(error).__name__
        return result

    def process_once(self):
        if self.client is None:
            return
        try:
            capabilities = self.client.signed_get("/reporter/v1/capabilities")
            if 2 not in capabilities.get("external_schedule_sync_versions", []):
                self.last_errors["server"] = "unsupported_server"
                return
            for value in self.scan_sources():
                if value.pop("freshness") != "fresh":
                    self.last_errors[value["instance_id"]] = "application_snapshot_stale"
                    continue
                key = (value["instance_id"], value["generation"])
                base = "/reporter/v1/schedule-sources/apscheduler/" + quote(
                    value["instance_id"], safe=""
                )
                try:
                    if key not in self.leases:
                        self.leases[key] = self.client.signed_json(
                            "POST", base + "/claim", {"generation": value["generation"]}
                        )["lease_epoch"]
                    self.client.signed_json(
                        "POST", base + "/sync", {**value, "lease_epoch": self.leases[key]}
                    )
                    self.last_errors.pop(value["instance_id"], None)
                    registered = json.loads(registry_path().read_text())[value["instance_id"]]
                    event_path = Path(registered["export_file"]).with_suffix(
                        Path(registered["export_file"]).suffix + ".events.json"
                    )
                    if (
                        event_path.is_file()
                        and not event_path.is_symlink()
                        and event_path.stat().st_size <= 1024 * 1024
                    ):
                        events = json.loads(event_path.read_text())
                        if events.get("generation") == value["generation"]:
                            self.client.signed_json(
                                "POST",
                                base + "/events",
                                {
                                    "generation": value["generation"],
                                    "lease_epoch": self.leases[key],
                                    "events": events["events"],
                                },
                            )
                            if events.get("truncated"):
                                self.last_errors[value["instance_id"]] = "schedule_events_truncated"
                except Exception as error:
                    self.last_errors[value["instance_id"]] = type(error).__name__
        except Exception as error:
            self.last_errors["server"] = type(error).__name__
