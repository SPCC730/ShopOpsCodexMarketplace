"""Runtime facts with explicit provenance; never execute the business entry point."""

from __future__ import annotations

import json
import platform
import subprocess
from pathlib import Path


def collect_runtime_facts(*, reporter: dict, application: dict | None) -> dict:
    allowed = {"runtime", "version", "architecture"}
    facts = {"status": "unknown", "source": "unknown"}
    if isinstance(application, dict) and application.get("source") in {
        "in_process",
        "explicit_probe",
    }:
        if all(
            isinstance(application.get(k), str) and 0 < len(application[k]) <= 100 for k in allowed
        ):
            facts = {
                "status": "known",
                "source": application["source"],
                **{k: application[k] for k in allowed},
            }
    return {
        "reporter_environment": {k: v for k, v in reporter.items() if k in allowed},
        "application_environment": facts,
    }


def read_application_environment(path: Path, *, run_key: str) -> dict | None:
    try:
        if path.is_symlink() or path.stat().st_size > 4096:
            return None
        value = json.loads(path.read_text(encoding="utf-8"))
        if value.get("external_run_key") != run_key:
            return None
        return {**value, "source": "in_process"}
    except (OSError, ValueError, AttributeError):
        return None


def write_application_environment() -> None:
    """Optional Python in-process hook; writes only into this run's dedicated directory."""
    import os

    directory, run_key = (
        os.environ.get("SHOPOPS_RUN_OUTPUT_DIR"),
        os.environ.get("SHOPOPS_EXTERNAL_RUN_KEY"),
    )
    if not directory or not run_key:
        return
    path = Path(directory) / "application-environment.json"
    payload = {
        "external_run_key": run_key,
        "runtime": "Python",
        "version": platform.python_version(),
        "architecture": platform.machine(),
        "source": "in_process",
    }
    path.write_text(json.dumps(payload), encoding="utf-8")


def probe_interpreter(executable: str, runtime: str) -> dict | None:
    args = {
        "Python": ["--version"],
        "Node": ["--version"],
        "PowerShell": [
            "-NoProfile",
            "-NonInteractive",
            "-Command",
            "$PSVersionTable.PSVersion.ToString()",
        ],
    }
    if runtime not in args or not Path(executable).is_file():
        return None
    try:
        process = subprocess.run(
            [executable, *args[runtime]], capture_output=True, text=True, timeout=5, check=True
        )
        version = process.stdout.strip().removeprefix("Python ").removeprefix("v")
        if not version or len(version) > 100:
            return None
        return {
            "runtime": runtime,
            "version": version,
            "architecture": "unknown",
            "source": "explicit_probe",
        }
    except (OSError, ValueError, subprocess.SubprocessError):
        return None


def validate_environment_config(value):
    if value is None:
        return None
    if not isinstance(value, dict) or value.get("mode") not in {"in_process", "explicit_probe"}:
        raise ValueError("application_environment_config_invalid")
    if value["mode"] == "in_process":
        if set(value) != {"mode"}:
            raise ValueError("application_environment_config_invalid")
    elif (
        set(value) != {"mode", "runtime", "executable"}
        or value["runtime"] not in {"Python", "Node", "PowerShell"}
        or not isinstance(value["executable"], str)
        or not Path(value["executable"]).is_absolute()
    ):
        raise ValueError("application_environment_config_invalid")
    return value


def application_facts(config, path: Path, *, run_key: str):
    value = validate_environment_config(config)
    actual = read_application_environment(path, run_key=run_key)
    if actual is not None:
        return actual
    if value and value["mode"] == "explicit_probe":
        return probe_interpreter(value["executable"], value["runtime"])
    return None


def environment_config_digest(config):
    import hashlib

    return hashlib.sha256(
        json.dumps(validate_environment_config(config), sort_keys=True).encode()
    ).hexdigest()
