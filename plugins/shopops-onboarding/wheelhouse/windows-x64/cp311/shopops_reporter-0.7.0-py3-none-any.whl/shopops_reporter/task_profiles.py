from __future__ import annotations

import hashlib
import json
from uuid import UUID, uuid4

from shopops_reporter.task_context import TaskContext, atomic_json, confined_path, file_lock, read_json


def prepare_scope(context: TaskContext, entry: str, variant: str = '') -> dict:
    """Called only after confirmation; reserve identity before the first network write."""
    if context.task_key is None:
        raise ValueError('named_task_required')
    target = confined_path(context.root, entry)
    if not target.is_file():
        raise ValueError('task_entry_missing')
    if len(variant) > 80 or any(not (c.isalnum() or c in '._-') for c in variant):
        raise ValueError('task_variant_invalid')
    workspace_path = TaskContext(context.root).file('workspace.json')
    with file_lock(TaskContext(context.root).file('workspace.lock')):
        if workspace_path.exists():
            workspace = read_json(workspace_path)
            if not isinstance(workspace, dict) or workspace.get('version') != 1:
                raise ValueError('workspace_state_invalid_preserve_for_recovery')
            UUID(workspace['workspace_key'])
        else:
            tasks_dir = context.root / '.shopops/tasks'
            if tasks_dir.is_dir() and (any(tasks_dir.glob('*/integration.yaml'))
                                      or any(tasks_dir.glob('*/identity.json'))):
                raise ValueError('workspace_state_missing_restore_required')
            from shopops_reporter.config import ProjectConfig
            default = TaskContext(context.root)
            key = (ProjectConfig.load(context.root).project_key
                   if default.config_path.exists() else str(uuid4()))
            workspace = {'version': 1, 'workspace_key': key}
            atomic_json(workspace_path, workspace)
    entry_key = 'sha256:' + hashlib.sha256(json.dumps(
        [entry, variant], ensure_ascii=False, separators=(',', ':'),
    ).encode()).hexdigest()
    scope = {'version': 1, 'workspace_key': workspace['workspace_key'], 'entry_key': entry_key}
    reservation = context.file('identity.json')
    if reservation.exists():
        previous = read_json(reservation)
        if previous != {'version': 1, 'project_key': context.task_key, 'task_scope': scope}:
            raise ValueError('task_entry_changed_restore_or_confirm_new_task')
    else:
        atomic_json(reservation, {'version': 1, 'project_key': context.task_key, 'task_scope': scope})
    return scope
