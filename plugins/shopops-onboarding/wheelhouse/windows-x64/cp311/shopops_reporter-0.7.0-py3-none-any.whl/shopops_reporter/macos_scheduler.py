"""Read launchd schedules without executing or uploading their commands."""

from __future__ import annotations

import hashlib
import os
from pathlib import Path
import plistlib
import re
import subprocess
import sys
from xml.parsers.expat import ExpatError

from shopops_reporter.config import ProjectConfig
from shopops_reporter.project import project_fingerprint
from shopops_reporter.schedule_map import (
    load_schedule_map, mapping_hash, registered_tasks, save_schedule_map,
)
from shopops_reporter.scheduler import SchedulerScanResult


def launchd_key(domain: str, label: str) -> str:
    return 'sha256:' + hashlib.sha256(f'macos\0{domain}\0{label}'.encode()).hexdigest()


def local_timezone() -> str:
    zone = os.environ.get('TZ')
    if zone:
        from zoneinfo import ZoneInfo
        ZoneInfo(zone)
        return zone
    target = str(Path('/etc/localtime').resolve())
    if '/zoneinfo/' in target:
        return target.split('/zoneinfo/', 1)[1]
    raise ValueError('timezone_unavailable')


def launchd_triggers(definition: dict) -> tuple[list[dict], str]:
    triggers, summaries = [], []
    limits = {'Month': (1, 12), 'Day': (1, 31), 'Weekday': (0, 7),
              'Hour': (0, 23), 'Minute': (0, 59)}
    calendars = definition.get('StartCalendarInterval', [])
    if isinstance(calendars, dict):
        calendars = [calendars]
    if not isinstance(calendars, list) or len(calendars) > 49:
        raise ValueError('invalid_calendar')
    for calendar in calendars:
        if not isinstance(calendar, dict) or set(calendar) - limits.keys():
            raise ValueError('invalid_calendar')
        for key, value in calendar.items():
            low, high = limits[key]
            if type(value) is not int or not low <= value <= high:
                raise ValueError('invalid_calendar')
        triggers.append({'kind': 'launchd_calendar', 'calendar': calendar})
        day = []
        if 'Month' in calendar:
            day.append(f"{calendar['Month']} 月")
        if 'Day' in calendar:
            day.append(f"{calendar['Day']} 日")
        if 'Weekday' in calendar:
            day.append('周' + '日一二三四五六'[calendar['Weekday'] % 7])
        hour, minute = calendar.get('Hour'), calendar.get('Minute')
        clock = (f'{hour:02d}:{minute:02d}' if hour is not None and minute is not None
                 else f'{hour:02d} 时每分钟' if hour is not None
                 else f'每小时第 {minute:02d} 分钟' if minute is not None else '每分钟')
        summaries.append(' '.join(day or ['每天']) + ' ' + clock)
    if 'StartInterval' in definition:
        seconds = definition['StartInterval']
        if type(seconds) is not int or seconds <= 0:
            raise ValueError('invalid_interval')
        triggers.append({'kind': 'launchd_interval', 'seconds': seconds})
        summaries.append(f'每 {seconds // 60} 分钟' if seconds % 60 == 0 else f'每 {seconds} 秒')
    return triggers, '；'.join(summaries)[:450]


def definition_hash(definition: dict, triggers: list[dict], timezone: str) -> str:
    # Hash action identity locally so a changed wrapper requires another mapping.
    fields = ('Program', 'ProgramArguments', 'WorkingDirectory', 'EnvironmentVariables',
              'Disabled', 'RunAtLoad', 'KeepAlive')
    return mapping_hash({'triggers': triggers, 'timezone': timezone,
                         'action': {key: definition.get(key) for key in fields}})


def action_script(definition: dict) -> Path | None:
    """Recognize the executed script slot, never a path in arbitrary arguments."""
    args = definition.get('ProgramArguments', [])
    if not isinstance(args, list) or any(not isinstance(arg, str) for arg in args):
        raise ValueError('invalid_arguments')
    program = definition.get('Program') or (args[0] if args else None)
    if not isinstance(program, str):
        return None
    argv = [program, *args[1:]]
    if Path(program).name == 'caffeinate':
        argv = argv[1:]
        while argv and argv[0].startswith('-'):
            flag = argv.pop(0)
            if flag in {'-t', '-w'}:
                if not argv or not argv.pop(0).isdigit():
                    return None
            elif not set(flag[1:]) <= set('dimsu'):
                return None
    if not argv:
        return None
    executable = Path(argv[0]).name
    script = argv[0]
    if executable in {'sh', 'bash', 'zsh'} or re.fullmatch(r'python(?:\d+(?:\.\d+)*)?', executable):
        args = argv[1:]
        allowed = {'-u', '-B', '-I', '-E', '-s', '-S', '-O', '-OO'} if executable.startswith('python') else set()
        while args and args[0].startswith('-'):
            flag = args.pop(0)
            if flag == '--':
                break
            if flag not in allowed:
                return None
        if not args:
            return None
        script = args[0]
    elif Path(script).suffix not in {'.py', '.sh', '.command'}:
        return None
    path = Path(script)
    if not path.is_absolute():
        cwd = definition.get('WorkingDirectory')
        if not isinstance(cwd, str) or not Path(cwd).is_absolute():
            return None
        path = Path(cwd) / path
    return path.resolve()


class MacOSLaunchdScheduler:
    def __init__(self, *, roots=None, runner=None, tasks=None, timezone=None):
        user_domain = f'gui/{os.getuid()}'
        self.roots = roots if roots is not None else [
            (Path.home() / 'Library/LaunchAgents', user_domain),
            (Path('/Library/LaunchAgents'), user_domain),
            (Path('/Library/LaunchDaemons'), 'system'),
        ]
        self.runner = runner or subprocess.run
        self.tasks = tasks or registered_tasks
        self.timezone = timezone or local_timezone

    def definitions(self):
        entries, failed = [], False
        for root, domain in self.roots:
            try:
                paths = list(root.iterdir())
            except FileNotFoundError:
                continue
            except OSError:
                failed = True
                continue
            for path in paths:
                if path.suffix != '.plist':
                    continue
                try:
                    if not path.resolve().is_relative_to(root.resolve()) or path.stat().st_size > 1_048_576:
                        raise ValueError('invalid_plist')
                    with path.open('rb') as stream:
                        definition = plistlib.load(stream)
                    if not isinstance(definition, dict):
                        raise ValueError('invalid_plist')
                    triggers, summary = launchd_triggers(definition)
                    if not triggers:
                        continue
                    label = definition.get('Label')
                    if not isinstance(label, str) or not label or len(label) > 200 or '/' in label:
                        raise ValueError('invalid_label')
                    entries.append((domain, label, definition, triggers, summary))
                except (OSError, ValueError, plistlib.InvalidFileException, ExpatError):
                    failed = True
        return entries, failed

    def _query(self, *arguments):
        return self.runner(['/bin/launchctl', *arguments], capture_output=True, text=True,
                           timeout=10, check=False)

    def _status(self, domain, label, definition, overrides):
        result = self._query('print', f'{domain}/{label}')
        enabled = not overrides.get(label, bool(definition.get('Disabled', False)))
        if result.returncode:
            if 'Could not find service' not in result.stderr:
                raise ValueError('launchctl_failed')
            return enabled, 'unloaded', None
        state = re.search(r'^\s*state = ([^\n]+)', result.stdout, re.M)
        code = re.search(r'^\s*last exit code = (-?\d+)\s*$', result.stdout, re.M)
        return enabled, ('running' if state and state[1] == 'running' else 'ready'), (
            int(code[1]) if code else None)

    def _projects(self, entry, contexts, digest):
        domain, label, definition, _, _ = entry
        key = launchd_key(domain, label)
        explicit, candidates, exact = [], [], []
        script = action_script(definition)
        cwd = definition.get('WorkingDirectory')
        for context, config, fingerprint, mappings in contexts:
            for item in mappings:
                if item['schedule_key'] != key:
                    continue
                if (item['project_fingerprint'] != fingerprint
                        or item.get('integration_id') != config.integration_id
                        or item.get('definition_hash') != digest):
                    raise ValueError('schedule_mapping_changed')
                explicit.append((config, fingerprint, item['accepted'], item['expected_on_each_run']))
            if context.file('run.command').resolve() == script:
                exact.append((config, fingerprint, False, False))
            elif script is not None and not config.task_key and (
                (isinstance(cwd, str) and Path(cwd).resolve() == context.root.resolve())
                or script.is_relative_to(context.root.resolve())
            ):
                candidates.append((config, fingerprint, False, False))
        selected = explicit or exact or candidates
        if (not explicit and len(selected) > 1) or len({p[1] for p in selected}) != len(selected):
            raise ValueError('schedule_mapping_ambiguous')
        return [{'project_key': config.project_key, 'integration_id': config.integration_id,
                 'project_fingerprint': fingerprint, 'source': 'declared' if accepted else 'observed',
                 'expected_on_each_run': expected, 'mapping_hash': None}
                for config, fingerprint, accepted, expected in selected]

    def scan(self) -> SchedulerScanResult:
        entries, failed = self.definitions()
        tasks, contexts, overrides, seen = [], [], {}, set()
        try:
            timezone = self.timezone()
            for context in self.tasks():
                config = ProjectConfig.load(context.root, task_key=context.task_key)
                if not config.integration_id:
                    continue
                contexts.append((context, config, project_fingerprint(context.root, config=config),
                                 load_schedule_map(context.root, task_key=context.task_key)['mappings']))
        except (OSError, ValueError, RuntimeError, KeyError):
            return SchedulerScanResult([], False, '无法读取已接入项目或时区', 'scan_failed')
        for entry in entries:
            domain, label, definition, triggers, summary = entry
            try:
                digest = definition_hash(definition, triggers, timezone)
                projects = self._projects(entry, contexts, digest)
                if not projects:
                    continue
                key = launchd_key(domain, label)
                if key in seen:
                    raise ValueError('duplicate_label')
                seen.add(key)
                if domain not in overrides:
                    result = self._query('print-disabled', domain)
                    if result.returncode:
                        raise ValueError('launchctl_failed')
                    overrides[domain] = {name: value == 'true' for name, value in
                                         re.findall(r'"([^"\n]+)"\s*=>\s*(true|false)', result.stdout)}
                enabled, state, last_result = self._status(domain, label, definition, overrides[domain])
                association_hash = mapping_hash([{k: p[k] for k in
                    ('project_key', 'integration_id', 'project_fingerprint')} for p in projects])
                for project in projects:
                    project['mapping_hash'] = association_hash
                tasks.append({
                    'schedule_key': key, 'task_name': label,
                    'redacted_task_path': 'macOS/' + ('system' if domain == 'system' else 'user'),
                    'trigger_summary': summary, 'triggers': triggers, 'timezone': timezone,
                    'enabled': enabled, 'scheduler_state': state, 'last_task_result': last_result,
                    'last_run_at': None, 'next_run_at': None, 'definition_hash': digest,
                    'mapping_hash': association_hash, 'projects': projects,
                })
            except (OSError, ValueError, subprocess.SubprocessError):
                failed = True
        if len(tasks) > 500:
            tasks, failed = tasks[:500], True
        return SchedulerScanResult(tasks, not failed, '部分计划无法读取或关联，请检查本机映射' if failed else None,
                                   'scan_failed' if failed else None)


def declare_launchd_mapping(project_dir, label, *, task_key=None, domain=None, scanner=None):
    if sys.platform != 'darwin' and scanner is None:
        raise ValueError('map-schedule 仅适用于 macOS launchd')
    scanner = scanner or MacOSLaunchdScheduler()
    entries, _ = scanner.definitions()
    matches = [entry for entry in entries if entry[1] == label and (domain is None or entry[0] == domain)]
    if len(matches) != 1:
        raise ValueError('计划不存在或 Label 不唯一；请用 --domain 指定 launchd 域')
    entry = matches[0]
    config = ProjectConfig.load(project_dir, task_key=task_key)
    if not config.integration_id:
        raise ValueError('项目尚未接入')
    key = launchd_key(entry[0], label)
    digest = definition_hash(entry[2], entry[3], scanner.timezone())
    payload = load_schedule_map(project_dir, task_key=task_key)
    payload['mappings'] = [item for item in payload['mappings'] if item['schedule_key'] != key]
    payload['mappings'].append({'schedule_key': key, 'task_name': label,
        'project_fingerprint': project_fingerprint(project_dir, config=config),
        'integration_id': config.integration_id, 'definition_hash': digest, 'accepted': False,
        'expected_on_each_run': False})
    path = save_schedule_map(project_dir, payload, task_key=task_key)
    return {'schedule_key': key, 'mapping_path': str(path), 'status': 'pending_confirmation'}
