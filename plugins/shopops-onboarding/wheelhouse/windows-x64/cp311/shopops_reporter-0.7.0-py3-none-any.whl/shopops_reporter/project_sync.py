"""Sync declared project metadata independently of business runs."""

from __future__ import annotations

from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path
import tempfile
import time
from typing import Any, Callable

from shopops_reporter import __version__
from shopops_reporter.client import ReporterApiError, ReporterClient
from shopops_reporter.config import ProjectConfig, reporter_home
from shopops_reporter.project import project_fingerprint, redact_command
from shopops_reporter.schedule_map import registered_tasks
from shopops_reporter.task_context import TaskContext


def request_project_sync() -> None:
    marker = reporter_home() / "project-sync.requested"
    marker.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    marker.touch(mode=0o600)


def requested_sync_time() -> float:
    try:
        return (reporter_home() / "project-sync.requested").stat().st_mtime
    except OSError:
        return 0.0


def status_path(project_dir: Path, *, task_key: str | None = None) -> Path:
    source = str(project_dir.resolve()) + (f':{task_key}' if task_key else '')
    key = hashlib.sha256(source.encode()).hexdigest()
    return reporter_home() / "project-sync" / f"{key}.json"


def read_sync_status(project_dir: Path, *, task_key: str | None = None) -> dict[str, Any]:
    try:
        value = json.loads(status_path(project_dir, task_key=task_key).read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_status(project_dir: Path, value: dict[str, Any], *, task_key: str | None = None) -> None:
    target = status_path(project_dir, task_key=task_key)
    target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temporary = tempfile.mkstemp(prefix="sync-", dir=target.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False)
        os.replace(temporary, target)
    finally:
        Path(temporary).unlink(missing_ok=True)


def project_profile(project_dir: Path, config: ProjectConfig) -> dict[str, Any]:
    # Optional reporting metadata must not prevent the original script from starting.
    if not isinstance(config.run_mode, str) or config.run_mode not in {"unknown", "manual", "scheduled"}:
        raise ValueError("invalid_run_mode")
    for name, limit in (("description", 2000), ("project_version", 100)):
        value = getattr(config, name)
        if value is not None and (not isinstance(value, str) or len(value) > limit):
            raise ValueError(f"invalid_{name}")
    return {
        "name": config.display_name, "description": config.description,
        "project_version": config.project_version, "platform": config.platform,
        "command_summary": redact_command(config.command),
        "project_fingerprint": project_fingerprint(project_dir, config=config), "run_mode": config.run_mode,
    }


class ProjectSynchronizer:
    def __init__(
        self, client: ReporterClient,
        *, projects: Callable[[], list[Path | TaskContext]] = registered_tasks,
    ):
        self.client = client
        self.projects = projects
        self.digests: dict[str, str] = {}
        self.capabilities: dict[str, Any] | None = None
        self.next_capability_check = 0.0

    def _supported(self) -> bool:
        if self.capabilities is not None and time.monotonic() < self.next_capability_check:
            return self.capabilities.get("project_sync") == 1
        try:
            self.capabilities = self.client.signed_get("/reporter/v1/capabilities")
        except ReporterApiError as error:
            if error.status_code not in {404, 405}:
                raise
            self.capabilities = {}
        self.next_capability_check = time.monotonic() + 300
        return self.capabilities.get("project_sync") == 1

    def sync_one(self, project_dir: Path, scan: dict[str, Any] | None = None, *, task_key: str | None = None) -> bool:
        previous = read_sync_status(project_dir, task_key=task_key)
        def save(value):
            _save_status(project_dir, value, task_key=task_key)
        try:
            config = ProjectConfig.load(project_dir, task_key=task_key)
            if not self._supported() or (task_key and self.capabilities.get('task_profiles') != 1):
                save({**previous, "sync_state": "unsupported_server"})
                return False
            status_url = f"/reporter/v1/projects/{config.integration_id}/status"
            result = self.client.signed_get(status_url)
            if result.get("binding_status") == "pending_migration":
                save({
                    "sync_state": "pending_migration", "binding_status": "pending_migration",
                    "project": result.get("project"),
                })
                return False
            profile = project_profile(project_dir, config)
            if 2 in (self.capabilities or {}).get('project_verification_versions', []):
                from shopops_reporter.runtime_probe import environment_config_digest
                profile['application_environment_digest'] = environment_config_digest(config.application_environment)
            digest = hashlib.sha256(json.dumps(profile, sort_keys=True).encode()).hexdigest()
            cache_key = f"{config.integration_id}:{project_dir.resolve()}"
            now = datetime.now(UTC).isoformat()
            payload: dict[str, Any] = {"observed_at": now, "reporter_version": __version__}
            if self.digests.get(cache_key) != digest:
                payload["profile"] = profile
            if scan is not None:
                payload["scan"] = scan
            if config.office_role is not None and 1 in (self.capabilities or {}).get("project_role_sync_versions", []):
                payload["office_role"] = config.office_role
            response = self.client.signed_json(
                "POST", f"/reporter/v1/projects/{config.integration_id}/sync", payload,
            )
            if not response.get("accepted"):
                raise RuntimeError("project_sync_not_accepted")
            self.digests[cache_key] = digest
            result = self.client.signed_get(status_url)
            save({
                "sync_state": "synced", "last_synced_at": now,
                "binding_status": result.get("binding_status"),
                "project": result.get("project"),
                "office_role": response.get("office_role"),
            })
            return True
        except Exception as error:
            # Raw exception messages may contain local paths or request credentials.
            code = f"http_{error.status_code}" if isinstance(error, ReporterApiError) else type(error).__name__
            try:
                save({**previous, "sync_state": "failed", "error_code": code})
            except OSError:
                pass
            return False

    def process_once(self, scan: dict[str, Any] | None = None) -> bool:
        try:
            projects = self.projects()
        except (OSError, ValueError):
            return False
        success = True
        for item in projects:
            context = item if isinstance(item, TaskContext) else TaskContext(item)
            success = self.sync_one(context.root, scan, task_key=context.task_key) and success
        return success
