from __future__ import annotations

import json
import os
import socket
import tempfile
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import keyring
import yaml
from keyring.errors import KeyringError

from shopops_reporter.dashboard import validate_dashboard_descriptor
from shopops_reporter.task_context import TaskContext, file_lock


KEYRING_SERVICE = "shopops-reporter"
PROJECT_CONFIG = Path(".shopops/integration.yaml")


class NotPairedError(RuntimeError):
    """The Reporter has no usable device identity yet."""


def reporter_home() -> Path:
    override = os.environ.get("SHOPOPS_REPORTER_HOME")
    if override:
        return Path(override).expanduser().resolve()
    if os.name == "nt":
        root = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData/Local"))
        return root / "ShopOps" / "Reporter"
    return Path.home() / ".shopops-reporter"


def ensure_private_directory(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    if os.name != "nt":
        path.chmod(0o700)
    return path


@dataclass(frozen=True)
class DeviceIdentity:
    server_url: str
    device_id: str
    installation_id: str
    display_name: str
    declared_operator: str | None
    private_key: str
    private_key_storage: str = "file"


class IdentityStore:
    def __init__(self, home: Path | None = None, *, create: bool = True):
        self.home = home or reporter_home()
        if create:
            self.home = ensure_private_directory(self.home)
        self.metadata_path = self.home / "device.json"
        self.fallback_key_path = self.home / "device.key"

    def exists(self) -> bool:
        return self.metadata_path.exists()

    def save(
        self,
        *,
        server_url: str,
        device_id: str,
        installation_id: str,
        display_name: str,
        declared_operator: str | None,
        private_key: str,
    ) -> DeviceIdentity:
        storage = "keyring"
        try:
            keyring.set_password(KEYRING_SERVICE, installation_id, private_key)
            if keyring.get_password(KEYRING_SERVICE, installation_id) != private_key:
                storage = "file"
        except (KeyringError, RuntimeError):
            storage = "file"
        if storage == "file":
            self.fallback_key_path.write_text(private_key, encoding="ascii")
            if os.name != "nt":
                self.fallback_key_path.chmod(0o600)
        else:
            self.fallback_key_path.unlink(missing_ok=True)
        metadata = {
            "server_url": normalize_server_url(server_url),
            "device_id": device_id,
            "installation_id": installation_id,
            "display_name": display_name,
            "declared_operator": declared_operator,
            "private_key_storage": storage,
        }
        self.metadata_path.write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        if os.name != "nt":
            self.metadata_path.chmod(0o600)
        return self.load()

    def load(self) -> DeviceIdentity:
        if not self.metadata_path.exists():
            raise NotPairedError("Reporter 尚未配对，请先执行 shopops-report enroll")
        metadata = json.loads(self.metadata_path.read_text(encoding="utf-8"))
        private_key: str | None = None
        if metadata.get("private_key_storage") == "keyring":
            try:
                private_key = keyring.get_password(
                    KEYRING_SERVICE,
                    metadata["installation_id"],
                )
            except (KeyringError, RuntimeError):
                private_key = None
        if private_key is None and self.fallback_key_path.exists():
            private_key = self.fallback_key_path.read_text(encoding="ascii").strip()
        if not private_key:
            raise RuntimeError("Reporter 设备私钥不可用，请重新配对")
        return DeviceIdentity(private_key=private_key, **metadata)


@dataclass
class ProjectConfig:
    version: int
    project_key: str
    integration_id: str
    display_name: str
    platform: str
    working_directory: str
    command: list[str]
    initial_discovery_fingerprint: str
    descriptor: dict[str, Any]
    descriptor_signature: str
    artifacts: list[str] = field(default_factory=list)
    html_reports: list[str] = field(default_factory=list)
    result_json: str | None = None
    dashboard: dict[str, Any] | None = None
    office_role: dict[str, Any] | None = None
    application_environment: dict[str, Any] | None = None
    diagnostics: dict[str, Any] | None = None
    ai_readable_artifacts: list[str] = field(default_factory=list)
    result_contract: dict[str, Any] | None = None
    description: str | None = None
    project_version: str | None = None
    run_mode: str = "unknown"
    fingerprint: dict[str, Any] | None = None
    task_key: str | None = None
    task_scope: dict[str, Any] | None = None

    @classmethod
    def load(cls, project_dir: Path, *, task_key: str | None = None) -> "ProjectConfig":
        context = TaskContext(project_dir, task_key)
        path = context.config_path
        if not path.exists():
            raise RuntimeError(f"未找到 {PROJECT_CONFIG}，请先执行 shopops-report init")
        payload = yaml.safe_load(path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise RuntimeError(f"{PROJECT_CONFIG} 格式无效")
        config = cls(**payload)
        from shopops_reporter.runtime_probe import validate_environment_config
        validate_environment_config(config.application_environment)
        if config.task_key != task_key:
            raise ValueError('task_configuration_identity_mismatch')
        if config.dashboard is not None:
            config.dashboard = validate_dashboard_descriptor(config.dashboard)
        return config

    def save(self, project_dir: Path) -> Path:
        context = TaskContext(project_dir, self.task_key)
        with file_lock(context.file('config.lock')):
            return self._save(context.config_path)

    def _save(self, path: Path) -> Path:
        ensure_private_directory(path.parent)
        payload = asdict(self)
        for key in ('task_key', 'task_scope'):
            if payload[key] is None:
                payload.pop(key)
        serialized = yaml.safe_dump(payload, allow_unicode=True, sort_keys=False)
        temporary: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w", encoding="utf-8", dir=path.parent, prefix="integration-",
                suffix=".tmp", delete=False,
            ) as handle:
                temporary = Path(handle.name)
                handle.write(serialized)
                handle.flush()
                os.fsync(handle.fileno())
            temporary.replace(path)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
        return path

    def resolved_working_directory(self, project_dir: Path) -> Path:
        return (project_dir / self.working_directory).resolve()


def find_project_dir(start: Path | None = None, *, task_key: str | None = None) -> Path:
    current = (start or Path.cwd()).resolve()
    for candidate in (current, *current.parents):
        context = TaskContext(candidate, task_key)
        if context.config_path.is_file():
            return candidate
        if task_key is None and (candidate / '.shopops/tasks').is_dir():
            raise RuntimeError('task_selection_required: 请使用 --task 选择具名任务')
    raise RuntimeError(f"当前目录及父目录中未找到 {PROJECT_CONFIG}")


def normalize_server_url(value: str) -> str:
    normalized = value.strip().rstrip("/")
    if not normalized.startswith(("http://", "https://")):
        raise ValueError("ShopOps 地址必须以 http:// 或 https:// 开头")
    return normalized


def default_device_name() -> str:
    return socket.gethostname() or "ShopOps Reporter"
