"""Serialize snapshot capacity decisions across Reporter processes."""

from contextlib import contextmanager
import hashlib
import json
import os
import shutil
from pathlib import Path
import time
from shopops_reporter.task_context import file_lock
from shopops_reporter.run_snapshots import SnapshotManifest, freeze_run_snapshot


@contextmanager
def storage_lock(root: Path, timeout: float = 60):
    deadline = time.monotonic() + timeout
    while True:
        lock = file_lock(root / ".storage.lock")
        try:
            lock.__enter__()
            break
        except RuntimeError:
            if time.monotonic() >= deadline:
                raise RuntimeError("snapshot_storage_busy") from None
            time.sleep(0.05)
    try:
        yield
    finally:
        lock.__exit__(None, None, None)


def validated_manifest(directory: Path):
    try:
        value = json.loads((directory / "manifest.json").read_text())
        manifest = SnapshotManifest(**value)
        if manifest.version != 1 or not isinstance(manifest.external_run_key, str):
            return None
        for item in manifest.artifacts:
            path = directory / item["path"]
            if path.is_symlink() or not path.resolve().is_relative_to(directory.resolve()):
                return None
            if (
                path.stat().st_size != item["size"]
                or hashlib.sha256(path.read_bytes()).hexdigest() != item["sha256"]
            ):
                return None
        return manifest
    except (OSError, ValueError, TypeError, KeyError):
        return None


def recover_staging(spool):
    """Called under the storage lock. Keep incomplete, unacknowledged evidence."""
    for directory in spool.snapshots_dir.glob(".snapshot-*"):
        if not directory.is_dir() or directory.is_symlink():
            continue
        manifest = validated_manifest(directory)
        if manifest is None:
            try:
                owner = json.loads((directory / "owner.json").read_text())
                run = spool.get_run(owner["external_run_key"])
                if run and run["upload_state"] == "complete" and run["acknowledged_at"]:
                    shutil.rmtree(directory)
            except (OSError, ValueError, KeyError, TypeError):
                pass
            continue
        run = spool.get_run(manifest.external_run_key)
        if run is None:
            continue
        target = (
            spool.snapshots_dir / hashlib.sha256(manifest.external_run_key.encode()).hexdigest()
        )
        if not target.exists():
            os.rename(directory, target)
        elif run["upload_state"] == "complete" and run["acknowledged_at"]:
            shutil.rmtree(directory)


def freeze_spool_snapshot(spool, *, run_key, inputs, diagnostics, warnings):
    root = spool.snapshots_dir
    target = root / hashlib.sha256(run_key.encode()).hexdigest()
    with storage_lock(root):
        recover_staging(spool)
        if target.exists():
            existing = validated_manifest(target)
            if existing and existing.external_run_key == run_key:
                return existing
            raise ValueError("run_snapshot_invalid")
        spool.cleanup_snapshots()
        if spool._storage_bytes() >= spool.max_bytes:
            spool.cleanup_snapshots(capacity_pressure=True)
        return freeze_run_snapshot(
            run_key=run_key,
            run_dir=target,
            inputs=inputs,
            diagnostics=diagnostics,
            warnings=warnings,
            max_bytes=max(0, spool.max_bytes - spool._storage_bytes()),
        )
