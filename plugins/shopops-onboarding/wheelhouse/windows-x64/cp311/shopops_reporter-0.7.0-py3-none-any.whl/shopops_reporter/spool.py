from __future__ import annotations

import json
import shutil
import sqlite3
import tempfile
import time
from contextlib import closing, contextmanager
from dataclasses import asdict
from pathlib import Path
from typing import Any, Iterator

from shopops_reporter.config import ProjectConfig, ensure_private_directory, reporter_home


SCHEMA = """
CREATE TABLE IF NOT EXISTS local_run (
    local_run_key TEXT PRIMARY KEY,
    integration_id TEXT NOT NULL,
    project_dir TEXT NOT NULL,
    config_json TEXT NOT NULL,
    project_fingerprint TEXT NOT NULL,
    git_json TEXT NOT NULL,
    environment_json TEXT NOT NULL,
    started_at TEXT NOT NULL,
    local_status TEXT NOT NULL DEFAULT 'running',
    ended_at TEXT,
    exit_code INTEGER,
    result_json TEXT NOT NULL DEFAULT '{}',
    result_warnings_json TEXT NOT NULL DEFAULT '[]',
    server_run_id TEXT,
    last_uploaded_sequence INTEGER NOT NULL DEFAULT 0,
    next_sequence INTEGER NOT NULL DEFAULT 1,
    last_heartbeat_at REAL,
    upload_state TEXT NOT NULL DEFAULT 'pending',
    retry_at REAL NOT NULL DEFAULT 0,
    retry_count INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    live_report_token TEXT,
    live_report_path TEXT,
    windows_task_key TEXT,
    windows_task_path TEXT,
    trigger_instance_id TEXT,
    trigger_kind TEXT,
    logs_partial INTEGER NOT NULL DEFAULT 0,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS local_log (
    local_run_key TEXT NOT NULL,
    sequence INTEGER NOT NULL,
    timestamp TEXT NOT NULL,
    stream TEXT NOT NULL,
    level TEXT,
    message TEXT NOT NULL,
    PRIMARY KEY (local_run_key, sequence),
    FOREIGN KEY (local_run_key) REFERENCES local_run(local_run_key) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS local_artifact (
    local_run_key TEXT NOT NULL,
    artifact_key TEXT NOT NULL,
    path TEXT NOT NULL,
    display_name TEXT NOT NULL,
    artifact_type TEXT NOT NULL,
    sha256 TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    last_error TEXT,
    PRIMARY KEY (local_run_key, artifact_key),
    FOREIGN KEY (local_run_key) REFERENCES local_run(local_run_key) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS ix_local_run_pending
ON local_run(upload_state, retry_at, created_at);
"""


class Spool:
    def __init__(self, path: Path | None = None, *, max_bytes: int = 500 * 1024 * 1024):
        home = ensure_private_directory((path or reporter_home() / "spool.db").parent)
        self.path = path or home / "spool.db"
        self.max_bytes = max_bytes
        self.initialize()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path, timeout=15)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA busy_timeout=15000")
        try:
            yield connection
        finally:
            connection.close()

    def initialize(self) -> None:
        with self.connect() as connection:
            connection.execute("PRAGMA journal_mode=WAL")
            connection.executescript(SCHEMA)
            columns = {
                row["name"]
                for row in connection.execute("PRAGMA table_info(local_run)").fetchall()
            }
            if "logs_partial" not in columns:
                connection.execute(
                    "ALTER TABLE local_run ADD COLUMN logs_partial INTEGER NOT NULL DEFAULT 0"
                )
            if "result_warnings_json" not in columns:
                connection.execute(
                    "ALTER TABLE local_run ADD COLUMN result_warnings_json TEXT NOT NULL DEFAULT '[]'"
                )
            for column in ("schedule_context_json", "run_purpose", "snapshot_json", "snapshot_dir", "completion_json", "acknowledged_at", "windows_task_key", "windows_task_path", "trigger_instance_id", "trigger_kind"):
                if column not in columns:
                    connection.execute(f"ALTER TABLE local_run ADD COLUMN {column} TEXT")
            connection.commit()

    def create_run(
        self,
        *,
        local_run_key: str,
        config: ProjectConfig,
        project_dir: Path,
        project_fingerprint: str,
        git_metadata: dict[str, Any],
        environment_metadata: dict[str, Any],
        started_at: str,
        schedule_context: dict | None = None,
        run_purpose: str = "business",
        windows_task_key: str | None = None,
        windows_task_path: str | None = None,
        trigger_instance_id: str | None = None,
        trigger_kind: str | None = None,
    ) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                INSERT INTO local_run (
                    local_run_key, integration_id, project_dir, config_json,
                    project_fingerprint, git_json, environment_json, started_at,
                    windows_task_key, windows_task_path, trigger_instance_id, trigger_kind,
                    created_at, run_purpose, schedule_context_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    local_run_key,
                    config.integration_id,
                    str(project_dir),
                    json.dumps(asdict(config), ensure_ascii=False),
                    project_fingerprint,
                    json.dumps(git_metadata, ensure_ascii=False),
                    json.dumps(environment_metadata, ensure_ascii=False),
                    started_at,
                    windows_task_key,
                    windows_task_path,
                    trigger_instance_id,
                    trigger_kind,
                    time.time(),
                    run_purpose,
                    json.dumps(schedule_context) if schedule_context else None,
                ),
            )
            connection.commit()

    def append_log(
        self,
        local_run_key: str,
        *,
        timestamp: str,
        stream: str,
        message: str,
        level: str | None = None,
    ) -> int:
        if self._storage_bytes() >= self.max_bytes:
            with self.connect() as connection:
                connection.execute(
                    "UPDATE local_run SET logs_partial = 1 WHERE local_run_key = ?",
                    (local_run_key,),
                )
                connection.commit()
            return 0
        with self.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT next_sequence FROM local_run WHERE local_run_key = ?",
                (local_run_key,),
            ).fetchone()
            if row is None:
                connection.rollback()
                raise RuntimeError(f"本地 Run 不存在: {local_run_key}")
            sequence = int(row["next_sequence"])
            connection.execute(
                """
                INSERT INTO local_log (
                    local_run_key, sequence, timestamp, stream, level, message
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (local_run_key, sequence, timestamp, stream, level, message),
            )
            connection.execute(
                "UPDATE local_run SET next_sequence = ? WHERE local_run_key = ?",
                (sequence + 1, local_run_key),
            )
            connection.commit()
            return sequence

    def finish_run(
        self,
        local_run_key: str,
        *,
        status: str,
        exit_code: int,
        ended_at: str,
        result: dict[str, Any],
        result_warnings: list[str] | tuple[str, ...] = (),
        live_report_token: str | None = None,
        live_report_path: Path | None = None,
        snapshot: dict | None = None,
        snapshot_dir: Path | None = None,
    ) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                UPDATE local_run
                SET local_status = ?, exit_code = ?, ended_at = ?, result_json = ?,
                    result_warnings_json = ?,
                    live_report_token = ?, live_report_path = ?, snapshot_json = ?, snapshot_dir = ?, retry_at = 0
                WHERE local_run_key = ?
                """,
                (
                    status,
                    exit_code,
                    ended_at,
                    json.dumps(result, ensure_ascii=False),
                    json.dumps(list(result_warnings), ensure_ascii=False),
                    live_report_token,
                    str(live_report_path) if live_report_path else None,
                    json.dumps(snapshot, ensure_ascii=False) if snapshot is not None else None,
                    str(snapshot_dir) if snapshot_dir else None,
                    local_run_key,
                ),
            )
            if snapshot is not None and snapshot_dir is not None:
                for artifact in snapshot.get("artifacts", []):
                    if artifact["key"] == "live-report":
                        continue
                    path = snapshot_dir / artifact["path"]
                    connection.execute("""INSERT OR IGNORE INTO local_artifact
                        (local_run_key, artifact_key, path, display_name, artifact_type, sha256)
                        VALUES (?, ?, ?, ?, ?, ?)""",
                        (local_run_key, artifact["key"], str(path), path.name, artifact["kind"], artifact["sha256"]))
            connection.commit()

    def update_runtime_facts(self, local_run_key: str, facts: dict) -> None:
        with self.connect() as connection:
            row = connection.execute("SELECT environment_json FROM local_run WHERE local_run_key = ?", (local_run_key,)).fetchone()
            if row:
                value = {**json.loads(row[0]), **facts}
                connection.execute("UPDATE local_run SET environment_json = ? WHERE local_run_key = ?", (json.dumps(value), local_run_key))
                connection.commit()

    def freeze_completion(self, local_run_key: str, payload: dict) -> dict:
        with self.connect() as connection:
            connection.execute("UPDATE local_run SET completion_json = COALESCE(completion_json, ?) WHERE local_run_key = ?",
                               (json.dumps(payload, ensure_ascii=False), local_run_key))
            row = connection.execute("SELECT completion_json FROM local_run WHERE local_run_key = ?", (local_run_key,)).fetchone()
            connection.commit()
        return json.loads(row[0])

    def pending_runs(self, limit: int = 20) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute(
                """
                SELECT * FROM local_run
                WHERE upload_state != 'complete' AND retry_at <= ?
                ORDER BY created_at
                LIMIT ?
                """,
                (time.time(), limit),
            ).fetchall()
        return [dict(row) for row in rows]

    def get_run(self, local_run_key: str) -> dict[str, Any] | None:
        with self.connect() as connection:
            row = connection.execute(
                "SELECT * FROM local_run WHERE local_run_key = ?",
                (local_run_key,),
            ).fetchone()
        return dict(row) if row else None

    def set_server_run(self, local_run_key: str, server_run_id: str) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                UPDATE local_run
                SET server_run_id = ?, retry_count = 0, retry_at = 0, last_error = NULL
                WHERE local_run_key = ?
                """,
                (server_run_id, local_run_key),
            )
            connection.commit()

    def log_batch(self, local_run_key: str, after: int, limit: int = 100) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute(
                """
                SELECT sequence, timestamp, stream, level, message
                FROM local_log
                WHERE local_run_key = ? AND sequence > ?
                ORDER BY sequence
                LIMIT ?
                """,
                (local_run_key, after, limit),
            ).fetchall()
        return [dict(row) for row in rows]

    def recent_diagnostic_logs(
        self,
        local_run_key: str,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute(
                """
                SELECT sequence, timestamp, stream, level, message
                FROM local_log
                WHERE local_run_key = ?
                ORDER BY sequence DESC
                LIMIT ?
                """,
                (local_run_key, limit),
            ).fetchall()
        return [dict(row) for row in reversed(rows)]

    def acknowledge_logs(self, local_run_key: str, sequence: int) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                UPDATE local_run
                SET last_uploaded_sequence = MAX(last_uploaded_sequence, ?),
                    retry_count = 0, retry_at = 0, last_error = NULL
                WHERE local_run_key = ?
                """,
                (sequence, local_run_key),
            )
            connection.commit()

    def heartbeat_sent(self, local_run_key: str) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                UPDATE local_run
                SET last_heartbeat_at = ?, retry_count = 0, retry_at = 0, last_error = NULL
                WHERE local_run_key = ?
                """,
                (time.time(), local_run_key),
            )
            connection.commit()

    def complete_upload(self, local_run_key: str) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                UPDATE local_run
                SET upload_state = 'complete', acknowledged_at = strftime('%s','now'), retry_count = 0,
                    retry_at = 0, last_error = NULL
                WHERE local_run_key = ?
                """,
                (local_run_key,),
            )
            connection.commit()

    def record_error(self, local_run_key: str, error: Exception) -> None:
        with self.connect() as connection:
            row = connection.execute(
                "SELECT retry_count FROM local_run WHERE local_run_key = ?",
                (local_run_key,),
            ).fetchone()
            count = (int(row["retry_count"]) if row else 0) + 1
            delay = min(60.0, 2 ** min(count, 6))
            connection.execute(
                """
                UPDATE local_run
                SET retry_count = ?, retry_at = ?, last_error = ?
                WHERE local_run_key = ?
                """,
                (count, time.time() + delay, str(error)[:1000], local_run_key),
            )
            connection.commit()

    def add_artifact(
        self,
        local_run_key: str,
        *,
        artifact_key: str,
        path: Path,
        artifact_type: str,
        sha256: str,
    ) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                INSERT OR IGNORE INTO local_artifact (
                    local_run_key, artifact_key, path, display_name,
                    artifact_type, sha256
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    local_run_key,
                    artifact_key,
                    str(path),
                    path.name,
                    artifact_type,
                    sha256,
                ),
            )
            connection.commit()

    def pending_artifacts(self, local_run_key: str) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute(
                """
                SELECT * FROM local_artifact
                WHERE local_run_key = ? AND status = 'pending'
                ORDER BY artifact_key
                """,
                (local_run_key,),
            ).fetchall()
        return [dict(row) for row in rows]

    def artifact_finished(
        self,
        local_run_key: str,
        artifact_key: str,
        *,
        accepted: bool,
        error: str | None = None,
    ) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                UPDATE local_artifact SET status = ?, last_error = ?
                WHERE local_run_key = ? AND artifact_key = ?
                """,
                ("uploaded" if accepted else "failed", error, local_run_key, artifact_key),
            )
            connection.commit()

    def artifact_incomplete(self, local_run_key: str) -> bool:
        with self.connect() as connection:
            row = connection.execute(
                """
                SELECT COUNT(*) AS total FROM local_artifact
                WHERE local_run_key = ? AND status = 'failed'
                """,
                (local_run_key,),
            ).fetchone()
        return bool(row and row["total"])

    def queue_summary(self) -> dict[str, int]:
        with self.connect() as connection:
            runs = connection.execute(
                "SELECT COUNT(*) FROM local_run WHERE upload_state != 'complete'"
            ).fetchone()[0]
            logs = connection.execute(
                """
                SELECT COUNT(*) FROM local_log l
                JOIN local_run r ON r.local_run_key = l.local_run_key
                WHERE l.sequence > r.last_uploaded_sequence
                """
            ).fetchone()[0]
        return {"pending_runs": int(runs), "pending_logs": int(logs)}

    @staticmethod
    def queue_summary_read_only(path: Path | None = None) -> dict[str, int]:
        spool_path = path or reporter_home() / "spool.db"
        if not spool_path.is_file():
            return {"pending_runs": 0, "pending_logs": 0}
        source_wal = spool_path.with_name(f"{spool_path.name}-wal")
        with tempfile.TemporaryDirectory(prefix="shopops-reporter-status-") as temporary:
            for attempt in range(3):
                snapshot = Path(temporary) / str(attempt) / "spool.db"
                snapshot.parent.mkdir()
                shutil.copyfile(spool_path, snapshot)
                try:
                    if source_wal.is_file():
                        shutil.copyfile(source_wal, snapshot.with_name("spool.db-wal"))
                except FileNotFoundError:
                    continue
                try:
                    with closing(sqlite3.connect(snapshot, timeout=15)) as connection:
                        runs = connection.execute(
                            "SELECT COUNT(*) FROM local_run WHERE upload_state != 'complete'"
                        ).fetchone()[0]
                        logs = connection.execute(
                            """
                            SELECT COUNT(*) FROM local_log l
                            JOIN local_run r ON r.local_run_key = l.local_run_key
                            WHERE l.sequence > r.last_uploaded_sequence
                            """
                        ).fetchone()[0]
                except sqlite3.DatabaseError:
                    if attempt < 2:
                        continue
                    raise
                return {"pending_runs": int(runs), "pending_logs": int(logs)}
        raise RuntimeError("无法读取 Reporter 本地队列快照")

    def has_pending(self) -> bool:
        return self.queue_summary()["pending_runs"] > 0

    def report_for_token(self, token: str) -> Path | None:
        with self.connect() as connection:
            row = connection.execute(
                "SELECT live_report_path FROM local_run WHERE live_report_token = ?",
                (token,),
            ).fetchone()
        if not row or not row["live_report_path"]:
            return None
        return Path(row["live_report_path"])

    @property
    def snapshots_dir(self) -> Path:
        return self.path.parent / ".shopops" / "reporter-snapshots" / self.path.stem

    def cleanup_snapshots(self, *, capacity_pressure: bool = False) -> None:
        cutoff = time.time() if capacity_pressure else time.time() - 7 * 86400
        with self.connect() as connection:
            rows = connection.execute("SELECT snapshot_dir FROM local_run WHERE upload_state = 'complete' AND CAST(acknowledged_at AS REAL) < ? ORDER BY CAST(acknowledged_at AS REAL)", (cutoff,)).fetchall()
        for row in rows:
            if capacity_pressure and self._storage_bytes() < self.max_bytes:
                break
            if row[0]:
                target = Path(row[0])
                if target.parent.resolve() == self.snapshots_dir.resolve():
                    shutil.rmtree(target, ignore_errors=True)
                    shutil.rmtree(target.with_name(target.name + "-output"), ignore_errors=True)

    def _storage_bytes(self) -> int:
        snapshot_bytes = 0
        for path in self.snapshots_dir.glob("**/*"):
            try:
                if path.is_file() and not path.is_symlink():
                    snapshot_bytes += path.stat().st_size
            except FileNotFoundError:
                pass  # Acknowledged files may be removed by another process.

        return snapshot_bytes + sum(
            path.stat().st_size
            for path in (
                self.path,
                self.path.with_name(f"{self.path.name}-wal"),
                self.path.with_name(f"{self.path.name}-shm"),
            )
            if path.exists()
        )
