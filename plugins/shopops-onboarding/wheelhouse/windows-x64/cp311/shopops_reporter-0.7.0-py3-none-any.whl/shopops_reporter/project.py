from __future__ import annotations

import hashlib
import json
import os
import platform
import secrets
import shlex
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Iterable
from uuid import uuid4

import yaml

from shopops_reporter import __version__
from shopops_reporter.client import ReporterClient
from shopops_reporter.config import ProjectConfig
from shopops_reporter.dashboard import read_dashboard_descriptor
from shopops_reporter.diagnostics import validate_ai_readable_paths
from shopops_reporter.schedule_map import register_project
from shopops_reporter.fingerprint import validate_fingerprint_policy
from shopops_reporter.task_context import TaskContext, atomic_json, file_lock, read_json
from shopops_reporter.task_profiles import prepare_scope


EXCLUDED_PARTS = {
    ".git",
    ".shopops",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "dist",
    "build",
    "output",
    "outputs",
    "reports",
    "logs",
    "downloads",
    "tmp",
    "temp",
}
SENSITIVE_NAMES = {".env", ".env.local", "credentials.json", "secrets.json"}
FINGERPRINT_SUFFIXES = {
    ".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".ps1", ".r",
    ".json", ".yaml", ".yml", ".toml", ".lock", ".txt",
}
ARTIFACT_TYPES = {
    ".csv": "csv",
    ".xlsx": "xlsx",
    ".json": "json",
    ".txt": "text",
    ".log": "log",
    ".png": "image",
    ".jpg": "image",
    ".jpeg": "image",
    ".webp": "image",
    ".pdf": "pdf",
}


def project_fingerprint(
    project_dir: Path, *, config: ProjectConfig | None = None,
    policy: dict[str, Any] | None = None,
) -> str:
    if config is None and (project_dir / ".shopops/integration.yaml").is_file():
        declaration = yaml.safe_load((project_dir / ".shopops/integration.yaml").read_text(encoding="utf-8"))
        if isinstance(declaration, dict) and declaration.get("fingerprint") is not None:
            config = ProjectConfig.load(project_dir)
    policy = policy if policy is not None else (config.fingerprint if config else None)
    if policy is not None:
        return _versioned_fingerprint(project_dir, validate_fingerprint_policy(policy), config)
    return legacy_project_fingerprint(project_dir)


def legacy_project_fingerprint(project_dir: Path) -> str:
    digest = hashlib.sha256()
    count = 0
    for path in sorted(_fingerprint_files(project_dir), key=lambda item: item.as_posix()):
        relative = path.relative_to(project_dir).as_posix()
        digest.update(relative.encode("utf-8"))
        try:
            with path.open("rb") as handle:
                while chunk := handle.read(1024 * 1024):
                    digest.update(chunk)
        except OSError:
            continue
        count += 1
    if count == 0:
        digest.update(str(project_dir).encode("utf-8"))
    return f"sha256:{digest.hexdigest()}"


def _versioned_fingerprint(
    project_dir: Path, policy: dict[str, Any], config: ProjectConfig | None,
) -> str:
    # Frame the policy, execution configuration and each file independently.
    # Project identity stays in project_key/integration_id, never in this digest.
    execution = {
        key: getattr(config, key) for key in (
            "command", "working_directory", "artifacts", "html_reports", "result_json",
            "diagnostics", "ai_readable_artifacts",
        )
    } if config else {}
    digest = hashlib.sha256(json.dumps(
        {"policy": policy, "execution": execution}, sort_keys=True,
        ensure_ascii=False, separators=(",", ":"),
    ).encode())
    outputs = set(policy["outputs"])
    for path in sorted(_fingerprint_files(project_dir, version=2)):
        relative = path.relative_to(project_dir).as_posix()
        if relative in outputs:
            continue
        file_digest = hashlib.sha256()
        with path.open("rb") as handle:
            while chunk := handle.read(1024 * 1024):
                file_digest.update(chunk)
        digest.update(json.dumps([relative, file_digest.hexdigest()]).encode())
    return f"sha256-v2:{digest.hexdigest()}"


def _fingerprint_files(project_dir: Path, *, version: int = 1) -> Iterable[Path]:
    excluded = EXCLUDED_PARTS if version == 1 else EXCLUDED_PARTS - {
        "output", "outputs", "reports", "logs", "downloads", "tmp", "temp",
    }

    def walk_error(error: OSError) -> None:
        if version == 2:
            raise error

    for root, dirs, files in os.walk(project_dir, onerror=walk_error):
        dirs[:] = [name for name in dirs if name not in excluded]
        root_path = Path(root)
        if version == 2 and any((root_path / name).is_symlink() for name in dirs):
            raise RuntimeError("project_fingerprint_symlink_unsupported")
        for name in files:
            path = root_path / name
            if name in SENSITIVE_NAMES or name.startswith(".env."):
                continue
            if path.suffix.lower() not in FINGERPRINT_SUFFIXES:
                continue
            try:
                if version == 2 and path.is_symlink():
                    raise RuntimeError("project_fingerprint_symlink_unsupported")
                if path.is_symlink() or (version == 1 and path.stat().st_size > 10 * 1024 * 1024):
                    continue
            except OSError:
                continue
            yield path


def git_metadata(project_dir: Path) -> dict[str, Any]:
    def run(*args: str) -> str | None:
        try:
            result = subprocess.run(
                ["git", "-C", str(project_dir), *args],
                check=True,
                capture_output=True,
                text=True,
                timeout=5,
            )
        except (OSError, subprocess.SubprocessError):
            return None
        return result.stdout.strip()

    commit = run("rev-parse", "HEAD")
    if not commit:
        return {"available": False}
    return {
        "available": True,
        "branch": run("branch", "--show-current") or "detached",
        "commit": commit,
        "dirty": bool(run("status", "--porcelain")),
    }


def environment_metadata() -> dict[str, Any]:
    return {
        "os": f"{platform.system()} {platform.release()}",
        "python": platform.python_version(),
        "runtime": f"Python {platform.python_version()}",
        "reporter_version": __version__,
    }


def initialize_project(
    *,
    client: ReporterClient,
    project_dir: Path,
    display_name: str,
    platform_name: str,
    command: list[str],
    artifacts: list[str],
    html_reports: list[str],
    result_json: str | None,
    diagnostics: dict[str, Any] | None = None,
    ai_readable_artifacts: list[str] | None = None,
    task_key: str | None = None,
    entry: str | None = None,
    variant: str = '',
) -> tuple[ProjectConfig, bool]:
    context = TaskContext(project_dir, task_key)
    if task_key:
        if client.signed_get('/reporter/v1/capabilities').get('task_profiles') != 1:
            raise RuntimeError('task_profiles_unsupported_server')
    with file_lock(context.file('operation.lock')):
        return _initialize_project(
            client=client, project_dir=context.root, display_name=display_name,
            platform_name=platform_name, command=command, artifacts=artifacts,
            html_reports=html_reports, result_json=result_json, diagnostics=diagnostics,
            ai_readable_artifacts=ai_readable_artifacts, task_key=task_key,
            entry=entry, variant=variant,
        )


def _initialize_project(
    *, client, project_dir, display_name, platform_name, command, artifacts,
    html_reports, result_json, diagnostics, ai_readable_artifacts, task_key, entry, variant,
) -> tuple[ProjectConfig, bool]:
    project_dir = project_dir.resolve()
    context = TaskContext(project_dir, task_key)
    existing: ProjectConfig | None = None
    if context.config_path.exists():
        existing = ProjectConfig.load(project_dir, task_key=task_key)
    task_scope = existing.task_scope if existing else None
    if task_key and existing is None:
        if not entry:
            raise ValueError('task_entry_required')
        task_scope = prepare_scope(context, entry, variant)
    fingerprint = project_fingerprint(project_dir, config=existing) if existing else legacy_project_fingerprint(project_dir)
    dashboard = read_dashboard_descriptor(project_dir, task_key=task_key)
    resolved_diagnostics = diagnostics if diagnostics is not None else (
        existing.diagnostics if existing else None
    )
    requested_ai_paths = ai_readable_artifacts if ai_readable_artifacts is not None else (
        existing.ai_readable_artifacts if existing else []
    )
    resolved_ai_paths = validate_ai_readable_paths(requested_ai_paths, artifacts)
    project_key = existing.project_key if existing else (task_key or str(uuid4()))
    payload: dict[str, Any] = {
        "project_key": project_key,
        "display_name": display_name,
        "platform": platform_name,
        "initial_discovery_fingerprint": (
            existing.initial_discovery_fingerprint if existing else fingerprint
        ),
        "project_fingerprint": fingerprint,
        "command_summary": redact_command(command),
        "upload_policy": {
            "artifacts": artifacts,
            "html_reports": html_reports,
            "dashboard": dashboard,
            "diagnostics": resolved_diagnostics,
            "ai_readable_artifacts": resolved_ai_paths,
        },
    }
    if existing:
        payload["descriptor"] = existing.descriptor
        payload["descriptor_signature"] = existing.descriptor_signature
    if task_scope is not None:
        payload['task_scope'] = task_scope
        receipt_path = context.file('init-receipt.json')
        if existing is None and receipt_path.exists():
            receipt = read_json(receipt_path)
            if (receipt.get('project_key') != project_key
                    or receipt.get('descriptor', {}).get('task_scope') != task_scope):
                raise ValueError('task_receipt_identity_mismatch')
            payload['descriptor'] = receipt['descriptor']
            payload['descriptor_signature'] = receipt['descriptor_signature']
    response = client.signed_json("POST", "/reporter/v1/integrations/resolve", payload)
    if task_key:
        atomic_json(context.file('init-receipt.json'), response)
    config = ProjectConfig(
        version=1,
        project_key=project_key,
        integration_id=str(response["integration_id"]),
        display_name=display_name,
        platform=platform_name,
        working_directory=".",
        command=command,
        initial_discovery_fingerprint=payload["initial_discovery_fingerprint"],
        descriptor=response["descriptor"],
        descriptor_signature=response["descriptor_signature"],
        artifacts=artifacts,
        html_reports=html_reports,
        result_json=result_json,
        description=existing.description if existing else None,
        project_version=existing.project_version if existing else None,
        run_mode=existing.run_mode if existing else "unknown",
        dashboard=dashboard,
        diagnostics=resolved_diagnostics,
        ai_readable_artifacts=resolved_ai_paths,
        result_contract=existing.result_contract if existing else None,
        fingerprint=existing.fingerprint if existing else None,
        task_key=task_key,
        task_scope=task_scope,
    )
    config.save(project_dir)
    write_launchers(project_dir, task_key=task_key)
    register_project(project_dir, task_key=task_key)
    return config, bool(response.get("created"))


def redact_command(command: list[str]) -> str:
    sensitive = {"password", "token", "secret", "cookie", "authorization"}
    result: list[str] = []
    redact_next = False
    for part in command:
        lowered = part.lower().lstrip("-")
        if redact_next:
            result.append("[REDACTED]")
            redact_next = False
        elif lowered in sensitive:
            result.append(part)
            redact_next = True
        elif any(lowered.startswith(f"{key}=") for key in sensitive):
            result.append(f"{part.split('=', 1)[0]}=[REDACTED]")
        else:
            result.append(part)
    return shlex.join(result)[:500]


def write_launchers(project_dir: Path, *, task_key: str | None = None,
                    preserve_existing: bool = False) -> None:
    context = TaskContext(project_dir, task_key)
    directory = context.config_dir
    def write(name, content, *, encoding):
        target = context.file(name)
        if preserve_existing and target.exists():
            return
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(mode='w', encoding=encoding, dir=directory,
                                             prefix=name + '-', delete=False) as handle:
                temporary = Path(handle.name)
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
            if name == 'run.command' and os.name != 'nt':
                temporary.chmod(0o755)
            if preserve_existing and target.exists():
                return
            temporary.replace(target)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
    parent = '../../..' if task_key else '..'
    task_option = f' --task {task_key}' if task_key else ''
    directory.mkdir(parents=True, exist_ok=True)
    write('run.command',
        "#!/bin/sh\n"
        "set -eu\n"
        f"cd \"$(dirname \"$0\")/{parent}\"\n"
        "REPORTER_HOME=${SHOPOPS_REPORTER_HOME:-\"$HOME/.shopops-reporter\"}\n"
        f"exec \"$REPORTER_HOME/bin/shopops-report\" run{task_option}\n",
        encoding="utf-8",
    )
    write('run.ps1',
        "$ErrorActionPreference = 'Stop'\n"
        f"Set-Location (Join-Path $PSScriptRoot '{parent}')\n"
        "$ReporterHome = if ($env:SHOPOPS_REPORTER_HOME) {\n"
        "  $env:SHOPOPS_REPORTER_HOME\n"
        "} else {\n"
        "  Join-Path $env:LOCALAPPDATA 'ShopOps\\Reporter'\n"
        "}\n"
        "$Reporter = Join-Path $ReporterHome 'bin\\shopops-report.cmd'\n"
        f"& $Reporter run{task_option} @args\n"
        "exit $LASTEXITCODE\n",
        encoding="utf-8",
    )
    write('windows-task-wrapper.ps1',
        "param(\n"
        "  [string]$TaskKey,\n"
        "  [string]$TaskPath,\n"
        "  [string]$TriggerInstanceId,\n"
        "  [Parameter(ValueFromRemainingArguments = $true)]\n"
        "  [string[]]$ArgumentList\n"
        ")\n"
        "$ErrorActionPreference = 'Stop'\n"
        "$env:SHOPOPS_WINDOWS_TASK_KEY = $TaskKey\n"
        "$env:SHOPOPS_WINDOWS_TASK_PATH = $TaskPath\n"
        "$env:SHOPOPS_TRIGGER_INSTANCE_ID = if ($TriggerInstanceId) { $TriggerInstanceId } else { [guid]::NewGuid().ToString() }\n"
        "$env:SHOPOPS_TRIGGER_KIND = 'scheduled'\n"
        "$run = Join-Path $PSScriptRoot 'run.ps1'\n"
        "& $run @ArgumentList\n"
        "exit $LASTEXITCODE\n",
        encoding="utf-8",
    )


def read_result(config: ProjectConfig, project_dir: Path) -> dict[str, Any]:
    if not config.result_json:
        return {}
    target = safe_project_path(project_dir, config.result_json)
    if not target.is_file():
        return {"reporter_warning": f"结果文件不存在: {config.result_json}"}
    try:
        value = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        return {"reporter_warning": f"结果文件解析失败: {error}"}
    return value if isinstance(value, dict) else {"value": value}


def matching_files(project_dir: Path, patterns: list[str]) -> list[Path]:
    matched: dict[Path, None] = {}
    root = project_dir.resolve()
    for pattern in patterns:
        for candidate in root.glob(pattern):
            try:
                if candidate.is_symlink():
                    continue
                resolved = candidate.resolve(strict=True)
                resolved.relative_to(root)
            except (OSError, ValueError):
                continue
            if resolved.is_file():
                matched[resolved] = None
    return sorted(matched)


def safe_project_path(project_dir: Path, relative: str) -> Path:
    root = project_dir.resolve()
    target = (root / relative).resolve()
    try:
        target.relative_to(root)
    except ValueError as error:
        raise RuntimeError(f"项目路径越界: {relative}") from error
    return target


def artifact_type(path: Path) -> str | None:
    return ARTIFACT_TYPES.get(path.suffix.lower())


def artifact_digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def artifact_key(path: Path, project_dir: Path) -> str:
    relative = path.relative_to(project_dir.resolve()).as_posix()
    return f"file-{hashlib.sha256(relative.encode()).hexdigest()[:24]}"


def new_report_token() -> str:
    return secrets.token_urlsafe(24)
