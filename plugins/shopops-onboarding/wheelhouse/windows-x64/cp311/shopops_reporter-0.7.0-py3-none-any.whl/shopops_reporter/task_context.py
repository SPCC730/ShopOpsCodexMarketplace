"""Keep task declarations separate from the original source and output root."""

from __future__ import annotations

import json
import os
import stat
import tempfile
import yaml
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any
from uuid import UUID


def is_link(path: Path) -> bool:
    if path.is_symlink():
        return True
    try:
        return bool(getattr(path.lstat(), 'st_file_attributes', 0)
                    & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400))
    except FileNotFoundError:
        return False


def confined_path(root: Path, relative: str) -> Path:
    if (not relative or '\\' in relative or '\x00' in relative or ':' in relative
            or PurePosixPath(relative).is_absolute()
            or any(part in {'', '.', '..'} for part in relative.split('/'))):
        raise ValueError('task_path_invalid')
    root = root.resolve()
    target = root
    for part in relative.split('/'):
        target = target / part
        if is_link(target):
            raise ValueError('task_path_link_unsupported')
    target.resolve().relative_to(root)
    return target


@dataclass(frozen=True)
class TaskContext:
    root: Path
    task_key: str | None = None

    def __post_init__(self):
        object.__setattr__(self, 'root', self.root.resolve())
        if self.task_key is not None:
            if not isinstance(self.task_key, str) or str(UUID(self.task_key)) != self.task_key:
                raise ValueError('task_key_must_be_canonical_uuid')

    @property
    def config_relative(self) -> str:
        return f'.shopops/tasks/{self.task_key}' if self.task_key else '.shopops'

    @property
    def config_dir(self) -> Path:
        return confined_path(self.root, self.config_relative)

    def relative_config(self, name: str) -> str:
        relative = f'{self.config_relative}/{name}'
        confined_path(self.root, relative)
        return relative

    def file(self, name: str) -> Path:
        return confined_path(self.root, self.relative_config(name))

    @property
    def config_path(self) -> Path:
        return self.file('integration.yaml')

    @property
    def contract_path(self) -> Path:
        if self.config_path.is_file():
            if self.config_path.stat().st_size > 1024 * 1024:
                raise ValueError('task_config_too_large')
            config = yaml.safe_load(self.config_path.read_text(encoding='utf-8'))
            reference = config.get('result_contract') if isinstance(config, dict) else None
            name = reference.get('file') if isinstance(reference, dict) else None
            if name is not None:
                if not isinstance(name, str) or '/' in name or '\\' in name:
                    raise ValueError('result_contract_file_invalid')
                return self.file(name)
        return self.file('result-contract.yaml')

    def as_reference(self) -> dict[str, Any]:
        return {'root': str(self.root), 'task_key': self.task_key}


@contextmanager
def file_lock(path: Path):
    """OS locks release on process exit; a stale lock file is never a stale owner."""
    if is_link(path) or is_link(path.parent):
        raise ValueError('task_path_link_unsupported')
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd = os.open(path, os.O_CREAT | os.O_RDWR | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    locked = False
    try:
        if os.name == 'nt':
            import msvcrt
            if os.fstat(fd).st_size == 0:
                os.write(fd, b'0')
            os.lseek(fd, 0, os.SEEK_SET)
            try:
                msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
            except OSError as error:
                raise RuntimeError('task_operation_busy') from error
        else:
            import fcntl
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError as error:
                raise RuntimeError('task_operation_busy') from error
        locked = True
        yield
    finally:
        if locked:
            if os.name == 'nt':
                os.lseek(fd, 0, os.SEEK_SET)
                msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def atomic_json(path: Path, value: Any) -> None:
    if is_link(path) or is_link(path.parent):
        raise ValueError('task_path_link_unsupported')
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent,
                                         prefix=path.stem + '-', suffix='.tmp', delete=False) as handle:
            temporary = Path(handle.name)
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write('\n')
            handle.flush()
            os.fsync(handle.fileno())
        temporary.replace(path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def read_json(path: Path, *, maximum: int = 1024 * 1024) -> Any:
    if is_link(path) or path.stat().st_size > maximum:
        raise ValueError('task_state_unsafe')
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (UnicodeError, ValueError) as error:
        raise ValueError('task_state_invalid_preserve_for_recovery') from error
