from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path

from shopops_reporter.task_context import is_link

EXCLUDED = {'.git', '.shopops', '.venv', 'venv', 'node_modules', '__pycache__',
            '.pytest_cache', '.mypy_cache', '.ruff_cache', 'dist', 'build', 'data',
            'output', 'outputs', 'reports', 'logs', 'downloads', 'tmp', 'temp',
            'storage', 'browser', 'profiles', 'credentials', 'secrets', '.ssh'}
SUFFIXES = {'.py', '.js', '.mjs', '.cjs', '.ts', '.ps1', '.sh', '.bat', '.cmd',
            '.md', '.toml', '.yaml', '.yml', '.json'}
MAX_FILES, MAX_DEPTH, MAX_BYTES = 1000, 5, 256 * 1024
MAX_TOTAL_BYTES = 8 * 1024 * 1024


def digest(value) -> str:
    return 'sha256:' + hashlib.sha256(json.dumps(value, sort_keys=True,
                ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()


def allowed(path: Path) -> bool:
    name = path.name.casefold()
    return (path.suffix.casefold() in SUFFIXES and not name.startswith('.')
            and not any(word in name for word in ('credential', 'secret', 'cookie', 'password', 'token'))
            and name not in {'auth.json', 'config.json', 'session.json'})


def checked_scope(path: Path) -> Path:
    path = path.expanduser().absolute()
    if any(is_link(item) for item in (path, *path.parents)):
        raise ValueError('discovery_link_unsupported')
    path = path.resolve(strict=True)
    if not path.is_file() and not path.is_dir():
        raise ValueError('discovery_path_invalid')
    return path


def discover(path: Path) -> dict:
    scope = checked_scope(path)
    root = scope if scope.is_dir() else scope.parent
    files, candidates, omitted = [], [], 0
    total = 0
    limited = False
    if scope.is_file():
        if not allowed(scope):
            raise ValueError('discovery_file_not_allowed')
        paths = iter([scope])
    else:
        def walk():
            nonlocal limited, omitted
            for directory, dirs, names in os.walk(scope, followlinks=False):
                parent = Path(directory)
                dirs[:] = sorted(name for name in dirs if name.casefold() not in EXCLUDED
                                 and not name.startswith('.') and not is_link(parent / name))
                if len(parent.relative_to(scope).parts) >= MAX_DEPTH:
                    limited = limited or bool(dirs)
                    dirs[:] = []
                for name in sorted(names):
                    target = parent / name
                    if allowed(target) and not is_link(target):
                        yield target
                    else:
                        omitted += 1
        paths = walk()
    for target in paths:
        if len(files) >= MAX_FILES:
            limited = True
            break
        if target.stat().st_size > MAX_BYTES:
            omitted += 1
            limited = True
            continue
        content = target.read_bytes()
        total += len(content)
        if total > MAX_TOTAL_BYTES:
            limited = True
            break
        try:
            text = content.decode('utf-8-sig')
        except UnicodeError:
            omitted += 1
            continue
        relative = target.relative_to(root).as_posix()
        files.append({'path': relative, 'digest': 'sha256:' + hashlib.sha256(content).hexdigest()})
        reasons = []
        if scope.is_file():
            reasons = ['explicit_file']
        elif target.suffix == '.py':
            try:
                tree = ast.parse(text)
                if any(isinstance(node, ast.If) and isinstance(node.test, ast.Compare)
                       and isinstance(node.test.left, ast.Name) and node.test.left.id == '__name__'
                       and any(isinstance(value, ast.Constant) and value.value == '__main__'
                               for value in node.test.comparators) for node in tree.body):
                    reasons = ['python_main_guard']
            except SyntaxError:
                pass
        elif target.suffix in {'.sh', '.ps1', '.bat', '.cmd'}:
            reasons = ['launcher_requires_confirmation']
        elif target.suffix in {'.js', '.ts', '.mjs', '.cjs'} and target.stem in {'main', 'cli', 'index'}:
            reasons = ['possible_entry_requires_confirmation']
        if reasons:
            candidates.append({'entry': relative, 'evidence': reasons, 'confirmed_sop': False})
    return {'version': 1, 'scope': str(scope), 'root': str(root),
            'scope_kind': 'directory' if scope.is_dir() else 'file', 'files': files,
            'candidates': candidates, 'omitted_count': omitted, 'limited': limited,
            'digest': digest({'scope': str(scope), 'files': files}),
            'uncertainties': ['confirm_independent_business_units', 'confirm_output_meaning'],
            'existing_access': 'inspect_selected_configuration_after_scope_confirmation'}
