from shopops_reporter.onboarding import workflow
from shopops_reporter.onboarding.discovery import discover
from shopops_reporter.task_context import read_json


def dispatch_onboarding(args):
    action = args.onboarding_action
    if action == 'capabilities':
        return {'version': 1, 'task_profiles': 1, 'guided_onboarding': 1, 'batch_run': False}
    if action == 'discover':
        return discover(args.path)
    if action == 'prepare':
        return workflow.prepare(args.path, read_json(args.selection),
                                scope_digest=args.scope_digest, experienced=args.experienced)
    if action == 'preview':
        return workflow.preview(args.session, args.task, args.operation,
                                read_json(args.spec) if args.spec else None)
    if action == 'apply':
        return workflow.apply(args.session, args.plan, args.confirm_digest)
    if action == 'check':
        return workflow.check(args.session, args.task)
    if action == 'status':
        state = workflow.load(args.session)
        return {**state, 'plans': {key: value['status'] for key, value in state['plans'].items()},
                'evidence_freshness': 'cached_use_check_for_current_server_evidence',
                'output_conflicts': workflow.output_conflicts(state)}
    if action == 'apply-batch':
        return apply_batch(args.session, read_json(args.confirmations))
    raise ValueError('onboarding_command_invalid')


def apply_batch(session_id, confirmations):
    if (not isinstance(confirmations, list) or not 1 <= len(confirmations) <= 100
            or any(not isinstance(item, dict) or set(item) != {'plan_id', 'digest'} for item in confirmations)):
        raise ValueError('onboarding_batch_invalid')
    state = workflow.load(session_id)
    if not state['experienced'] and state['tasks'][0]['phase'] != 'verified':
        raise ValueError('onboarding_first_task_verification_required')
    seen = set()
    for item in confirmations:
        record = state['plans'].get(item['plan_id'])
        if record is None or record['plan']['digest'] != item['digest']:
            raise ValueError('onboarding_confirmation_mismatch')
        if record['plan']['operation'] not in {'initialize', 'submit'}:
            raise ValueError('onboarding_batch_run_forbidden')
        task_key = record['plan']['task_key']
        if task_key in seen:
            raise ValueError('onboarding_batch_one_operation_per_task')
        seen.add(task_key)
    results = []
    for item in confirmations:
        try:
            value = workflow.apply(session_id, item['plan_id'], item['digest'])
            results.append({'plan_id': item['plan_id'], 'ok': True, 'result': value})
        except Exception as error:
            results.append({'plan_id': item['plan_id'], 'ok': False, 'error_code': type(error).__name__})
    return {'results': results, 'run_all_available': False}
