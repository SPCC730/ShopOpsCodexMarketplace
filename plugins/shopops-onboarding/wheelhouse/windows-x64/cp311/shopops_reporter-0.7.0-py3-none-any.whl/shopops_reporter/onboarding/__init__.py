"""Explicit, resumable onboarding; discovery never executes project code."""
