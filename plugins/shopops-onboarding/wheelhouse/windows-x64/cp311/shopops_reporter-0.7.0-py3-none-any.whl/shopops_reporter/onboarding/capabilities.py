"""Read-only capability doctor with server identity validation and dated local cache."""

import json
from shopops_reporter.config import ProjectConfig
from shopops_reporter.task_context import TaskContext, atomic_json

KEYS = {
    "diagnostic_schema",
    "reporter_version",
    "structured_error",
    "project_version",
    "application_environment",
    "ai_evidence",
    "office_role",
    "schedule",
}


def evaluate_capability_receipt(
    receipt: dict, *, integration_id: str, configuration_digest: str
) -> dict:
    if (
        receipt.get("version") != 2
        or receipt.get("integration_id") != integration_id
        or receipt.get("configuration_digest") != configuration_digest
    ):
        raise ValueError("capability_receipt_identity_mismatch")
    items = receipt.get("items")
    if not isinstance(items, list) or len(items) != 8 or not all(isinstance(i, dict) for i in items) or {i.get("key") for i in items} != KEYS:
        raise ValueError("capability_receipt_items_invalid")
    if any(
        i.get("state") not in {"unconfigured", "pending", "verified", "invalid", "not_applicable"}
        for i in items
    ):
        raise ValueError("capability_receipt_state_invalid")
    return receipt


def check_capabilities(project_dir, *, task_key=None, client=None):
    config = ProjectConfig.load(project_dir, task_key=task_key)
    path = TaskContext(project_dir, task_key).file("capability-receipt.json")
    cached = json.loads(path.read_text()) if path.exists() else None
    if client is None:
        return {
            "source": "local_cache",
            "fresh": False,
            "receipt": cached,
            "note": "缓存仅供诊断参考；完整接入以服务端回执为准",
        }
    receipt = client.signed_get(f"/reporter/v1/projects/{config.integration_id}/capabilities")
    result = evaluate_capability_receipt(
        receipt,
        integration_id=config.integration_id,
        configuration_digest=receipt.get("configuration_digest"),
    )
    atomic_json(path, result)
    return {"source": "server", "fresh": True, "receipt": result}
