from __future__ import annotations

import hmac
import json
import os
import secrets
import threading
import time
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

import httpx
import psutil

from shopops_reporter.config import ensure_private_directory, reporter_home


def marker_path() -> Path:
    return reporter_home() / "reporter.pid"


@contextmanager
def instance_lock():
    home = ensure_private_directory(reporter_home())
    # Never unlink a lock file: another process may already hold its inode.
    with (home / "reporter.lock").open("a+b") as handle:
        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            raise RuntimeError("reporter_instance_locked: Reporter 已有后台实例") from error
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle, fcntl.LOCK_UN)


def process_identity(pid: int) -> dict[str, Any] | None:
    try:
        process = psutil.Process(pid)
        with process.oneshot():
            return {
                "pid": pid, "created_at": process.create_time(),
                "executable": process.exe(), "command": process.cmdline(),
            }
    except psutil.NoSuchProcess:
        return None


def is_reporter_command(command: list[str]) -> bool:
    return any(
        command[index:index + 3] == ["-m", "shopops_reporter", "serve"]
        for index in range(len(command))
    ) or any(
        Path(part).name in {"shopops-report", "shopops-report.exe"}
        and command[index + 1:index + 2] == ["serve"]
        for index, part in enumerate(command)
    )


def read_marker() -> tuple[str | None, dict[str, Any] | None]:
    try:
        raw = marker_path().read_text(encoding="utf-8")
    except FileNotFoundError:
        return None, None
    value = json.loads(raw)
    if type(value) is int and value > 0:
        return raw, {"pid": value, "version": 1}
    if (
        not isinstance(value, dict) or value.get("version") != 2
        or type(value.get("pid")) is not int or value["pid"] <= 0
        or not isinstance(value.get("created_at"), (int, float))
        or not isinstance(value.get("executable"), str)
        or type(value.get("port")) is not int or not 0 < value["port"] < 65536
        or not isinstance(value.get("token"), str) or len(value["token"]) < 32
    ):
        raise ValueError("reporter_marker_invalid")
    return raw, value


def clear_marker(raw: str) -> None:
    # Called only while the instance lock is held, or by the owning instance.
    try:
        if marker_path().read_text(encoding="utf-8") == raw:
            marker_path().unlink()
    except FileNotFoundError:
        pass


def control_request(marker: dict[str, Any], action: str) -> dict[str, Any] | None:
    try:
        with httpx.Client(timeout=1, trust_env=False) as client:
            response = client.request(
                "POST" if action == "stop" else "GET",
                f"http://127.0.0.1:{marker['port']}/{action}",
                headers={"Authorization": f"Bearer {marker['token']}"},
            )
            value = response.json()
            if response.status_code == 200 and isinstance(value, dict):
                if value.get("pid") == marker["pid"] and value.get("created_at") == marker["created_at"]:
                    return value
    except (httpx.HTTPError, ValueError, KeyError):
        pass
    return None


def inspect_daemon(*, cleanup_stale: bool = False) -> dict[str, Any]:
    try:
        raw, marker = read_marker()
        if marker is None:
            return {"state": "stopped", "pid": None, "running": False}
        identity = process_identity(marker["pid"])
        if identity is None:
            state = "stale"
        elif not is_reporter_command(identity["command"]):
            state = "foreign"
        elif marker["version"] == 1:
            state = "legacy_unverified"
        elif any(identity[key] != marker[key] for key in ("created_at", "executable")):
            state = "foreign"
        else:
            health = control_request(marker, "health")
            state = "healthy" if health and health.get("healthy") is True else "unhealthy"
        if cleanup_stale and state in {"stale", "foreign"} and raw is not None:
            try:
                with instance_lock():
                    clear_marker(raw)
            except RuntimeError:
                pass
        return {
            "state": state,
            "pid": marker["pid"] if state in {"healthy", "unhealthy", "legacy_unverified"} else None,
            "running": state == "healthy",
        }
    except (OSError, ValueError, psutil.Error):
        return {"state": "unknown", "pid": None, "running": False}


class DaemonControl:
    def __init__(self, stopped: threading.Event):
        self.stopped = stopped
        self.last_progress = time.monotonic()
        self.ready = False
        identity = process_identity(os.getpid())
        if identity is None:
            raise RuntimeError("reporter_process_identity_unavailable")
        self.marker = {
            "version": 2, "pid": identity["pid"], "created_at": identity["created_at"],
            "executable": identity["executable"], "token": secrets.token_urlsafe(32),
        }
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):  # noqa: N802
                self.respond(False)

            def do_POST(self):  # noqa: N802
                self.respond(True)

            def respond(self, stop: bool):
                if not hmac.compare_digest(
                    self.headers.get("Authorization", ""), f"Bearer {owner.marker['token']}",
                ):
                    self.send_error(403)
                    return
                if self.path != ("/stop" if stop else "/health"):
                    self.send_error(404)
                    return
                if stop:
                    owner.stopped.set()
                body = json.dumps({
                    "pid": owner.marker["pid"], "created_at": owner.marker["created_at"],
                    "healthy": owner.ready and not owner.stopped.is_set()
                    and time.monotonic() - owner.last_progress < 120,
                }).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *_args):
                pass

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.server.daemon_threads = True
        self.marker["port"] = self.server.server_port
        self.raw = json.dumps(self.marker)

    def progress(self) -> None:
        self.last_progress = time.monotonic()

    def __enter__(self):
        temporary = marker_path().with_suffix(".tmp")
        try:
            with temporary.open("w", encoding="utf-8") as handle:
                if os.name != "nt":
                    os.chmod(temporary, 0o600)
                handle.write(self.raw)
            temporary.replace(marker_path())
            threading.Thread(target=self.server.serve_forever, daemon=True).start()
        except BaseException:
            self.server.server_close()
            raise
        return self

    def __exit__(self, *_args):
        self.server.shutdown()
        self.server.server_close()
        clear_marker(self.raw)


def request_daemon_stop() -> bool:
    try:
        initial_raw, _ = read_marker()
    except (OSError, ValueError) as error:
        raise RuntimeError("Reporter 进程身份无法确认，未终止任何进程") from error
    status = inspect_daemon()
    if status["state"] in {"stopped", "stale", "foreign"}:
        inspect_daemon(cleanup_stale=True)
        return False
    if status["state"] not in {"healthy", "unhealthy"}:
        raise RuntimeError("Reporter 进程身份无法确认，未终止任何进程")
    raw, marker = read_marker()
    if raw != initial_raw or marker is None or marker["pid"] != status["pid"] or not control_request(marker, "stop"):
        raise RuntimeError("Reporter 控制接口不可用，未向 PID 发送终止信号")
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        current, _ = read_marker()
        if current != raw:
            return True
        time.sleep(0.1)
    raise RuntimeError("Reporter 尚未退出，保留实例标记与离线队列")
