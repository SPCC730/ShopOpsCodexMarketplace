from __future__ import annotations

from pathlib import PurePosixPath
from typing import Any


OUTPUT_SUFFIXES = {".json", ".csv", ".xlsx", ".txt", ".log", ".html", ".pdf", ".png", ".jpg", ".jpeg", ".webp"}


def validate_fingerprint_policy(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != {"version", "outputs"}:
        raise ValueError("project_fingerprint_policy_invalid")
    if type(value["version"]) is not int or value["version"] != 2:
        raise ValueError("project_fingerprint_version_unsupported")
    outputs = value["outputs"]
    if not isinstance(outputs, list) or len(outputs) > 200:
        raise ValueError("project_fingerprint_outputs_invalid")
    for path in outputs:
        if (
            not isinstance(path, str) or not path or len(path) > 500
            or any(char in path for char in "\\\x00:*?[]")
            or any(part in {"", ".", ".."} for part in path.split("/"))
            or PurePosixPath(path).suffix.lower() not in OUTPUT_SUFFIXES
            or path.startswith(".shopops/")
        ):
            raise ValueError("project_fingerprint_output_path_invalid")
    if len(outputs) != len(set(outputs)):
        raise ValueError("project_fingerprint_outputs_duplicate")
    return {"version": 2, "outputs": sorted(outputs)}
