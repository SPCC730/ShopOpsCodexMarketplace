"""Use only public APScheduler 3.x attributes. Never inspect callables or arguments."""


def iso(value):
    return value.isoformat() if value is not None else None


def normalize_job(job):
    from apscheduler.triggers.cron import CronTrigger
    from apscheduler.triggers.interval import IntervalTrigger
    from apscheduler.triggers.date import DateTrigger

    trigger = job.trigger
    if isinstance(trigger, CronTrigger):
        data = {
            "kind": "cron",
            "fields": {field.name: str(field) for field in trigger.fields},
            "start_date": iso(trigger.start_date),
            "end_date": iso(trigger.end_date),
            "jitter": trigger.jitter,
        }
    elif isinstance(trigger, IntervalTrigger):
        data = {
            "kind": "interval",
            "seconds": trigger.interval.total_seconds(),
            "start_date": iso(trigger.start_date),
            "end_date": iso(trigger.end_date),
            "jitter": trigger.jitter,
        }
    elif isinstance(trigger, DateTrigger):
        data = {"kind": "date", "run_date": iso(trigger.run_date)}
    else:
        data = {"kind": "custom"}
    pending = job.pending
    next_run = None if pending else job.next_run_time
    return {
        "source_schedule_id": job.id,
        "task_name": job.name,
        "trigger": data,
        "timezone": str(getattr(trigger, "timezone", "unknown")),
        "enabled": pending or next_run is not None,
        "next_run_at": iso(next_run),
        "scheduler_state": "pending" if pending else "paused" if next_run is None else "ready",
        "projects": [],
    }
