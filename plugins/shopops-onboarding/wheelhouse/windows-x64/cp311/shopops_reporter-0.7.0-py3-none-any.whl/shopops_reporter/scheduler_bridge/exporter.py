import json
import hashlib
import os
import tempfile
import threading
from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4
from shopops_reporter.scheduler_bridge.apscheduler3 import normalize_job
from shopops_reporter.scheduler_bridge.versions import require_supported_version


class BridgeHandle:
    def __init__(self, scheduler, *, instance_id, export_path, mappings):
        require_supported_version()
        if not isinstance(instance_id, str) or not instance_id or len(instance_id) > 200:
            raise ValueError("scheduler_instance_id_invalid")
        self.scheduler = scheduler
        self.instance_id = instance_id
        self.export_path = Path(export_path)
        self.mappings = dict(mappings)
        self.generation = uuid4().hex
        self.sequence = 0
        self.events = []
        self.events_truncated = False
        self.event_lock = threading.Lock()
        self.lock = threading.Lock()
        self.stop = threading.Event()
        self.changed = threading.Event()
        self.last_tasks = []
        from apscheduler.events import (
            EVENT_SCHEDULER_STARTED,
            EVENT_SCHEDULER_SHUTDOWN,
            EVENT_SCHEDULER_PAUSED,
            EVENT_SCHEDULER_RESUMED,
            EVENT_JOB_ADDED,
            EVENT_JOB_REMOVED,
            EVENT_JOB_MODIFIED,
        )

        self.mask = (
            EVENT_SCHEDULER_STARTED
            | EVENT_SCHEDULER_SHUTDOWN
            | EVENT_SCHEDULER_PAUSED
            | EVENT_SCHEDULER_RESUMED
            | EVENT_JOB_ADDED
            | EVENT_JOB_REMOVED
            | EVENT_JOB_MODIFIED
        )
        from apscheduler.events import (
            EVENT_JOB_SUBMITTED,
            EVENT_JOB_MISSED,
            EVENT_JOB_MAX_INSTANCES,
            EVENT_JOB_ERROR,
        )

        self.event_kinds = {
            EVENT_JOB_SUBMITTED: "triggered",
            EVENT_JOB_MISSED: "misfired",
            EVENT_JOB_MAX_INSTANCES: "max_instances_skipped",
            EVENT_JOB_ERROR: "call_failed",
        }
        self.mask |= (
            EVENT_JOB_SUBMITTED | EVENT_JOB_MISSED | EVENT_JOB_MAX_INSTANCES | EVENT_JOB_ERROR
        )
        scheduler.add_listener(self._on_event, self.mask)
        self.export_now()
        self.thread = threading.Thread(
            target=self._heartbeat, name="shopops-schedule-export", daemon=True
        )
        self.thread.start()

    def _on_event(self, event):
        kind = self.event_kinds.get(event.code)
        if kind:
            times = getattr(event, "scheduled_run_times", None) or [
                getattr(event, "scheduled_run_time", None)
            ]
            with self.event_lock:
                for scheduled in times:
                    if scheduled is None:
                        continue
                    occurrence = scheduled.isoformat()
                    trigger_id = hashlib.sha256(
                        json.dumps(
                            [self.instance_id, self.generation, event.job_id, occurrence]
                        ).encode()
                    ).hexdigest()
                    self.events.append(
                        {
                            "event_id": trigger_id + ":" + kind,
                            "kind": kind,
                            "source_schedule_id": event.job_id,
                            "scheduled_for": occurrence,
                            "observed_at": datetime.now(UTC).isoformat(),
                            "trigger_instance_id": trigger_id,
                        }
                    )
                if len(self.events) > 500:
                    self.events_truncated = True
                    self.events = self.events[-500:]
        self.changed.set()

    def _heartbeat(self):
        while not self.stop.is_set():
            self.changed.wait(30)
            if self.stop.is_set():
                return
            self.changed.clear()
            try:
                self.export_now()
            except (OSError, ValueError):
                # The old observation time stays unchanged when writing fails.
                pass

    def export_now(self):
        with self.lock:
            complete = True
            try:
                tasks = [normalize_job(job) for job in self.scheduler.get_jobs()]
                for task in tasks:
                    task["projects"] = [
                        {"integration_id": key, "source": "declared", "expected_on_each_run": True}
                        for key in self.mappings.get(task["source_schedule_id"], [])
                    ]
                self.last_tasks = tasks
            except Exception:
                complete = False
                tasks = self.last_tasks
            self.sequence += 1
            value = {
                "version": 2,
                "source": "apscheduler",
                "instance_id": self.instance_id,
                "generation": self.generation,
                "sequence": self.sequence,
                "observed_at": datetime.now(UTC).isoformat(),
                "complete": complete,
                "scheduler_state": {0: "stopped", 1: "running", 2: "paused"}.get(
                    self.scheduler.state, "unknown"
                ),
                "tasks": tasks,
            }
            self.export_path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            fd, name = tempfile.mkstemp(prefix=".schedule-", dir=self.export_path.parent)
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as stream:
                    json.dump(value, stream, ensure_ascii=False)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(name, self.export_path)
            finally:
                Path(name).unlink(missing_ok=True)
            event_path = self.export_path.with_suffix(self.export_path.suffix + ".events.json")
            fd, event_temp = tempfile.mkstemp(prefix=".events-", dir=event_path.parent)
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as stream:
                    with self.event_lock:
                        event_payload = {
                            "generation": self.generation,
                            "events": list(self.events),
                            "truncated": self.events_truncated,
                        }
                    json.dump(event_payload, stream)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(event_temp, event_path)
            finally:
                Path(event_temp).unlink(missing_ok=True)
            return value

    def close(self):
        self.stop.set()
        self.changed.set()
        self.scheduler.remove_listener(self._on_event)
        self.thread.join(timeout=5)
