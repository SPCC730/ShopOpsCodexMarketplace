from importlib.metadata import version


def require_supported_version():
    parts = version("APScheduler").split(".")
    if len(parts) < 2 or parts[0] != "3" or parts[1] not in {"10", "11"}:
        raise ValueError("unsupported_apscheduler_version")
    return ".".join(parts)
