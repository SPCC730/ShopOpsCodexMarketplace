"""Optional read-only adapter; importing it neither imports APScheduler nor starts work."""


def attach_scheduler(scheduler, *, instance_id, export_path, mappings):
    from .exporter import BridgeHandle

    return BridgeHandle(
        scheduler, instance_id=instance_id, export_path=export_path, mappings=mappings
    )
