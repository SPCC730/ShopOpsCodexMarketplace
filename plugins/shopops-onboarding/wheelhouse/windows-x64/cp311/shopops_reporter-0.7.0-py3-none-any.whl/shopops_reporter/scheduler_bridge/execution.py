"""Explicit occurrence context for supported application wrappers, not global env mutation."""

from contextvars import ContextVar
from dataclasses import asdict, dataclass
from datetime import datetime


@dataclass(frozen=True)
class ScheduleExecutionContext:
    source: str
    instance_id: str
    source_schedule_id: str
    trigger_instance_id: str
    scheduled_for: str

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, value):
        result = cls(**value)
        if (
            result.source != "apscheduler"
            or datetime.fromisoformat(result.scheduled_for.replace("Z", "+00:00")).utcoffset()
            is None
        ):
            raise ValueError("schedule_execution_context_invalid")
        if not all(isinstance(v, str) and 0 < len(v) <= 200 for v in value.values()):
            raise ValueError("schedule_execution_context_invalid")
        return result


current_execution_context = ContextVar("shopops_schedule_execution", default=None)
