"""Strict, credential-free diagnostic v2 wire format (shared protocol)."""

from __future__ import annotations

import json
import re
from datetime import datetime

_KEYS = {
    "schema_version",
    "external_run_key",
    "generated_at",
    "business_status",
    "issues",
    "impact",
    "evidence_refs",
}
_IDENTIFIER = re.compile(r"^[A-Za-z0-9_.-]{1,100}$")
_SENSITIVE = re.compile(
    r"password|passwd|secret|token|cookie|authorization|api[_-]?key|credential", re.I
)


def parse_diagnostic_v2(payload: dict, *, external_run_key: str) -> dict:
    def reject(code="invalid_diagnostic_envelope"):
        raise ValueError(code)

    def sensitive(value):
        if isinstance(value, dict):
            return any(_SENSITIVE.search(str(k)) or sensitive(v) for k, v in value.items())
        if isinstance(value, list):
            return any(sensitive(v) for v in value)
        if isinstance(value, str):
            return bool(
                re.search(
                    r"(?i)\bbearer\s+[A-Za-z0-9._~+/=-]+|\b(password|passwd|cookie|token|secret|authorization|api[_-]?key)\s*[:=]\s*[^\s,;]+",
                    value,
                )
            )
        return False

    if not isinstance(payload, dict) or set(payload) != _KEYS:
        reject()
    try:
        encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (TypeError, ValueError):
        reject()
    if len(encoded) > 65536:
        reject("diagnostic_file_too_large")
    if sensitive(payload):
        reject("sensitive_diagnostic_content")
    if type(payload["schema_version"]) is not int or payload["schema_version"] != 2:
        reject("unsupported_diagnostic_schema")
    if (
        not isinstance(payload["external_run_key"], str)
        or not payload["external_run_key"]
        or len(payload["external_run_key"]) > 200
    ):
        reject()
    if payload["external_run_key"] != external_run_key:
        reject("diagnostic_run_mismatch")
    try:
        timestamp = datetime.fromisoformat(payload["generated_at"].replace("Z", "+00:00"))
        if timestamp.utcoffset() is None:
            reject("diagnostic_timestamp_timezone_required")
    except (AttributeError, TypeError, ValueError):
        reject("diagnostic_timestamp_timezone_required")
    if payload["business_status"] not in ("completed", "partial", "failed", "unknown"):
        reject()
    issues = payload["issues"]
    if not isinstance(issues, list) or len(issues) > 50:
        reject()
    for issue in issues:
        if not isinstance(issue, dict) or set(issue) != {
            "code",
            "stage",
            "type",
            "message",
            "retryable",
        }:
            reject()
        if not all(
            isinstance(issue[k], str) and _IDENTIFIER.fullmatch(issue[k])
            for k in ("code", "stage", "type")
        ):
            reject()
        if (
            not isinstance(issue["message"], str)
            or not issue["message"].strip()
            or len(issue["message"]) > 2000
            or type(issue["retryable"]) is not bool
        ):
            reject()
    impact = payload["impact"]
    if not isinstance(impact, dict) or not all(
        isinstance(k, str) and isinstance(v, str) for k, v in impact.items()
    ):
        reject()
    refs = payload["evidence_refs"]
    if not isinstance(refs, list) or len(refs) > 50:
        reject()
    for ref in refs:
        if not isinstance(ref, dict):
            reject()
        if ref.get("kind") == "log":
            if (
                set(ref) != {"kind", "sequence"}
                or type(ref["sequence"]) is not int
                or ref["sequence"] < 1
            ):
                reject()
        elif ref.get("kind") == "artifact":
            if (
                set(ref) != {"kind", "key"}
                or not isinstance(ref["key"], str)
                or not re.fullmatch(r"[A-Za-z0-9._-]{1,200}", ref["key"])
            ):
                reject()
        else:
            reject()
    return json.loads(encoded)
