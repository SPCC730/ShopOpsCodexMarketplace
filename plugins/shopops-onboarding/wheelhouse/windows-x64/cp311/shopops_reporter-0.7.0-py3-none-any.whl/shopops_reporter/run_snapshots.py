"""Materialize run-owned files before a terminal record can enter the upload queue."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True)
class SnapshotInput:
    key: str
    path: Path
    kind: str


@dataclass(frozen=True)
class SnapshotManifest:
    version: int
    external_run_key: str
    artifacts: list[dict]
    diagnostics: dict | None
    warnings: list[str]

    def to_dict(self) -> dict:
        return asdict(self)


def freeze_run_snapshot(
    *,
    run_key: str,
    run_dir: Path,
    inputs: list[SnapshotInput],
    diagnostics: dict | None,
    warnings: list[str],
    max_bytes: int,
) -> SnapshotManifest:
    run_dir.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if run_dir.exists():
        raise ValueError("run_snapshot_already_exists")
    temp = Path(tempfile.mkdtemp(prefix=".snapshot-", dir=run_dir.parent))
    (temp / 'owner.json').write_text(json.dumps({'external_run_key': run_key}), encoding='utf-8')
    artifacts, errors, seen = [], list(warnings), set()
    used = 0
    try:
        for item in inputs:
            if not re.fullmatch(r"[A-Za-z0-9._-]{1,200}", item.key) or item.key in seen:
                raise ValueError("snapshot_artifact_key_invalid_or_duplicate")
            seen.add(item.key)
            target = temp / item.key / item.path.name
            try:
                if item.path.is_symlink() or any(p.is_symlink() for p in item.path.parents):
                    raise ValueError("snapshot_symlink_rejected")
                before = item.path.stat()
                if not item.path.is_file():
                    raise ValueError("snapshot_not_regular_file")
                if used + before.st_size > max_bytes:
                    raise ValueError("snapshot_capacity_exceeded")
                target.parent.mkdir(mode=0o700)
                digest = hashlib.sha256()
                size = 0
                with item.path.open("rb") as source, target.open("xb") as destination:
                    while chunk := source.read(1024 * 1024):
                        size += len(chunk)
                        if used + size > max_bytes:
                            raise ValueError("snapshot_capacity_exceeded")
                        digest.update(chunk)
                        destination.write(chunk)
                    destination.flush()
                    os.fsync(destination.fileno())
                    after = os.fstat(source.fileno())
                current = item.path.stat()

                def signature(stat):
                    return (stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)

                if signature(before) != signature(after) or signature(before) != signature(current):
                    raise ValueError("snapshot_source_changed")
                used += size
                artifacts.append(
                    {
                        "key": item.key,
                        "path": target.relative_to(temp).as_posix(),
                        "sha256": digest.hexdigest(),
                        "size": size,
                        "kind": item.kind,
                    }
                )
            except (OSError, ValueError) as error:
                target.unlink(missing_ok=True)
                errors.append(
                    f"{str(error) if isinstance(error, ValueError) else 'snapshot_file_unavailable'}:{item.key}"
                )
        manifest = SnapshotManifest(1, run_key, artifacts, diagnostics, list(dict.fromkeys(errors)))
        with (temp / "manifest.json").open("x", encoding="utf-8") as stream:
            json.dump(manifest.to_dict(), stream, ensure_ascii=False, sort_keys=True)
            stream.flush()
            os.fsync(stream.fileno())
        os.rename(temp, run_dir)
        return manifest
    finally:
        if temp.exists():
            shutil.rmtree(temp)


def load_run_snapshot(run: dict) -> SnapshotManifest:
    value = json.loads(run.get("snapshot_json") or "null")
    if not isinstance(value, dict):
        raise ValueError("legacy_snapshot_unavailable")
    if value.get("version") != 1 or value.get("external_run_key") != run["local_run_key"]:
        raise ValueError("run_snapshot_invalid")
    return SnapshotManifest(**value)


def collect_snapshot_inputs(
    config, project_dir: Path, run_output_dir: Path | None = None
) -> list[SnapshotInput]:
    from shopops_reporter.project import artifact_key, artifact_type, matching_files
    from shopops_reporter.result_mapping.policy import is_v2_reference

    patterns, protected = list(config.artifacts), set()
    reference = config.result_contract
    if is_v2_reference(reference) and reference.get("run_validated") is not True:
        return []
    if isinstance(reference, dict):
        for artifact in (reference.get("snapshot") or {}).get("artifacts", []):
            if artifact.get("visibility") in {"sensitive", "forbidden"}:
                protected.add(artifact["path"])
            elif reference.get("run_validated") is True and artifact.get("visibility") in {
                "public",
                "internal",
            }:
                patterns.append(artifact["path"])
    collected = {}
    for root in (project_dir, run_output_dir):
        if root is None:
            continue
        for path in matching_files(root, patterns):
            if artifact_type(path) and path.relative_to(root.resolve()).as_posix() not in protected:
                key = artifact_key(path, root)
                collected[key] = SnapshotInput(key, path, artifact_type(path))
    return list(collected.values())
