from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from shopops_reporter.result_mapping.loader import ResultContractSnapshot


MAX_JSON_BYTES = 10 * 1024 * 1024
MAX_TEXT_BYTES = 512 * 1024
MAX_TABULAR_ROWS = 1_000_000
MAX_TABULAR_COLUMNS = 200


@dataclass(frozen=True)
class MappingOutcome:
    result: dict[str, Any]
    warnings: tuple[str, ...]


def evaluate_result_contract(
    snapshot: ResultContractSnapshot,
    project_root: Path,
) -> MappingOutcome:
    payload = snapshot.payload
    warnings: list[str] = []
    cache: dict[str, Any] = {}

    def resolve(binding: dict[str, Any], label: str, *, optional=False) -> Any:
        if "value" in binding:
            return binding["value"]
        source_name = binding["source"]
        source = payload["sources"][source_name]
        try:
            return _read_binding(
                source,
                binding["selector"],
                binding.get("aggregate", "first"),
                project_root,
                cache,
            )
        except (OSError, UnicodeError, ValueError, KeyError, IndexError, TypeError) as error:
            if not (snapshot.is_v2 and optional and isinstance(error, (KeyError, IndexError))):
                warnings.append(f"result_mapping_failed:{label}:{type(error).__name__}")
            return None

    summary_definition = payload["summary"]
    headline = resolve(summary_definition["headline"], "summary.headline")
    description = (
        resolve(summary_definition["description"], "summary.description", optional=True)
        if "description" in summary_definition
        else None
    )
    if not isinstance(headline, str) or not headline.strip():
        warnings.append("required_result_field_missing:summary.headline")
        headline = "运行已结束，但未生成业务摘要"
    summary: dict[str, str] = {"headline": headline.strip()[:300]}
    if description is not None:
        summary["description"] = str(description).strip()[:2000]

    business_definition = payload["business_status"]
    raw_business_status = resolve(business_definition["value"], "business_status")
    business_status = business_definition.get("mapping", {}).get(
        str(raw_business_status),
        business_definition["default"],
    )
    if snapshot.is_v2 and str(raw_business_status) not in business_definition.get("mapping", {}):
        warnings.append("unknown_business_status")

    metrics = _map_fields(payload.get("metrics", []), resolve, warnings, include_unit=True, strict=snapshot.is_v2)
    details = _map_fields(payload.get("details", []), resolve, warnings, include_unit=False, strict=snapshot.is_v2)
    claims: list[dict[str, Any]] = []
    for claim in payload.get("claims", []):
        if claim["visibility"] in {"sensitive", "forbidden"}:
            if not snapshot.is_v2:
                warnings.append(f"protected_result_field_omitted:{claim['key']}")
            continue
        raw_status = resolve(claim["status"], f"claim.{claim['key']}.status", optional=not claim.get('required'))
        if snapshot.is_v2 and raw_status is None and not claim.get('required'):
            continue
        valid_status = isinstance(raw_status, str) and raw_status in {"confirmed", "not_met", "unknown"}
        status = raw_status if valid_status else "unknown"
        if snapshot.is_v2 and not valid_status:
            warnings.append(f"result_claim_status_invalid:{claim['key']}")
        evidence_refs = [
            str(value)
            for index, binding in enumerate(claim.get("evidence", []))
            if (value := resolve(binding, f"claim.{claim['key']}.evidence.{index}"))
        ][:20]
        if status == "confirmed" and not evidence_refs:
            warnings.append(f"confirmed_claim_missing_evidence:{claim['key']}")
            status = "unknown"
        item: dict[str, Any] = {
            "key": claim["key"],
            "label": claim["label"],
            "status": status,
            "evidence_refs": evidence_refs,
            "visibility": claim["visibility"],
        }
        if "description" in claim:
            value = resolve(claim["description"], f"claim.{claim['key']}.description", optional=True)
            if value is not None:
                item["description"] = str(value)[:2000]
        claims.append(item)

    artifacts: list[dict[str, Any]] = []
    root = project_root.resolve()
    for artifact in payload.get("artifacts", []):
        if artifact["visibility"] in {"sensitive", "forbidden"}:
            if not snapshot.is_v2:
                warnings.append(f"protected_result_artifact_omitted:{artifact['key']}")
            continue
        path = (root / artifact["path"]).resolve()
        try:
            path.relative_to(root)
        except ValueError:
            warnings.append(f"result_artifact_outside_project:{artifact['key']}")
            continue
        if not path.is_file() or path.is_symlink():
            if artifact.get("required"):
                warnings.append(f"required_result_artifact_missing:{artifact['key']}")
            continue
        artifacts.append(
            {
                "key": artifact["key"],
                "name": artifact["label"],
                "path": artifact["path"],
                "type": artifact["type"],
                "visibility": artifact["visibility"],
            }
        )

    result = {
        "result_schema": "shopops.run_result.v2",
        "contract": {"version": 0, "digest": snapshot.digest},
        "business_status": business_status,
        "summary": summary,
        "metrics": metrics,
        "details": details,
        "claims": claims,
        "artifacts": artifacts,
        "remote_write_performed": None,
    }
    return MappingOutcome(result=result, warnings=tuple(dict.fromkeys(warnings)))


def _map_fields(
    definitions: list[dict[str, Any]],
    resolve,
    warnings: list[str],
    *,
    include_unit: bool,
    strict: bool = False,
) -> list[dict[str, Any]]:
    fields: list[dict[str, Any]] = []
    for field in definitions:
        key = field["key"]
        if field["visibility"] in {"sensitive", "forbidden"}:
            if not strict:
                warnings.append(f"protected_result_field_omitted:{key}")
            continue
        raw_value = resolve(field["value"], key, optional=not field.get("required"))
        value = _typed_value(raw_value, field["value_type"])
        if value is None:
            if strict and raw_value is not None:
                warnings.append(f"result_type_mismatch:{key}")
            if field.get("required"):
                warnings.append(f"required_result_field_missing:{key}")
            continue
        item = {
            "key": key,
            "label": field["label"],
            "value": value,
            "visibility": field["visibility"],
        }
        if include_unit and field.get("unit"):
            item["unit"] = field["unit"]
        if include_unit and field.get("standard_metric"):
            item["standard_metric"] = field["standard_metric"]
        fields.append(item)
    return fields


def _typed_value(value: Any, value_type: str) -> str | int | float | bool | None:
    if value_type == "string":
        return value if isinstance(value, str) else None
    if value_type == "boolean":
        return value if isinstance(value, bool) else None
    if value_type == "integer":
        return value if isinstance(value, int) and not isinstance(value, bool) else None
    if value_type == "number":
        return value if isinstance(value, (int, float)) and not isinstance(value, bool) else None
    return None


def _read_binding(
    source: dict[str, Any],
    selector: str,
    aggregate: str,
    project_root: Path,
    cache: dict[str, Any],
) -> Any:
    path = (project_root.resolve() / source["path"]).resolve()
    path.relative_to(project_root.resolve())
    if path.is_symlink() or not path.is_file():
        raise OSError("source unavailable")
    cache_key = f"{source['type']}:{path}:{source.get('sheet')}:{source.get('encoding')}"
    if source["type"] == "json":
        if cache_key not in cache:
            if path.stat().st_size > MAX_JSON_BYTES:
                raise ValueError("json source too large")
            cache[cache_key] = json.loads(path.read_text(encoding="utf-8"))
        return _json_pointer(cache[cache_key], selector)
    if source["type"] == "csv":
        return _tabular_value(_csv_rows(path, source.get("encoding") or "utf-8-sig"), selector, aggregate)
    if source["type"] == "xlsx":
        return _xlsx_value(path, source.get("sheet"), selector, aggregate)
    if path.stat().st_size > MAX_TEXT_BYTES:
        raise ValueError("text source too large")
    text = path.read_text(encoding=source.get("encoding") or "utf-8")
    if selector == "text":
        return text
    if selector == "line_count":
        return len(text.splitlines())
    if selector.startswith("contains:"):
        return selector.removeprefix("contains:") in text
    raise ValueError("text selector unsupported")


def _json_pointer(value: Any, pointer: str) -> Any:
    if pointer == "":
        return value
    if not pointer.startswith("/"):
        raise ValueError("json pointer invalid")
    current = value
    for raw in pointer[1:].split("/"):
        key = raw.replace("~1", "/").replace("~0", "~")
        if isinstance(current, dict):
            current = current[key]
        elif isinstance(current, list) and key.isdigit():
            current = current[int(key)]
        else:
            raise KeyError(key)
    return current


def _csv_rows(path: Path, encoding: str):
    with path.open("r", encoding=encoding, newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or len(reader.fieldnames) > MAX_TABULAR_COLUMNS:
            raise ValueError("csv columns invalid")
        for index, row in enumerate(reader):
            if index >= MAX_TABULAR_ROWS:
                raise ValueError("csv row limit exceeded")
            yield row


def _tabular_value(rows, selector: str, aggregate: str) -> Any:
    values: list[Any] = []
    count = 0
    for row in rows:
        if selector not in row:
            raise KeyError(selector)
        count += 1
        if aggregate == "count":
            continue
        value = row[selector]
        if aggregate in {"sum", "min", "max"}:
            try:
                numeric = Decimal(str(value))
                if not numeric.is_finite():
                    raise InvalidOperation
                value = int(numeric) if numeric == numeric.to_integral_value() else float(numeric)
            except (InvalidOperation, TypeError, ValueError) as error:
                raise ValueError("tabular numeric value invalid") from error
        values.append(value)
    if aggregate == "count":
        return count
    if not values:
        return None
    if aggregate == "first":
        return values[0]
    if aggregate == "sum":
        return sum(values)
    return min(values) if aggregate == "min" else max(values)


def _xlsx_value(path: Path, sheet: str | None, selector: str, aggregate: str) -> Any:
    try:
        from openpyxl import load_workbook
    except ImportError as error:
        raise ValueError("xlsx support unavailable") from error
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        visible = [item for item in workbook.worksheets if item.sheet_state == "visible"]
        if sheet is None and len(visible) != 1:
            raise ValueError("xlsx sheet required")
        worksheet = workbook[sheet] if sheet else visible[0]
        rows = worksheet.iter_rows(values_only=True)
        headers = next(rows, None)
        if headers is None or len(headers) > MAX_TABULAR_COLUMNS:
            raise ValueError("xlsx headers invalid")
        names = [str(item) if item is not None else "" for item in headers]
        if selector not in names:
            raise KeyError(selector)
        column = names.index(selector)
        return _tabular_value(
            ({selector: row[column] if column < len(row) else None} for row in rows),
            selector,
            aggregate,
        )
    finally:
        workbook.close()
