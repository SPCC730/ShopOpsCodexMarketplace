from __future__ import annotations

import hashlib
import json
import copy
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml
from shopops_reporter.fingerprint import validate_fingerprint_policy
from shopops_reporter.task_context import TaskContext, confined_path
from shopops_reporter.result_mapping.policy import CONTRACT_V2, reporting_policy, validate_reporting_policy


CONTRACT_SCHEMA = "shopops.result_contract.v1"
CONTRACT_FILE = Path(".shopops/result-contract.yaml")
TOP_LEVEL_KEYS = {
    "schema",
    "name",
    "project_fingerprint",
    "script_version",
    "sources",
    "summary",
    "business_status",
    "metrics",
    "details",
    "claims",
    "artifacts",
    "samples",
    "fingerprint",
}
SOURCE_KEYS = {"type", "path", "sheet", "encoding"}
BINDING_KEYS = {"source", "selector", "aggregate", "value"}
FIELD_KEYS = {
    "key",
    "label",
    "value",
    "value_type",
    "visibility",
    "required",
    "unit",
    "standard_metric",
}
CLAIM_KEYS = {"key", "label", "status", "description", "visibility", "required", "evidence"}
ARTIFACT_KEYS = {"key", "label", "path", "type", "visibility", "required"}
VISIBILITIES = {"public", "internal", "sensitive", "forbidden"}
BUSINESS_STATUSES = {
    "completed",
    "partial",
    "no_change",
    "skipped",
    "waiting_manual",
    "failed",
}


class ResultContractError(ValueError):
    pass


@dataclass(frozen=True)
class ResultContractSnapshot:
    payload: dict[str, Any]
    digest: str
    path: Path

    @property
    def project_fingerprint(self) -> str | None:
        return self.payload.get("project_fingerprint")

    @property
    def is_v2(self) -> bool:
        return self.payload.get("schema") == CONTRACT_V2

    def validate_project(self, config, fingerprint: str) -> None:
        if self.is_v2:
            if validate_reporting_policy(self.payload["reporting_policy"]) != reporting_policy(config):
                raise ResultContractError("result_contract_reporting_policy_mismatch")
        else:
            if self.project_fingerprint != fingerprint:
                raise ResultContractError("result_contract_project_mismatch")
            if self.payload.get("fingerprint") != config.fingerprint:
                raise ResultContractError("result_contract_fingerprint_policy_mismatch")


def canonical_digest(payload: dict[str, Any]) -> str:
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return f"sha256:{hashlib.sha256(encoded).hexdigest()}"


def load_result_contract(
    project_root: Path,
    path: Path | None = None,
    *, task_key: str | None = None,
) -> ResultContractSnapshot:
    root = project_root.resolve()
    target = path or TaskContext(root, task_key).contract_path
    try:
        target = confined_path(root, target.relative_to(root).as_posix())
    except ValueError as error:
        raise ResultContractError("result_contract_path_outside_project") from error
    if not target.is_file() or target.is_symlink():
        raise ResultContractError("result_contract_not_found")
    if target.stat().st_size > 256 * 1024:
        raise ResultContractError("result_contract_too_large")
    try:
        payload = yaml.safe_load(target.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, yaml.YAMLError) as error:
        raise ResultContractError("result_contract_invalid_yaml") from error
    if not isinstance(payload, dict):
        raise ResultContractError("result_contract_invalid")
    return snapshot_from_payload(payload, root, path=target)


def snapshot_from_payload(
    payload: dict[str, Any], root: Path, *, path: Path | None = None,
) -> ResultContractSnapshot:
    payload = copy.deepcopy(payload)
    _validate_contract(payload, root.resolve())
    return ResultContractSnapshot(
        payload=payload, digest=canonical_digest(payload), path=path or root / CONTRACT_FILE,
    )


def _exact_keys(value: dict[str, Any], allowed: set[str], label: str) -> None:
    unknown = set(value) - allowed
    if unknown:
        raise ResultContractError(f"{label}_unknown_field:{sorted(unknown)[0]}")


def _validate_binding(value: Any, sources: set[str]) -> None:
    if not isinstance(value, dict):
        raise ResultContractError("result_binding_invalid")
    _exact_keys(value, BINDING_KEYS, "result_binding")
    has_constant = "value" in value
    has_source = "source" in value or "selector" in value
    if has_constant == has_source:
        raise ResultContractError("result_binding_mode_invalid")
    if has_source:
        if value.get("source") not in sources or not isinstance(value.get("selector"), str):
            raise ResultContractError("result_binding_source_invalid")
    if value.get("aggregate", "first") not in {"first", "count", "sum", "min", "max"}:
        raise ResultContractError("result_binding_aggregate_invalid")


def _safe_relative_path(value: Any, root: Path) -> str:
    if not isinstance(value, str) or not value or "\x00" in value or "\\" in value:
        raise ResultContractError("result_source_path_invalid")
    candidate = Path(value)
    if candidate.is_absolute() or any(part in {"", ".", ".."} for part in candidate.parts):
        raise ResultContractError("result_source_path_invalid")
    target = (root / candidate).resolve()
    try:
        target.relative_to(root)
    except ValueError as error:
        raise ResultContractError("result_source_path_outside_project") from error
    return candidate.as_posix()


def _validate_contract(payload: dict[str, Any], root: Path) -> None:
    v2 = payload.get("schema") == CONTRACT_V2
    allowed = (TOP_LEVEL_KEYS - {"project_fingerprint", "script_version", "fingerprint"}
               | {"business_meaning", "reporting_policy"}) if v2 else TOP_LEVEL_KEYS
    _exact_keys(payload, allowed, "result_contract")
    if payload.get("schema") not in {CONTRACT_SCHEMA, CONTRACT_V2}:
        raise ResultContractError("result_contract_schema_unsupported")
    if not isinstance(payload.get("name"), str) or not payload["name"].strip():
        raise ResultContractError("result_contract_name_invalid")
    if v2:
        meaning = payload.get("business_meaning")
        if not isinstance(meaning, str) or not meaning.strip() or len(meaning) > 10000:
            raise ResultContractError("result_contract_business_meaning_required")
        validate_reporting_policy(payload.get("reporting_policy"))
    elif not isinstance(payload.get("project_fingerprint"), str):
        raise ResultContractError("result_contract_fingerprint_invalid")
    policy = payload.get("fingerprint")
    if policy is not None:
        try:
            validate_fingerprint_policy(policy)
        except ValueError as error:
            raise ResultContractError(str(error)) from error
        if not re.fullmatch(r"sha256-v2:[0-9a-f]{64}", payload["project_fingerprint"]):
            raise ResultContractError("result_contract_fingerprint_version_mismatch")
    elif not v2 and payload["project_fingerprint"].startswith("sha256-v2:"):
        raise ResultContractError("result_contract_fingerprint_policy_missing")
    sources = payload.get("sources")
    if not isinstance(sources, dict) or not 1 <= len(sources) <= 20:
        raise ResultContractError("result_contract_sources_invalid")
    for source_name, source in sources.items():
        if not isinstance(source_name, str) or not isinstance(source, dict):
            raise ResultContractError("result_source_invalid")
        _exact_keys(source, SOURCE_KEYS, "result_source")
        if source.get("type") not in {"json", "csv", "xlsx", "text"}:
            raise ResultContractError("result_source_type_invalid")
        source["path"] = _safe_relative_path(source.get("path"), root)

    source_names = set(sources)
    summary = payload.get("summary")
    if not isinstance(summary, dict):
        raise ResultContractError("result_summary_invalid")
    _exact_keys(summary, {"headline", "description"}, "result_summary")
    _validate_binding(summary.get("headline"), source_names)
    if "description" in summary:
        _validate_binding(summary["description"], source_names)

    business = payload.get("business_status")
    if not isinstance(business, dict):
        raise ResultContractError("business_status_invalid")
    _exact_keys(business, {"value", "mapping", "default"}, "business_status")
    _validate_binding(business.get("value"), source_names)
    if business.get("default") not in BUSINESS_STATUSES:
        raise ResultContractError("business_status_default_invalid")
    mapping = business.get("mapping", {})
    if not isinstance(mapping, dict) or any(value not in BUSINESS_STATUSES for value in mapping.values()):
        raise ResultContractError("business_status_mapping_invalid")

    field_keys: set[str] = set()
    for collection_name, maximum in (("metrics", 50), ("details", 100)):
        collection = payload.get(collection_name, [])
        if not isinstance(collection, list) or len(collection) > maximum:
            raise ResultContractError(f"result_{collection_name}_invalid")
        for field in collection:
            if not isinstance(field, dict):
                raise ResultContractError("result_field_invalid")
            _exact_keys(field, FIELD_KEYS, "result_field")
            _validate_output_identity(field, field_keys)
            _validate_binding(field.get("value"), source_names)
            if field.get("value_type") not in {"string", "integer", "number", "boolean"}:
                raise ResultContractError("result_field_type_invalid")

    claims = payload.get("claims", [])
    if not isinstance(claims, list) or len(claims) > 50:
        raise ResultContractError("result_claims_invalid")
    for claim in claims:
        if not isinstance(claim, dict):
            raise ResultContractError("result_claim_invalid")
        _exact_keys(claim, CLAIM_KEYS, "result_claim")
        _validate_output_identity(claim, field_keys)
        _validate_binding(claim.get("status"), source_names)
        if "description" in claim:
            _validate_binding(claim["description"], source_names)
        evidence = claim.get("evidence", [])
        if not isinstance(evidence, list) or len(evidence) > 20:
            raise ResultContractError("result_claim_evidence_invalid")
        for binding in evidence:
            _validate_binding(binding, source_names)

    artifacts = payload.get("artifacts", [])
    if not isinstance(artifacts, list) or len(artifacts) > 100:
        raise ResultContractError("result_artifacts_invalid")
    artifact_keys: set[str] = set()
    for artifact in artifacts:
        if not isinstance(artifact, dict):
            raise ResultContractError("result_artifact_invalid")
        _exact_keys(artifact, ARTIFACT_KEYS, "result_artifact")
        _validate_output_identity(artifact, artifact_keys)
        artifact["path"] = _safe_relative_path(artifact.get("path"), root)

    samples = payload.get("samples")
    if not isinstance(samples, list) or not 4 <= len(samples) <= 20:
        raise ResultContractError("result_contract_samples_invalid")
    sample_statuses: set[str] = set()
    for sample in samples:
        if not isinstance(sample, dict):
            raise ResultContractError("result_contract_sample_invalid")
        _exact_keys(sample, {"name", "business_status", "fixture"}, "result_contract_sample")
        if sample.get("business_status") not in BUSINESS_STATUSES:
            raise ResultContractError("result_contract_sample_status_invalid")
        sample_statuses.add(sample["business_status"])
        _safe_relative_path(sample.get("fixture"), root)
        if policy and sample["fixture"] in policy["outputs"]:
            raise ResultContractError("result_contract_sample_excluded")
    if not {"completed", "partial", "no_change", "failed"}.issubset(sample_statuses):
        raise ResultContractError("result_contract_sample_coverage_incomplete")


def _validate_output_identity(value: dict[str, Any], seen: set[str]) -> None:
    key = value.get("key")
    if not isinstance(key, str) or not key or key in seen:
        raise ResultContractError("result_field_key_invalid")
    seen.add(key)
    if not isinstance(value.get("label"), str) or not value["label"].strip():
        raise ResultContractError("result_field_label_invalid")
    if value.get("visibility") not in VISIBILITIES:
        raise ResultContractError("result_field_visibility_invalid")
