from __future__ import annotations

import json
import shutil
import sqlite3
import tempfile
import time
from contextlib import closing, contextmanager
from dataclasses import asdict
from pathlib import Path
from typing import Any, Iterator

from shopops_reporter.config import ProjectConfig, ensure_private_directory, reporter_home


SCHEMA = """
CREATE TABLE IF NOT EXISTS local_run (
    local_run_key TEXT PRIMARY KEY,
    integration_id TEXT NOT NULL,
    project_dir TEXT NOT NULL,
    config_json TEXT NOT NULL,
    project_fingerprint TEXT NOT NULL,
    git_json TEXT NOT NULL,
    environment_json TEXT NOT NULL,
    started_at TEXT NOT NULL,
    local_status TEXT NOT NULL DEFAULT 'running',
    ended_at TEXT,
    exit_code INTEGER,
    result_json TEXT NOT NULL DEFAULT '{}',
    server_run_id TEXT,
    last_uploaded_sequence INTEGER NOT NULL DEFAULT 0,
    next_sequence INTEGER NOT NULL DEFAULT 1,
    last_heartbeat_at REAL,
    upload_state TEXT NOT NULL DEFAULT 'pending',
    retry_at REAL NOT NULL DEFAULT 0,
    retry_count INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    live_report_token TEXT,
    live_report_path TEXT,
    logs_partial INTEGER NOT NULL DEFAULT 0,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS local_log (
    local_run_key TEXT NOT NULL,
    sequence INTEGER NOT NULL,
    timestamp TEXT NOT NULL,
    stream TEXT NOT NULL,
    level TEXT,
    message TEXT NOT NULL,
    PRIMARY KEY (local_run_key, sequence),
    FOREIGN KEY (local_run_key) REFERENCES local_run(local_run_key) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS local_artifact (
    local_run_key TEXT NOT NULL,
    artifact_key TEXT NOT NULL,
    path TEXT NOT NULL,
    display_name TEXT NOT NULL,
    artifact_type TEXT NOT NULL,
    sha256 TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    last_error TEXT,
    PRIMARY KEY (local_run_key, artifact_key),
    FOREIGN KEY (local_run_key) REFERENCES local_run(local_run_key) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS ix_local_run_pending
ON local_run(upload_state, retry_at, created_at);
"""


class Spool:
    def __init__(self, path: Path | None = None, *, max_bytes: int = 500 * 1024 * 1024):
        home = ensure_private_directory((path or reporter_home() / "spool.db").parent)
        self.path = path or home / "spool.db"
        self.max_bytes = max_bytes
        self.initialize()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path, timeout=15)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA busy_timeout=15000")
        try:
            yield connection
        finally:
            connection.close()

    def initialize(self) -> None:
        with self.connect() as connection:
            connection.execute("PRAGMA journal_mode=WAL")
            connection.executescript(SCHEMA)
            columns = {
                row["name"]
                for row in connection.execute("PRAGMA table_info(local_run)").fetchall()
            }
            if "logs_partial" not in columns:
                connection.execute(
                    "ALTER TABLE local_run ADD COLUMN logs_partial INTEGER NOT NULL DEFAULT 0"
                )
            connection.commit()

    def create_run(
        self,
        *,
        local_run_key: str,
        config: ProjectConfig,
        project_dir: Path,
        project_fingerprint: str,
        git_metadata: dict[str, Any],
        environment_metadata: dict[str, Any],
        started_at: str,
    ) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                INSERT INTO local_run (
                    local_run_key, integration_id, project_dir, config_json,
                    project_fingerprint, git_json, environment_json, started_at,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    local_run_key,
                    config.integration_id,
                    str(project_dir),
                    json.dumps(asdict(config), ensure_ascii=False),
                    project_fingerprint,
                    json.dumps(git_metadata, ensure_ascii=False),
                    json.dumps(environment_metadata, ensure_ascii=False),
                    started_at,
                    time.time(),
                ),
            )
            connection.commit()

    def append_log(
        self,
        local_run_key: str,
        *,
        timestamp: str,
        stream: str,
        message: str,
        level: str | None = None,
    ) -> int:
        if self._storage_bytes() >= self.max_bytes:
            with self.connect() as connection:
                connection.execute(
                    "UPDATE local_run SET logs_partial = 1 WHERE local_run_key = ?",
                    (local_run_key,),
                )
                connection.commit()
            return 0
        with self.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT next_sequence FROM local_run WHERE local_run_key = ?",
                (local_run_key,),
            ).fetchone()
            if row is None:
                connection.rollback()
                raise RuntimeError(f"本地 Run 不存在: {local_run_key}")
            sequence = int(row["next_sequence"])
            connection.execute(
                """
                INSERT INTO local_log (
                    local_run_key, sequence, timestamp, stream, level, message
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (local_run_key, sequence, timestamp, stream, level, message),
            )
            connection.execute(
                "UPDATE local_run SET next_sequence = ? WHERE local_run_key = ?",
                (sequence + 1, local_run_key),
            )
            connection.commit()
            return sequence

    def finish_run(
        self,
        local_run_key: str,
        *,
        status: str,
        exit_code: int,
        ended_at: str,
        result: dict[str, Any],
        live_report_token: str | None = None,
        live_report_path: Path | None = None,
    ) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                UPDATE local_run
                SET local_status = ?, exit_code = ?, ended_at = ?, result_json = ?,
                    live_report_token = ?, live_report_path = ?, retry_at = 0
                WHERE local_run_key = ?
                """,
                (
                    status,
                    exit_code,
                    ended_at,
                    json.dumps(result, ensure_ascii=False),
                    live_report_token,
                    str(live_report_path) if live_report_path else None,
                    local_run_key,
                ),
            )
            connection.commit()

    def pending_runs(self, limit: int = 20) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute(
                """
                SELECT * FROM local_run
                WHERE upload_state != 'complete' AND retry_at <= ?
                ORDER BY created_at
                LIMIT ?
                """,
                (time.time(), limit),
            ).fetchall()
        return [dict(row) for row in rows]

    def get_run(self, local_run_key: str) -> dict[str, Any] | None:
        with self.connect() as connection:
            row = connection.execute(
                "SELECT * FROM local_run WHERE local_run_key = ?",
                (local_run_key,),
            ).fetchone()
        return dict(row) if row else None

    def set_server_run(self, local_run_key: str, server_run_id: str) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                UPDATE local_run
                SET server_run_id = ?, retry_count = 0, retry_at = 0, last_error = NULL
                WHERE local_run_key = ?
                """,
                (server_run_id, local_run_key),
            )
            connection.commit()

    def log_batch(self, local_run_key: str, after: int, limit: int = 100) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute(
                """
                SELECT sequence, timestamp, stream, level, message
                FROM local_log
                WHERE local_run_key = ? AND sequence > ?
                ORDER BY sequence
                LIMIT ?
                """,
                (local_run_key, after, limit),
            ).fetchall()
        return [dict(row) for row in rows]

    def acknowledge_logs(self, local_run_key: str, sequence: int) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                UPDATE local_run
                SET last_uploaded_sequence = MAX(last_uploaded_sequence, ?),
                    retry_count = 0, retry_at = 0, last_error = NULL
                WHERE local_run_key = ?
                """,
                (sequence, local_run_key),
            )
            connection.commit()

    def heartbeat_sent(self, local_run_key: str) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                UPDATE local_run
                SET last_heartbeat_at = ?, retry_count = 0, retry_at = 0, last_error = NULL
                WHERE local_run_key = ?
                """,
                (time.time(), local_run_key),
            )
            connection.commit()

    def complete_upload(self, local_run_key: str) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                UPDATE local_run
                SET upload_state = 'complete', retry_count = 0,
                    retry_at = 0, last_error = NULL
                WHERE local_run_key = ?
                """,
                (local_run_key,),
            )
            connection.commit()

    def record_error(self, local_run_key: str, error: Exception) -> None:
        with self.connect() as connection:
            row = connection.execute(
                "SELECT retry_count FROM local_run WHERE local_run_key = ?",
                (local_run_key,),
            ).fetchone()
            count = (int(row["retry_count"]) if row else 0) + 1
            delay = min(60.0, 2 ** min(count, 6))
            connection.execute(
                """
                UPDATE local_run
                SET retry_count = ?, retry_at = ?, last_error = ?
                WHERE local_run_key = ?
                """,
                (count, time.time() + delay, str(error)[:1000], local_run_key),
            )
            connection.commit()

    def add_artifact(
        self,
        local_run_key: str,
        *,
        artifact_key: str,
        path: Path,
        artifact_type: str,
        sha256: str,
    ) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                INSERT OR IGNORE INTO local_artifact (
                    local_run_key, artifact_key, path, display_name,
                    artifact_type, sha256
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    local_run_key,
                    artifact_key,
                    str(path),
                    path.name,
                    artifact_type,
                    sha256,
                ),
            )
            connection.commit()

    def pending_artifacts(self, local_run_key: str) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute(
                """
                SELECT * FROM local_artifact
                WHERE local_run_key = ? AND status = 'pending'
                ORDER BY artifact_key
                """,
                (local_run_key,),
            ).fetchall()
        return [dict(row) for row in rows]

    def artifact_finished(
        self,
        local_run_key: str,
        artifact_key: str,
        *,
        accepted: bool,
        error: str | None = None,
    ) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                UPDATE local_artifact SET status = ?, last_error = ?
                WHERE local_run_key = ? AND artifact_key = ?
                """,
                ("uploaded" if accepted else "failed", error, local_run_key, artifact_key),
            )
            connection.commit()

    def artifact_incomplete(self, local_run_key: str) -> bool:
        with self.connect() as connection:
            row = connection.execute(
                """
                SELECT COUNT(*) AS total FROM local_artifact
                WHERE local_run_key = ? AND status = 'failed'
                """,
                (local_run_key,),
            ).fetchone()
        return bool(row and row["total"])

    def queue_summary(self) -> dict[str, int]:
        with self.connect() as connection:
            runs = connection.execute(
                "SELECT COUNT(*) FROM local_run WHERE upload_state != 'complete'"
            ).fetchone()[0]
            logs = connection.execute(
                """
                SELECT COUNT(*) FROM local_log l
                JOIN local_run r ON r.local_run_key = l.local_run_key
                WHERE l.sequence > r.last_uploaded_sequence
                """
            ).fetchone()[0]
        return {"pending_runs": int(runs), "pending_logs": int(logs)}

    @staticmethod
    def queue_summary_read_only(path: Path | None = None) -> dict[str, int]:
        spool_path = path or reporter_home() / "spool.db"
        if not spool_path.is_file():
            return {"pending_runs": 0, "pending_logs": 0}
        source_wal = spool_path.with_name(f"{spool_path.name}-wal")
        with tempfile.TemporaryDirectory(prefix="shopops-reporter-status-") as temporary:
            for attempt in range(3):
                snapshot = Path(temporary) / str(attempt) / "spool.db"
                snapshot.parent.mkdir()
                shutil.copyfile(spool_path, snapshot)
                try:
                    if source_wal.is_file():
                        shutil.copyfile(source_wal, snapshot.with_name("spool.db-wal"))
                except FileNotFoundError:
                    continue
                try:
                    with closing(sqlite3.connect(snapshot, timeout=15)) as connection:
                        runs = connection.execute(
                            "SELECT COUNT(*) FROM local_run WHERE upload_state != 'complete'"
                        ).fetchone()[0]
                        logs = connection.execute(
                            """
                            SELECT COUNT(*) FROM local_log l
                            JOIN local_run r ON r.local_run_key = l.local_run_key
                            WHERE l.sequence > r.last_uploaded_sequence
                            """
                        ).fetchone()[0]
                except sqlite3.DatabaseError:
                    if attempt < 2:
                        continue
                    raise
                return {"pending_runs": int(runs), "pending_logs": int(logs)}
        raise RuntimeError("无法读取 Reporter 本地队列快照")

    def has_pending(self) -> bool:
        return self.queue_summary()["pending_runs"] > 0

    def report_for_token(self, token: str) -> Path | None:
        with self.connect() as connection:
            row = connection.execute(
                "SELECT live_report_path FROM local_run WHERE live_report_token = ?",
                (token,),
            ).fetchone()
        if not row or not row["live_report_path"]:
            return None
        return Path(row["live_report_path"])

    def _storage_bytes(self) -> int:
        return sum(
            path.stat().st_size
            for path in (
                self.path,
                self.path.with_name(f"{self.path.name}-wal"),
                self.path.with_name(f"{self.path.name}-shm"),
            )
            if path.exists()
        )
