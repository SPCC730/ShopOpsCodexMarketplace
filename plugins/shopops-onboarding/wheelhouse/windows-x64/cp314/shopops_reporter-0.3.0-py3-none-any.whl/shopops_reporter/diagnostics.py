from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Any, Literal, Mapping, Sequence, TYPE_CHECKING

if TYPE_CHECKING:
    from shopops_reporter.config import ProjectConfig


MAX_DIAGNOSTIC_BYTES = 65_536
IDENTIFIER = re.compile(r"^[A-Za-z0-9_.-]{1,100}$")
SENSITIVE_KEY = re.compile(
    r"password|passwd|cookie|token|secret|authorization|otp|verification[_-]?code",
    re.IGNORECASE,
)
EXACT_TEXT_SUFFIXES = {".json", ".txt", ".log"}
GLOB_MARKERS = {"*", "?", "[", "]"}
UUID_PATTERN = re.compile(
    r"\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b",
    re.IGNORECASE,
)
ISO_TIME_PATTERN = re.compile(r"\b\d{4}-\d{2}-\d{2}[T ][0-9:.+-]+Z?\b")
UNIX_HOME_PATTERN = re.compile(r"/(?:Users|home)/[^/\s]+/")
WINDOWS_HOME_PATTERN = re.compile(r"[A-Za-z]:\\Users\\[^\\\s]+\\", re.IGNORECASE)
URL_QUERY_PATTERN = re.compile(r"(https?://[^\s?#]+)\?[^\s#]+")


@dataclass(frozen=True)
class DiagnosticsConfig:
    schema_version: int
    file: str


@dataclass(frozen=True)
class DiagnosticEvidenceRefV1:
    kind: Literal["log", "artifact"]
    sequence: int | None = None
    key: str | None = None


@dataclass(frozen=True)
class DiagnosticFailureV1:
    code: str
    stage: str
    type: str
    message: str
    retryable: bool


@dataclass(frozen=True)
class DiagnosticEnvelopeV1:
    schema_version: Literal[1]
    failure: DiagnosticFailureV1
    impact: dict[str, str]
    evidence_refs: tuple[DiagnosticEvidenceRefV1, ...]


@dataclass(frozen=True)
class DiagnosticReadResult:
    envelope: dict[str, Any] | None
    source: Literal["project_declared", "reporter_heuristic"] | None
    warnings: tuple[str, ...]


class DiagnosticValidationError(ValueError):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def _relative_text_path(value: str) -> str:
    normalized = value.strip().replace("\\", "/")
    path = PurePosixPath(normalized)
    if (
        not normalized
        or path.is_absolute()
        or PureWindowsPath(value).is_absolute()
        or any(part in {"", ".", ".."} for part in path.parts)
        or ":" in path.parts[0]
    ):
        raise ValueError("必须使用项目内的精确相对路径")
    if any(marker in normalized for marker in GLOB_MARKERS):
        raise ValueError("必须使用项目内的精确相对路径")
    if path.suffix.lower() not in EXACT_TEXT_SUFFIXES:
        raise ValueError("AI 可读产物必须是 JSON、TXT 或 LOG 文本文件")
    return path.as_posix()


def validate_ai_readable_paths(
    paths: list[str],
    artifact_rules: list[str],
) -> list[str]:
    result: list[str] = []
    for raw_path in paths:
        path = _relative_text_path(raw_path)
        if not any(PurePosixPath(path).match(rule.replace("\\", "/")) for rule in artifact_rules):
            raise ValueError(f"AI 可读路径必须被已有 artifact 规则覆盖: {path}")
        if path not in result:
            result.append(path)
    return result


def _has_sensitive_key(value: object) -> bool:
    if isinstance(value, dict):
        return any(
            SENSITIVE_KEY.search(str(key)) or _has_sensitive_key(child)
            for key, child in value.items()
        )
    if isinstance(value, (list, tuple)):
        return any(_has_sensitive_key(item) for item in value)
    return False


def _require_keys(value: dict[str, Any], expected: set[str]) -> None:
    if set(value) != expected:
        raise DiagnosticValidationError("invalid_diagnostic_envelope")


def _parse_envelope(value: object) -> DiagnosticEnvelopeV1:
    if not isinstance(value, dict):
        raise DiagnosticValidationError("invalid_diagnostic_envelope")
    if _has_sensitive_key(value):
        raise DiagnosticValidationError("sensitive_diagnostic_content")
    if value.get("schema_version") != 1:
        raise DiagnosticValidationError("unsupported_diagnostic_schema")
    _require_keys(value, {"schema_version", "failure", "impact", "evidence_refs"})
    failure = value.get("failure")
    if not isinstance(failure, dict):
        raise DiagnosticValidationError("invalid_diagnostic_envelope")
    _require_keys(failure, {"code", "stage", "type", "message", "retryable"})
    identifiers = [failure.get("code"), failure.get("stage"), failure.get("type")]
    if not all(isinstance(item, str) and IDENTIFIER.fullmatch(item) for item in identifiers):
        raise DiagnosticValidationError("invalid_diagnostic_envelope")
    message = failure.get("message")
    if not isinstance(message, str) or not message.strip() or len(message) > 2_000:
        raise DiagnosticValidationError("invalid_diagnostic_envelope")
    if not isinstance(failure.get("retryable"), bool):
        raise DiagnosticValidationError("invalid_diagnostic_envelope")
    impact = value.get("impact")
    if not isinstance(impact, dict) or not all(
        isinstance(key, str) and isinstance(item, str) for key, item in impact.items()
    ):
        raise DiagnosticValidationError("invalid_diagnostic_envelope")
    references = value.get("evidence_refs")
    if not isinstance(references, list) or len(references) > 50:
        raise DiagnosticValidationError("invalid_diagnostic_envelope")
    parsed_references: list[DiagnosticEvidenceRefV1] = []
    for reference in references:
        if not isinstance(reference, dict) or not set(reference) <= {"kind", "sequence", "key"}:
            raise DiagnosticValidationError("invalid_diagnostic_envelope")
        kind = reference.get("kind")
        sequence = reference.get("sequence")
        key = reference.get("key")
        if kind == "log" and isinstance(sequence, int) and sequence >= 0 and key is None:
            parsed_references.append(DiagnosticEvidenceRefV1(kind="log", sequence=sequence))
        elif kind == "artifact" and isinstance(key, str) and key and sequence is None:
            parsed_references.append(DiagnosticEvidenceRefV1(kind="artifact", key=key[:200]))
        else:
            raise DiagnosticValidationError("invalid_diagnostic_envelope")
    return DiagnosticEnvelopeV1(
        schema_version=1,
        failure=DiagnosticFailureV1(
            code=failure["code"],
            stage=failure["stage"],
            type=failure["type"],
            message=message.strip(),
            retryable=failure["retryable"],
        ),
        impact=dict(impact),
        evidence_refs=tuple(parsed_references),
    )


def _envelope_dict(envelope: DiagnosticEnvelopeV1) -> dict[str, Any]:
    return {
        "schema_version": envelope.schema_version,
        "failure": {
            "code": envelope.failure.code,
            "stage": envelope.failure.stage,
            "type": envelope.failure.type,
            "message": envelope.failure.message,
            "retryable": envelope.failure.retryable,
        },
        "impact": dict(envelope.impact),
        "evidence_refs": [
            {
                "kind": item.kind,
                **({"sequence": item.sequence} if item.kind == "log" else {"key": item.key}),
            }
            for item in envelope.evidence_refs
        ],
    }


def load_diagnostic_envelope(
    config: "ProjectConfig",
    project_dir: Path,
) -> DiagnosticReadResult:
    declaration = config.diagnostics
    if declaration is None:
        return DiagnosticReadResult(None, None, ())
    if not isinstance(declaration, dict) or set(declaration) != {"schema_version", "file"}:
        return DiagnosticReadResult(None, None, ("invalid_diagnostic_config",))
    if declaration.get("schema_version") != 1:
        return DiagnosticReadResult(None, None, ("unsupported_diagnostic_schema",))
    try:
        relative = _relative_text_path(str(declaration.get("file", "")))
        target = (project_dir.resolve() / relative).resolve()
        target.relative_to(project_dir.resolve())
    except (OSError, ValueError):
        return DiagnosticReadResult(None, None, ("invalid_diagnostic_path",))
    if not target.is_file():
        return DiagnosticReadResult(None, None, ("diagnostic_file_missing",))
    try:
        if target.stat().st_size > MAX_DIAGNOSTIC_BYTES:
            return DiagnosticReadResult(None, None, ("diagnostic_file_too_large",))
        value = json.loads(target.read_text(encoding="utf-8"))
        envelope = _parse_envelope(value)
    except UnicodeDecodeError:
        return DiagnosticReadResult(None, None, ("diagnostic_file_not_utf8",))
    except (OSError, json.JSONDecodeError):
        return DiagnosticReadResult(None, None, ("invalid_diagnostic_json",))
    except DiagnosticValidationError as exc:
        return DiagnosticReadResult(None, None, (exc.code,))
    return DiagnosticReadResult(_envelope_dict(envelope), "project_declared", ())


def _normalized_failure_message(value: str) -> str:
    normalized = UUID_PATTERN.sub("<uuid>", value)
    normalized = ISO_TIME_PATTERN.sub("<timestamp>", normalized)
    normalized = UNIX_HOME_PATTERN.sub("<home>/", normalized)
    normalized = WINDOWS_HOME_PATTERN.sub(lambda _match: "<home>\\", normalized)
    normalized = URL_QUERY_PATTERN.sub(r"\1?<query>", normalized)
    normalized = "\n".join(line.rstrip() for line in normalized.strip().splitlines())
    return normalized[-2_000:]


def extract_generic_diagnostic(
    logs: Sequence[Mapping[str, Any]],
    exit_code: int,
) -> dict[str, Any] | None:
    if exit_code == 0:
        return None
    candidates = [
        item
        for item in logs[-200:]
        if item.get("stream") == "stderr" or item.get("level") in {"error", "warning"}
    ]
    selected: list[Mapping[str, Any]] = []
    used = 0
    for item in reversed(candidates):
        message = str(item.get("message") or "")
        remaining = 24_000 - used
        if remaining <= 0:
            break
        selected.append({**item, "message": message[-remaining:]})
        used += min(len(message), remaining)
    selected.reverse()
    combined = "\n".join(str(item.get("message") or "") for item in selected).strip()
    failure_type = "nonzero_exit"
    code = f"exit_{exit_code}"
    if "Traceback (" in combined and re.search(r"\b[A-Za-z_][\w.]*Error\s*:", combined):
        failure_type = "python_exception"
        match = re.findall(r"\b([A-Za-z_][\w.]*Error)\s*:", combined)
        code = match[-1] if match else failure_type
    elif re.search(r"\b(?:TypeError|ReferenceError|RangeError|SyntaxError):", combined) and re.search(
        r"\n\s*at\s+", combined
    ):
        failure_type = "node_exception"
        match = re.search(r"\b(TypeError|ReferenceError|RangeError|SyntaxError):", combined)
        code = match.group(1) if match else failure_type
    elif "FullyQualifiedErrorId" in combined or "CategoryInfo" in combined:
        failure_type = "powershell_error"
        match = re.search(r"FullyQualifiedErrorId\s*:\s*([A-Za-z0-9_.-]+)", combined)
        code = match.group(1) if match else failure_type
    message = _normalized_failure_message(combined or f"process exited with code {exit_code}")
    references = [
        {"kind": "log", "sequence": int(item["sequence"])}
        for item in selected[-10:]
        if isinstance(item.get("sequence"), int)
    ]
    return {
        "schema_version": 1,
        "failure": {
            "code": re.sub(r"[^A-Za-z0-9_.-]", "_", code)[:100],
            "stage": "external_process",
            "type": failure_type,
            "message": message,
            "retryable": False,
        },
        "impact": {},
        "evidence_refs": references,
    }


def diagnostic_payload_for_run(
    config: "ProjectConfig",
    project_dir: Path,
    logs: Sequence[Mapping[str, Any]],
    exit_code: int,
) -> DiagnosticReadResult:
    if exit_code == 0:
        return DiagnosticReadResult(None, None, ())
    declared = load_diagnostic_envelope(config, project_dir)
    if declared.envelope is not None:
        return declared
    heuristic = extract_generic_diagnostic(logs, exit_code)
    return DiagnosticReadResult(
        envelope=heuristic,
        source="reporter_heuristic" if heuristic is not None else None,
        warnings=declared.warnings,
    )
