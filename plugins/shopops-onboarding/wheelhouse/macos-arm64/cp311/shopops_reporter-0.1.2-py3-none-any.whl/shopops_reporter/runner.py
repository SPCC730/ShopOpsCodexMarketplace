from __future__ import annotations

import subprocess
import sys
import threading
from datetime import UTC, datetime
from pathlib import Path
from time import monotonic
from typing import BinaryIO
from uuid import uuid4

from shopops_reporter.config import ProjectConfig
from shopops_reporter.daemon import ensure_daemon_running
from shopops_reporter.project import (
    environment_metadata,
    git_metadata,
    matching_files,
    new_report_token,
    project_fingerprint,
    read_result,
)
from shopops_reporter.spool import Spool


PIPE_DRAIN_GRACE_SECONDS = 1.0


def utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def run_project(
    *,
    project_dir: Path,
    config: ProjectConfig,
    command_override: list[str] | None = None,
    spool: Spool | None = None,
    start_daemon: bool = True,
    output_stream: BinaryIO | None = None,
) -> int:
    command = command_override or config.command
    if not command:
        raise RuntimeError("项目未配置启动命令")
    output_stream = output_stream or sys.stdout.buffer
    local_run_key = uuid4().hex
    working_dir = config.resolved_working_directory(project_dir)
    reported_failures: set[str] = set()
    warning_lock = threading.Lock()

    def warn_once(operation: str, error: Exception) -> None:
        with warning_lock:
            if operation in reported_failures:
                return
            reported_failures.add(operation)
        try:
            print(f"[ShopOps Reporter] {operation}失败，原脚本将继续运行: {error}", file=sys.stderr)
        except Exception:
            pass

    active_spool = spool
    if active_spool is None:
        try:
            active_spool = Spool()
        except Exception as error:
            warn_once("本地队列初始化", error)

    if active_spool is not None:
        try:
            active_spool.create_run(
                local_run_key=local_run_key,
                config=config,
                project_dir=project_dir,
                project_fingerprint=project_fingerprint(project_dir),
                git_metadata=git_metadata(project_dir),
                environment_metadata=environment_metadata(),
                started_at=utc_now(),
            )
        except Exception as error:
            warn_once("运行记录初始化", error)
            active_spool = None
    if start_daemon:
        try:
            ensure_daemon_running()
        except Exception as error:  # Reporter failure must not block the script.
            print(f"[ShopOps Reporter] 后台服务启动失败，将保留本地队列: {error}", file=sys.stderr)

    try:
        process = subprocess.Popen(
            command,
            cwd=working_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            bufsize=0,
        )
    except OSError as error:
        message = f"原脚本启动失败: {error}"
        print(message, file=sys.stderr)
        if active_spool is not None:
            try:
                active_spool.append_log(
                    local_run_key,
                    timestamp=utc_now(),
                    stream="stderr",
                    level="error",
                    message=message,
                )
            except Exception as spool_error:
                warn_once("日志写入", spool_error)
            try:
                active_spool.finish_run(
                    local_run_key,
                    status="failed",
                    exit_code=127,
                    ended_at=utc_now(),
                    result={"reporter_warning": message},
                )
            except Exception as spool_error:
                warn_once("运行记录结束写入", spool_error)
        return 127

    forwarding_active = threading.Event()
    forwarding_active.set()
    forwarding_lock = threading.Lock()

    def forward(source, target, stream: str) -> None:
        assert source is not None
        while chunk := source.readline():
            with forwarding_lock:
                if not forwarding_active.is_set():
                    continue
                try:
                    target.write(chunk)
                    target.flush()
                except Exception as error:
                    warn_once(f"{stream} 实时输出", error)
                text = chunk.decode("utf-8", errors="replace").rstrip("\r\n")
                if not text or active_spool is None:
                    continue
                for offset in range(0, len(text), 50_000):
                    try:
                        active_spool.append_log(
                            local_run_key,
                            timestamp=utc_now(),
                            stream=stream,
                            level="warning" if stream == "stderr" else "info",
                            message=text[offset : offset + 50_000],
                        )
                    except Exception as error:
                        warn_once("日志写入", error)

    threads = [
        threading.Thread(
            target=forward,
            args=(process.stdout, output_stream, "stdout"),
            daemon=True,
        ),
        threading.Thread(
            target=forward,
            args=(process.stderr, sys.stderr.buffer, "stderr"),
            daemon=True,
        ),
    ]
    for thread in threads:
        thread.start()
    interrupted = False
    try:
        exit_code = process.wait()
    except KeyboardInterrupt:
        interrupted = True
        process.terminate()
        process.wait()
        exit_code = 130
    drain_deadline = monotonic() + PIPE_DRAIN_GRACE_SECONDS
    for thread in threads:
        thread.join(timeout=max(0.0, drain_deadline - monotonic()))
    if any(thread.is_alive() for thread in threads):
        with forwarding_lock:
            forwarding_active.clear()
        warn_once("输出管道收尾", RuntimeError("后台进程仍占用输出管道"))

    if active_spool is not None:
        report_path = None
        try:
            html_files = matching_files(project_dir, config.html_reports)
            report_path = html_files[0] if html_files else None
        except Exception as error:
            warn_once("HTML 报告收集", error)
        try:
            result = read_result(config, project_dir)
        except Exception as error:
            warn_once("结构化结果读取", error)
            result = {}
        try:
            active_spool.finish_run(
                local_run_key,
                status="cancelled" if interrupted else "success" if exit_code == 0 else "failed",
                exit_code=exit_code,
                ended_at=utc_now(),
                result=result,
                live_report_token=new_report_token() if report_path else None,
                live_report_path=report_path,
            )
        except Exception as error:
            warn_once("运行记录结束写入", error)
    return exit_code
