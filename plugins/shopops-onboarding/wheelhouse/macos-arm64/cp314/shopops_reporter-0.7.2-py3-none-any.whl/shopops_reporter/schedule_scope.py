"""Keep scheduler inventory local unless it belongs to an enrolled SOP."""
from __future__ import annotations

from shopops_reporter.config import ProjectConfig
from shopops_reporter.schedule_map import registered_tasks


def enrolled_integration_ids() -> set[str]:
    # Read every registered declaration. Errors must not become an empty,
    # apparently complete scan that marks valid server plans missing.
    result = set()
    for context in registered_tasks():
        config = ProjectConfig.load(context.root, task_key=context.task_key)
        if config.integration_id:
            result.add(str(config.integration_id))
    return result


def scoped_tasks(tasks, integration_ids):
    allowed = []
    for task in tasks:
        projects = task.get('projects') or []
        # Do not alter a mapping projection without recomputing its digest.
        # An unresolved member keeps the entire mapping local until corrected.
        if projects and all(str(p.get('integration_id') or '') in integration_ids for p in projects):
            allowed.append(task)
    return allowed
