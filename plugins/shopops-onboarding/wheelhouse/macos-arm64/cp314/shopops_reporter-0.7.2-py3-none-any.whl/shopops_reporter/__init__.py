"""ShopOps Reporter client."""

__version__ = "0.7.2"
