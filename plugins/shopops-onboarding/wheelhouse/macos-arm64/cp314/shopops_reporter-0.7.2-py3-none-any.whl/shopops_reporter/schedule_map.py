"""Local, privacy-preserving mapping between Windows tasks and SOP projects.

The map is intentionally small and explicit.  Reporter never uploads command
lines, arguments, environment variables, or the complete Task Scheduler XML.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any, Iterable

from shopops_reporter.config import ensure_private_directory, reporter_home
from shopops_reporter.task_context import TaskContext, atomic_json, file_lock, read_json


MAP_PATH = Path(".shopops/schedule-map.json")
REGISTRY_PATH = Path("projects.json")
MAP_VERSION = 1


def _canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def mapping_hash(value: Any) -> str:
    return f"sha256:{hashlib.sha256(_canonical(value)).hexdigest()}"


def load_schedule_map(project_dir: Path, *, task_key: str | None = None) -> dict[str, Any]:
    path = TaskContext(project_dir, task_key).file('schedule-map.json')
    if not path.exists():
        return {"version": MAP_VERSION, "mappings": []}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise ValueError(f"{MAP_PATH} 不是有效 JSON: {error}") from error
    return validate_schedule_map(payload)


def validate_schedule_map(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict) or value.get("version") != MAP_VERSION:
        raise ValueError("schedule-map.json version 必须为 1")
    mappings = value.get("mappings", [])
    if not isinstance(mappings, list) or len(mappings) > 200:
        raise ValueError("schedule-map.json mappings 必须是最多 200 项的数组")
    normalized: list[dict[str, Any]] = []
    for item in mappings:
        if not isinstance(item, dict):
            raise ValueError("schedule-map.json mapping 必须是对象")
        allowed = {
            "schedule_key",
            "task_name",
            "project_fingerprint",
            "integration_id",
            "definition_hash",
            "mapping_hash",
            "expected_on_each_run",
            "accepted",
        }
        if set(item) - allowed:
            raise ValueError("schedule-map.json mapping 包含未知字段")
        schedule_key = item.get("schedule_key")
        fingerprint = item.get("project_fingerprint")
        if not isinstance(schedule_key, str) or not schedule_key.strip():
            raise ValueError("schedule-map.json schedule_key 不能为空")
        if not isinstance(fingerprint, str) or not fingerprint.strip():
            raise ValueError("schedule-map.json project_fingerprint 不能为空")
        normalized.append(
            {
                "schedule_key": schedule_key.strip(),
                "task_name": str(item.get("task_name") or "").strip()[:200],
                "project_fingerprint": fingerprint.strip(),
                "integration_id": item.get("integration_id"),
                "definition_hash": item.get("definition_hash"),
                "mapping_hash": item.get("mapping_hash"),
                "expected_on_each_run": bool(item.get("expected_on_each_run", False)),
                "accepted": bool(item.get("accepted", False)),
            }
        )
    return {"version": MAP_VERSION, "mappings": normalized}


def save_schedule_map(project_dir: Path, value: dict[str, Any], *, task_key: str | None = None) -> Path:
    with file_lock(TaskContext(project_dir, task_key).file('schedule-map.lock')):
        return _save_schedule_map(project_dir, value, task_key=task_key)


def _save_schedule_map(project_dir: Path, value: dict[str, Any], *, task_key: str | None = None) -> Path:
    normalized = validate_schedule_map(value)
    path = TaskContext(project_dir, task_key).file('schedule-map.json')
    ensure_private_directory(path.parent)
    if path.exists():
        backup = TaskContext(project_dir, task_key).file('schedule-map.json.bak')
        shutil.copy2(path, backup)
    fd, temporary = tempfile.mkstemp(prefix="schedule-map-", suffix=".json", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(normalized, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)
    return path


def register_project(project_dir: Path, *, task_key: str | None = None) -> None:
    """Remember initialized projects so the daemon can scan their mappings."""
    home = ensure_private_directory(reporter_home())
    if task_key is not None:
        context = TaskContext(project_dir, task_key)
        with file_lock(home / 'task-profiles.lock'):
            path = home / 'task-profiles.json'
            refs = [item.as_reference() for item in registered_profiles()]
            if context.as_reference() not in refs:
                refs.append(context.as_reference())
            atomic_json(path, {'version': 1, 'tasks': refs})
        return
    with file_lock(home / 'projects.lock'):
        path = home / REGISTRY_PATH
        projects = _registered_paths()
        resolved = str(project_dir.resolve())
        if resolved not in projects:
            projects.append(resolved)
        atomic_json(path, projects)


def registered_profiles() -> list[TaskContext]:
    path = reporter_home() / 'task-profiles.json'
    if not path.exists():
        return []
    payload = read_json(path)
    if (not isinstance(payload, dict) or payload.get('version') != 1
            or not isinstance(payload.get('tasks'), list)):
        raise ValueError('task_registry_invalid_preserve_for_recovery')
    result = []
    for item in payload['tasks']:
        if not isinstance(item, dict) or set(item) != {'root', 'task_key'} or not item['task_key']:
            raise ValueError('task_registry_invalid_preserve_for_recovery')
        result.append(TaskContext(Path(item['root']), item['task_key']))
    return result


def registered_tasks() -> list[TaskContext]:
    return [TaskContext(path) for path in registered_projects()] + registered_profiles()


def registered_projects() -> list[Path]:
    return [Path(item) for item in _registered_paths() if Path(item).is_dir()]


def _registered_paths() -> list[str]:
    path = reporter_home() / REGISTRY_PATH
    if not path.exists():
        return []
    payload = read_json(path)
    if not isinstance(payload, list) or any(not isinstance(item, str) for item in payload):
        raise ValueError('task_registry_invalid_preserve_for_recovery')
    return payload


def mappings_for_schedule(project_dirs: Iterable[Path | TaskContext], schedule_key: str, *, strict: bool = False) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for item in project_dirs:
        context = item if isinstance(item, TaskContext) else TaskContext(item)
        project_dir = context.root
        try:
            payload = load_schedule_map(project_dir, task_key=context.task_key)
        except ValueError:
            if strict:
                raise
            continue
        for mapping in payload["mappings"]:
            if mapping["schedule_key"] == schedule_key:
                result.append({**mapping, "project_dir": str(project_dir.resolve()), 'task_key': context.task_key})
    return result


def accept_mapping(
    project_dir: Path,
    *,
    schedule_key: str,
    project_fingerprint: str,
    integration_id: str | None = None,
    task_name: str | None = None,
    definition_hash: str | None = None,
    mapping_hash_value: str | None = None,
    expected_on_each_run: bool = False,
    task_key: str | None = None,
) -> Path:
    """Persist an explicitly accepted developer mapping atomically."""
    with file_lock(TaskContext(project_dir, task_key).file('schedule-map.lock')):
        return _accept_mapping(project_dir, schedule_key=schedule_key,
            project_fingerprint=project_fingerprint, integration_id=integration_id,
            task_name=task_name, definition_hash=definition_hash,
            mapping_hash_value=mapping_hash_value, expected_on_each_run=expected_on_each_run,
            task_key=task_key)


def _accept_mapping(project_dir, *, schedule_key, project_fingerprint, integration_id,
                    task_name, definition_hash, mapping_hash_value, expected_on_each_run, task_key):
    payload = load_schedule_map(project_dir, task_key=task_key)
    mappings = [
        item
        for item in payload["mappings"]
        if not (
            item["schedule_key"] == schedule_key
            and item["project_fingerprint"] == project_fingerprint
        )
    ]
    mappings.append(
        {
            "schedule_key": schedule_key,
            "task_name": task_name or "",
            "project_fingerprint": project_fingerprint,
            "integration_id": integration_id,
            "definition_hash": definition_hash,
            "mapping_hash": mapping_hash_value,
            "expected_on_each_run": expected_on_each_run,
            "accepted": True,
        }
    )
    return _save_schedule_map(project_dir, {"version": MAP_VERSION, "mappings": mappings}, task_key=task_key)


def _atomic_json_write(path: Path, value: Any) -> None:
    fd, temporary = tempfile.mkstemp(prefix=f"{path.stem}-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)
