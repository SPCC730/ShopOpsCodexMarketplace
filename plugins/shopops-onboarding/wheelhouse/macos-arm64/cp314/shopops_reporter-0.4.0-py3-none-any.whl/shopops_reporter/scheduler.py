"""Windows Task Scheduler discovery for the external-run integration."""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Callable

from shopops_reporter.config import ProjectConfig
from shopops_reporter.project import project_fingerprint
from shopops_reporter.schedule_map import mappings_for_schedule, registered_projects


POWERSHELL_TIMEOUT_SECONDS = 20
POWERSHELL_SCRIPT = r"""
$ErrorActionPreference = 'Stop'
$items = @(Get-ScheduledTask | ForEach-Object {
  $task = $_
  $info = Get-ScheduledTaskInfo -TaskName $task.TaskName -TaskPath $task.TaskPath
  $triggers = @($task.Triggers | ForEach-Object {
    [pscustomobject]@{
      kind = $_.CimClass.CimClassName
      enabled = [bool]$_.Enabled
      start_boundary = if ($_.StartBoundary) { ([datetime]$_.StartBoundary).ToUniversalTime().ToString('o') } else { $null }
    }
  })
  [pscustomobject]@{
    task_name = $task.TaskName
    task_path = $task.TaskPath
    enabled = [bool]$task.Settings.Enabled
    scheduler_state = [string]$task.State
    last_task_result = [int]$info.LastTaskResult
    last_run_at = if ($info.LastRunTime -and $info.LastRunTime.Year -gt 1) { $info.LastRunTime.ToUniversalTime().ToString('o') } else { $null }
    next_run_at = if ($info.NextRunTime -and $info.NextRunTime.Year -gt 1) { $info.NextRunTime.ToUniversalTime().ToString('o') } else { $null }
    triggers = $triggers
  }
})
$items | ConvertTo-Json -Depth 8 -Compress
"""


@dataclass(frozen=True)
class SchedulerScanResult:
    tasks: list[dict[str, Any]]
    complete: bool
    error: str | None = None
    error_code: str | None = None


def schedule_key(task_name: str, task_path: str | None) -> str:
    value = f"{task_path or '/'}\0{task_name}".encode("utf-8")
    return f"sha256:{hashlib.sha256(value).hexdigest()}"


def redact_task_path(task_path: str | None) -> str | None:
    if not task_path:
        return None
    # Task Scheduler paths are not filesystem paths. Keep only the hierarchy;
    # never include action command lines or user profile directories.
    normalized = task_path.replace("\\", "/")
    if not normalized.startswith("/"):
        normalized = f"/{normalized}"
    return "/".join(part for part in normalized.split("/") if part)


class WindowsTaskScheduler:
    def __init__(
        self,
        *,
        runner: Callable[..., subprocess.CompletedProcess[str]] | None = None,
    ):
        self.runner = runner or subprocess.run

    def scan(self) -> SchedulerScanResult:
        if os.name != "nt":
            return SchedulerScanResult([], False, "当前系统不是 Windows，无法读取任务计划", "not_windows")
        powershell = _find_powershell()
        if powershell is None:
            return SchedulerScanResult([], False, "未找到 PowerShell，无法读取 Windows 任务计划", "powershell_unavailable")
        try:
            completed = self.runner(
                [powershell, "-NoProfile", "-NonInteractive", "-Command", POWERSHELL_SCRIPT],
                capture_output=True,
                text=True,
                timeout=POWERSHELL_TIMEOUT_SECONDS,
                check=False,
            )
        except (OSError, subprocess.SubprocessError) as error:
            return SchedulerScanResult([], False, f"读取 Windows 任务计划失败: {error}")
        if completed.returncode != 0:
            detail = (completed.stderr or completed.stdout or "权限不足").strip()
            return SchedulerScanResult([], False, f"读取 Windows 任务计划失败: {detail[:500]}")
        try:
            raw = json.loads(completed.stdout or "[]")
        except ValueError as error:
            return SchedulerScanResult([], False, f"Windows 任务计划返回格式异常: {error}")
        entries = raw if isinstance(raw, list) else [raw]
        try:
            tasks = [self._normalize_task(item) for item in entries if isinstance(item, dict)]
        except ValueError as error:
            return SchedulerScanResult([], False, f"Windows 任务计划字段异常: {error}")
        return SchedulerScanResult(tasks, True)

    def _normalize_task(self, item: dict[str, Any]) -> dict[str, Any]:
        name = item.get("task_name")
        if not isinstance(name, str) or not name.strip():
            raise ValueError("缺少任务名称")
        path = item.get("task_path")
        path = path if isinstance(path, str) else "/"
        key = schedule_key(name.strip(), path)
        triggers = item.get("triggers")
        if not isinstance(triggers, list):
            triggers = []
        normalized_triggers = [trigger for trigger in triggers if isinstance(trigger, dict)][:50]
        project_dirs = registered_projects()
        mappings = mappings_for_schedule(project_dirs, key)
        if not mappings:
            mappings = _name_matched_projects(project_dirs, name.strip())
        projects = []
        for mapping in mappings[:200]:
            project_dir = Path(mapping["project_dir"])
            try:
                config = ProjectConfig.load(project_dir)
                fingerprint = project_fingerprint(project_dir)
            except (OSError, RuntimeError, ValueError):
                continue
            if fingerprint != mapping["project_fingerprint"]:
                # A changed project must be reviewed again; do not silently
                # associate the new code with an old schedule mapping.
                continue
            projects.append(
                {
                    "project_key": config.project_key,
                    "integration_id": config.integration_id,
                    "project_fingerprint": fingerprint,
                    "source": "declared" if mapping.get("accepted") else "observed",
                    "expected_on_each_run": bool(mapping.get("expected_on_each_run", False)),
                    # Filled after the stable mapping projection is hashed.
                    "mapping_hash": None,
                }
            )
        if projects:
            current_mapping_hash = _mapping_hash(projects)
            for project in projects:
                project["mapping_hash"] = current_mapping_hash
        definition = {
            "task_name": name.strip(),
            "task_path": redact_task_path(path),
            "enabled": bool(item.get("enabled", True)),
            "scheduler_state": str(item.get("scheduler_state") or "unknown"),
            "triggers": normalized_triggers,
        }
        definition_hash = f"sha256:{hashlib.sha256(_json(definition)).hexdigest()}"
        return {
            "schedule_key": key,
            "task_name": name.strip(),
            "redacted_task_path": redact_task_path(path),
            "trigger_summary": _trigger_summary(normalized_triggers),
            "triggers": normalized_triggers,
            "timezone": "Asia/Shanghai",
            "enabled": bool(item.get("enabled", True)),
            "scheduler_state": str(item.get("scheduler_state") or "unknown").lower(),
            "last_task_result": _int_or_none(item.get("last_task_result")),
            "last_run_at": _timestamp(item.get("last_run_at")),
            "next_run_at": _timestamp(item.get("next_run_at")),
            "definition_hash": definition_hash,
            "mapping_hash": _mapping_hash(projects),
            "projects": projects,
        }


def _find_powershell() -> str | None:
    for name in ("pwsh", "powershell.exe", "powershell"):
        path = _which(name)
        if path:
            return path
    return None


def _which(name: str) -> str | None:
    from shutil import which

    return which(name)


def _json(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def _mapping_hash(projects: list[dict[str, Any]]) -> str | None:
    if not projects:
        return None
    stable = [
        {
            key: project.get(key)
            for key in (
                "project_key",
                "integration_id",
                "project_fingerprint",
            )
        }
        for project in projects
    ]
    return f"sha256:{hashlib.sha256(_json(stable)).hexdigest()}"


def _trigger_summary(triggers: list[dict[str, Any]]) -> str | None:
    if not triggers:
        return None
    kinds = [str(item.get("kind")) for item in triggers if item.get("kind")]
    return "、".join(kinds[:5]) if kinds else f"{len(triggers)} 个触发器"


def _name_matched_projects(project_dirs: list[Path], task_name: str) -> list[dict[str, Any]]:
    """Discover an obvious project/task name match without scanning commands."""
    task_token = _compact_name(task_name.removesuffix("-WindowsTask"))
    result: list[dict[str, Any]] = []
    for project_dir in project_dirs:
        try:
            config = ProjectConfig.load(project_dir)
        except (OSError, RuntimeError, ValueError):
            continue
        candidates = {_compact_name(config.display_name), _compact_name(project_dir.name)}
        if not task_token or task_token not in candidates:
            continue
        try:
            fingerprint = project_fingerprint(project_dir)
        except OSError:
            continue
        result.append(
            {
                "project_dir": str(project_dir.resolve()),
                "project_fingerprint": fingerprint,
                "integration_id": config.integration_id,
                "task_name": config.display_name,
                "accepted": False,
                "mapping_hash": None,
            }
        )
    return result


def _compact_name(value: str) -> str:
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "", value.casefold())


def _int_or_none(value: Any) -> int | None:
    if value is None or value == "":
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _timestamp(value: Any) -> str | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC).isoformat().replace("+00:00", "Z")
