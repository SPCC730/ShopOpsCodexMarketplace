from __future__ import annotations

import codecs
import locale
import os
import subprocess
import sys
import threading
from datetime import UTC, datetime
from pathlib import Path
from time import monotonic
from typing import BinaryIO
from uuid import uuid4

from shopops_reporter.config import ProjectConfig
from shopops_reporter.daemon import ensure_daemon_running
from shopops_reporter.project import (
    environment_metadata,
    git_metadata,
    matching_files,
    new_report_token,
    project_fingerprint,
    read_result,
    safe_project_path,
)
from shopops_reporter.spool import Spool
from shopops_reporter.result_mapping import (
    ResultContractError,
    evaluate_result_contract,
    load_result_contract,
)


PIPE_DRAIN_GRACE_SECONDS = 1.0


def _output_encoding_candidates() -> tuple[str, ...]:
    configured = os.environ.get("SHOPOPS_OUTPUT_ENCODING", "").strip()
    preferred = locale.getpreferredencoding(False)
    candidates = [configured, "utf-8-sig"]
    if os.name == "nt":
        if preferred.lower().replace("_", "-") in {
            "cp936",
            "gb18030",
            "gb2312",
            "gbk",
        }:
            candidates.append(preferred)
        candidates.extend(("gb18030", preferred, "mbcs"))
    else:
        candidates.append(preferred)
    return tuple(dict.fromkeys(value for value in candidates if value))


def decode_process_output(
    chunk: bytes,
    *,
    fallback_encodings: tuple[str, ...] | None = None,
) -> str:
    """Decode captured script output without silently replacing source bytes."""
    if chunk.startswith((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE)):
        return chunk.decode("utf-16")
    if chunk.startswith(codecs.BOM_UTF8):
        return chunk.decode("utf-8-sig")

    encodings = fallback_encodings or _output_encoding_candidates()
    for encoding in encodings:
        try:
            codecs.lookup(encoding)
            return chunk.decode(encoding)
        except (LookupError, UnicodeDecodeError):
            continue
    return chunk.decode("utf-8", errors="backslashreplace")


def utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def scheduled_context() -> dict[str, str | None]:
    """Read only the wrapper-owned scheduling context from the environment."""
    values = {
        "windows_task_key": os.environ.get("SHOPOPS_WINDOWS_TASK_KEY"),
        "windows_task_path": os.environ.get("SHOPOPS_WINDOWS_TASK_PATH"),
        "trigger_instance_id": os.environ.get("SHOPOPS_TRIGGER_INSTANCE_ID"),
        "trigger_kind": os.environ.get("SHOPOPS_TRIGGER_KIND"),
    }
    if values["trigger_kind"] not in {"scheduled", "manual", "unknown", None}:
        values["trigger_kind"] = "unknown"
    return values


def run_project(
    *,
    project_dir: Path,
    config: ProjectConfig,
    command_override: list[str] | None = None,
    spool: Spool | None = None,
    start_daemon: bool = True,
    output_stream: BinaryIO | None = None,
) -> int:
    command = command_override or config.command
    if not command:
        raise RuntimeError("项目未配置启动命令")
    output_stream = output_stream or sys.stdout.buffer
    local_run_key = uuid4().hex
    working_dir = config.resolved_working_directory(project_dir)
    reported_failures: set[str] = set()
    warning_lock = threading.Lock()

    def warn_once(operation: str, error: Exception) -> None:
        with warning_lock:
            if operation in reported_failures:
                return
            reported_failures.add(operation)
        try:
            print(f"[ShopOps Reporter] {operation}失败，原脚本将继续运行: {error}", file=sys.stderr)
        except Exception:
            pass

    active_spool = spool
    current_project_fingerprint = project_fingerprint(project_dir)
    result_contract_snapshot = None
    result_warnings: list[str] = []
    if config.result_contract is not None:
        try:
            candidate = load_result_contract(project_dir)
            if candidate.digest != config.result_contract.get("digest"):
                raise ResultContractError("result_contract_digest_changed")
            if candidate.project_fingerprint != current_project_fingerprint:
                raise ResultContractError("result_contract_project_mismatch")
            if not isinstance(config.result_contract.get("version"), int):
                raise ResultContractError("result_contract_version_missing")
            result_contract_snapshot = candidate
        except (OSError, ResultContractError, ValueError) as error:
            result_warnings.append(str(error))
    if active_spool is None:
        try:
            active_spool = Spool()
        except Exception as error:
            warn_once("本地队列初始化", error)

    if active_spool is not None:
        try:
            active_spool.create_run(
                local_run_key=local_run_key,
                config=config,
                project_dir=project_dir,
                project_fingerprint=current_project_fingerprint,
                git_metadata=git_metadata(project_dir),
                environment_metadata=environment_metadata(),
                started_at=utc_now(),
                **scheduled_context(),
            )
        except Exception as error:
            warn_once("运行记录初始化", error)
            active_spool = None
    if start_daemon:
        try:
            from shopops_reporter.project_sync import request_project_sync

            request_project_sync()
            ensure_daemon_running()
        except Exception as error:  # Reporter failure must not block the script.
            print(f"[ShopOps Reporter] 后台服务启动失败，将保留本地队列: {error}", file=sys.stderr)

    try:
        process = subprocess.Popen(
            command,
            cwd=working_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            bufsize=0,
        )
    except OSError as error:
        message = f"原脚本启动失败: {error}"
        print(message, file=sys.stderr)
        if active_spool is not None:
            try:
                active_spool.append_log(
                    local_run_key,
                    timestamp=utc_now(),
                    stream="stderr",
                    level="error",
                    message=message,
                )
            except Exception as spool_error:
                warn_once("日志写入", spool_error)
            try:
                active_spool.finish_run(
                    local_run_key,
                    status="failed",
                    exit_code=127,
                    ended_at=utc_now(),
                    result={"reporter_warning": message},
                )
            except Exception as spool_error:
                warn_once("运行记录结束写入", spool_error)
        return 127

    forwarding_active = threading.Event()
    forwarding_active.set()
    forwarding_lock = threading.Lock()

    def forward(source, target, stream: str) -> None:
        assert source is not None
        while chunk := source.readline():
            with forwarding_lock:
                if not forwarding_active.is_set():
                    continue
                try:
                    target.write(chunk)
                    target.flush()
                except Exception as error:
                    warn_once(f"{stream} 实时输出", error)
                text = decode_process_output(chunk).rstrip("\r\n")
                if not text or active_spool is None:
                    continue
                for offset in range(0, len(text), 50_000):
                    try:
                        active_spool.append_log(
                            local_run_key,
                            timestamp=utc_now(),
                            stream=stream,
                            level="warning" if stream == "stderr" else "info",
                            message=text[offset : offset + 50_000],
                        )
                    except Exception as error:
                        warn_once("日志写入", error)

    threads = [
        threading.Thread(
            target=forward,
            args=(process.stdout, output_stream, "stdout"),
            daemon=True,
        ),
        threading.Thread(
            target=forward,
            args=(process.stderr, sys.stderr.buffer, "stderr"),
            daemon=True,
        ),
    ]
    for thread in threads:
        thread.start()
    interrupted = False
    try:
        exit_code = process.wait()
    except KeyboardInterrupt:
        interrupted = True
        process.terminate()
        process.wait()
        exit_code = 130
    drain_deadline = monotonic() + PIPE_DRAIN_GRACE_SECONDS
    for thread in threads:
        thread.join(timeout=max(0.0, drain_deadline - monotonic()))
    if any(thread.is_alive() for thread in threads):
        with forwarding_lock:
            forwarding_active.clear()
        warn_once("输出管道收尾", RuntimeError("后台进程仍占用输出管道"))

    if active_spool is not None:
        report_path = None
        try:
            html_patterns = list(config.html_reports)
            dashboard_path: str | None = None
            if config.dashboard and config.dashboard.get("kind") == "html":
                configured_path = config.dashboard.get("path")
                dashboard_path = configured_path if isinstance(configured_path, str) else None
            if dashboard_path:
                # Resolve the declared dashboard directly. `matching_files()`
                # sorts its result, so pattern ordering cannot express this
                # preference when another HTML report has an earlier name.
                declared_path = project_dir / dashboard_path
                try:
                    resolved_dashboard = safe_project_path(project_dir, dashboard_path)
                    if not declared_path.is_symlink() and resolved_dashboard.is_file():
                        report_path = resolved_dashboard
                except (OSError, RuntimeError):
                    report_path = None
            if report_path is None:
                html_files = matching_files(project_dir, html_patterns)
                report_path = html_files[0] if html_files else None
        except Exception as error:
            warn_once("HTML 报告收集", error)
        if result_contract_snapshot is not None:
            try:
                outcome = evaluate_result_contract(result_contract_snapshot, project_dir)
                result = outcome.result
                result["contract"]["version"] = config.result_contract["version"]
                result_warnings.extend(outcome.warnings)
            except Exception as error:
                warn_once("结果契约映射", error)
                result_warnings.append(f"result_mapping_failed:{type(error).__name__}")
                result = {}
        elif config.result_contract is not None:
            result = {}
        else:
            try:
                result = read_result(config, project_dir)
            except Exception as error:
                warn_once("结构化结果读取", error)
                result = {}
        try:
            active_spool.finish_run(
                local_run_key,
                status="cancelled" if interrupted else "success" if exit_code == 0 else "failed",
                exit_code=exit_code,
                ended_at=utc_now(),
                result=result,
                result_warnings=result_warnings,
                live_report_token=new_report_token() if report_path else None,
                live_report_path=report_path,
            )
        except Exception as error:
            warn_once("运行记录结束写入", error)
    return exit_code
