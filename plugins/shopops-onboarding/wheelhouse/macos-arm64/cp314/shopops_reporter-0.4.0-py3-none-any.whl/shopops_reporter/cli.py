from __future__ import annotations

import argparse
import contextlib
import getpass
import json
import os
import shlex
import sys
import time
from pathlib import Path
from typing import Any
from uuid import uuid4

from shopops_reporter.client import ReporterApiError, ReporterClient, generate_private_key
from shopops_reporter.config import (
    IdentityStore,
    NotPairedError,
    ProjectConfig,
    default_device_name,
    find_project_dir,
    normalize_server_url,
    reporter_home,
)
from shopops_reporter.daemon import (
    Uploader,
    current_daemon_pid,
    ensure_daemon_running,
    serve,
    stop_daemon,
)
from shopops_reporter.diagnostics import validate_ai_readable_paths
from shopops_reporter.project import initialize_project
from shopops_reporter.project import project_fingerprint
from shopops_reporter.result_mapping import evaluate_result_contract, load_result_contract
from shopops_reporter.schedule_map import accept_mapping, registered_projects
from shopops_reporter.protocol import emit_error, emit_success
from shopops_reporter.runner import run_project
from shopops_reporter.spool import Spool
from shopops_reporter.project_sync import ProjectSynchronizer, read_sync_status


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(
        prog="shopops-report",
        description="在开发者电脑运行原脚本，并向 ShopOps 上报运行记录。",
    )
    root.add_argument("--json", action="store_true", dest="json_output")
    commands = root.add_subparsers(dest="action", required=True)

    enroll = commands.add_parser("enroll", help="使用一次性配对码登记这台电脑")
    enroll.add_argument("--server", required=True, help="ShopOps 后端地址")
    enroll.add_argument("--pairing-code", help="管理台生成的一次性配对码")
    enroll.add_argument("--name", default=default_device_name(), help="设备显示名称")
    enroll.add_argument("--operator", help="开发者声明名称")
    enroll.add_argument("--force", action="store_true", help="覆盖本机已有设备身份")

    init = commands.add_parser("init", help="接入当前脚本项目")
    init.add_argument("--name", required=True, help="SOP/项目名称")
    init.add_argument("--platform", default="通用", help="业务平台")
    init.add_argument("--command", required=True, help="原脚本启动命令")
    init.add_argument("--artifact", action="append", default=[], help="附件相对 glob，可重复")
    init.add_argument("--html-report", action="append", default=[], help="HTML 相对 glob，可重复")
    init.add_argument("--result-json", help="结构化结果 JSON 相对路径")
    init.add_argument("--diagnostics-file", help="诊断信封 JSON 相对路径")
    init.add_argument(
        "--ai-readable",
        action="append",
        default=[],
        help="允许 AI 读取的文本产物相对路径，可重复",
    )
    init.add_argument("--project-dir", type=Path, default=Path.cwd())

    sync = commands.add_parser("sync", help="同步当前项目的接入配置和看板声明")
    sync.add_argument(
        "--project-dir",
        type=Path,
        default=Path.cwd(),
        help="项目目录或其子目录，默认使用当前目录",
    )

    accept_schedule = commands.add_parser("accept-schedule", help="接受一条 Windows 任务计划映射")
    accept_schedule.add_argument("--schedule-key", required=True)
    accept_schedule.add_argument("--mapping-hash", required=True)
    accept_schedule.add_argument("--project-fingerprint", required=True)
    accept_schedule.add_argument("--project-dir", type=Path, default=Path.cwd())
    accept_schedule.add_argument("--expected-on-each-run", action="store_true")

    run = commands.add_parser("run", help="运行当前项目并上报")
    run.add_argument("command", nargs=argparse.REMAINDER, help="可选命令覆盖，写在 -- 后")

    result_contract = commands.add_parser(
        "result-contract",
        help="验证、预览或提交当前项目的运行结果契约",
    )
    result_contract.add_argument(
        "contract_action",
        choices=("validate", "preview", "submit"),
    )
    result_contract.add_argument("--project-dir", type=Path, default=Path.cwd())

    commands.add_parser("start", help="启动 Reporter 后台服务")
    commands.add_parser("stop", help="停止 Reporter 后台服务")
    commands.add_parser("status", help="查看设备、后台服务和离线队列状态")
    serve_parser = commands.add_parser("serve", help=argparse.SUPPRESS)
    serve_parser.add_argument("--once", action="store_true")
    flush = commands.add_parser("flush", help="立即补传本地队列")
    flush.add_argument("--timeout", type=float, default=30)
    return root


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        return dispatch(args)
    except ReporterApiError as error:
        if args.json_output:
            emit_error(args.action, "api_error", str(error.detail))
            return 2
        print(f"Reporter API 请求失败：{error.detail}（HTTP {error.status_code}）", file=sys.stderr)
        return 2
    except NotPairedError as error:
        if args.json_output:
            emit_error(args.action, "not_paired", str(error))
            return 2
        print(f"ShopOps Reporter：{error}", file=sys.stderr)
        return 2
    except (OSError, RuntimeError, ValueError) as error:
        if args.json_output:
            code = "validation_error" if isinstance(error, ValueError) else "runtime_error"
            emit_error(args.action, code, str(error))
            return 2
        print(f"ShopOps Reporter：{error}", file=sys.stderr)
        return 2


def dispatch(args: argparse.Namespace) -> int:
    if args.action == "enroll":
        data = enroll(args)
        if args.json_output:
            emit_success("enroll", data)
        else:
            print(f"设备配对成功：{data['device']}")
            print(f"设备 ID：{data['device_id']}")
            print(f"私钥存储：{data['private_key_storage']}")
        return 0
    if args.action == "init":
        if args.json_output:
            with contextlib.redirect_stdout(sys.stderr):
                exit_code = init_project(args)
            emit_success("init", {"exit_code": exit_code})
            return exit_code
        return init_project(args)
    if args.action == "sync":
        if args.json_output:
            with contextlib.redirect_stdout(sys.stderr):
                exit_code = sync_project(args)
            sync_status = read_sync_status(find_project_dir(args.project_dir))
            if exit_code:
                emit_error("sync", str(sync_status.get("sync_state", "sync_failed")),
                           str(sync_status.get("error_code", "Project sync requires attention")))
            else:
                emit_success("sync", {"exit_code": exit_code, "sync": sync_status})
            return exit_code
        return sync_project(args)
    if args.action == "accept-schedule":
        data = accept_schedule_mapping(args)
        if args.json_output:
            emit_success("accept-schedule", data)
        else:
            print(f"已接受任务计划映射：{data['schedule_key']}")
            print(f"映射文件：{data['mapping_path']}")
        return 0
    if args.action == "run":
        project_dir = find_project_dir()
        config = ProjectConfig.load(project_dir)
        override = list(args.command)
        if override and override[0] == "--":
            override.pop(0)
        if args.json_output:
            exit_code = run_project(
                project_dir=project_dir,
                config=config,
                command_override=override or None,
                output_stream=sys.stderr.buffer,
            )
            emit_success("run", {"exit_code": exit_code})
            return exit_code
        return run_project(project_dir=project_dir, config=config, command_override=override or None)
    if args.action == "result-contract":
        data = manage_result_contract(args)
        if args.json_output:
            emit_success("result-contract", data)
        else:
            print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0
    if args.action == "start":
        data = start()
        if args.json_output:
            emit_success("start", data)
        else:
            print(f"Reporter 已启动，PID {data['daemon']['pid']}")
        return 0
    if args.action == "stop":
        data = stop()
        if args.json_output:
            emit_success("stop", data)
        else:
            print("Reporter 已停止" if data["stopped"] else "Reporter 当前未运行")
        return 0
    if args.action == "status":
        data = status()
        if args.json_output:
            emit_success("status", data)
        else:
            print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0
    if args.action == "serve":
        serve(once=args.once)
        if args.json_output:
            emit_success("serve", {"exit_code": 0})
        return 0
    if args.action == "flush":
        data = flush(args.timeout)
        if args.json_output:
            emit_success("flush", data)
        else:
            print(json.dumps(data, ensure_ascii=False))
        return 0 if data["pending_runs"] == 0 else 1
    raise RuntimeError(f"未知命令: {args.action}")


def enroll(args: argparse.Namespace) -> dict[str, Any]:
    store = IdentityStore()
    if store.exists() and not args.force:
        raise RuntimeError("这台电脑已经配对；如需替换身份请使用 --force")
    pairing_code = args.pairing_code or getpass.getpass("一次性配对码：").strip()
    if not pairing_code:
        raise ValueError("配对码不能为空")
    server_url = normalize_server_url(args.server)
    installation_id = str(uuid4())
    private_key, public_key = generate_private_key()
    response = ReporterClient.enroll(
        server_url=server_url,
        pairing_code=pairing_code,
        installation_id=installation_id,
        display_name=args.name,
        declared_operator=args.operator,
        public_key=public_key,
    )
    identity = store.save(
        server_url=server_url,
        device_id=str(response["id"]),
        installation_id=installation_id,
        display_name=args.name,
        declared_operator=args.operator,
        private_key=private_key,
    )
    return {
        "device": identity.display_name,
        "device_id": identity.device_id,
        "private_key_storage": identity.private_key_storage,
    }


def init_project(args: argparse.Namespace) -> int:
    identity = IdentityStore().load()
    command = split_command(args.command)
    if not command:
        raise ValueError("启动命令不能为空")
    ai_readable_artifacts = validate_ai_readable_paths(
        args.ai_readable,
        args.artifact,
    )
    diagnostics = (
        {"schema_version": 1, "file": args.diagnostics_file}
        if args.diagnostics_file
        else None
    )
    config, created = initialize_project(
        client=ReporterClient(identity),
        project_dir=args.project_dir,
        display_name=args.name,
        platform_name=args.platform,
        command=command,
        artifacts=args.artifact,
        html_reports=args.html_report,
        result_json=args.result_json,
        diagnostics=diagnostics,
        ai_readable_artifacts=ai_readable_artifacts,
    )
    print("已创建待确认 SOP" if created else "已更新现有外部 SOP 接入")
    print(f"Integration ID：{config.integration_id}")
    print(f"配置文件：{args.project_dir.resolve() / '.shopops/integration.yaml'}")
    return 0


def sync_project(args: argparse.Namespace) -> int:
    """Refresh an existing integration without re-uploading the project."""
    project_dir = find_project_dir(args.project_dir)
    existing = ProjectConfig.load(project_dir)
    identity = IdentityStore().load()
    config, created = initialize_project(
        client=ReporterClient(identity),
        project_dir=project_dir,
        display_name=existing.display_name,
        platform_name=existing.platform,
        command=existing.command,
        artifacts=existing.artifacts,
        html_reports=existing.html_reports,
        result_json=existing.result_json,
        diagnostics=existing.diagnostics,
        ai_readable_artifacts=existing.ai_readable_artifacts,
    )
    if created:
        # This should only happen when the server-side integration was removed;
        # keep the message explicit so the operator knows a new review is needed.
        print("已重新创建待确认 SOP 接入")
    else:
        print("已同步现有外部 SOP 接入")
    if config.dashboard:
        print(
            f"看板：{config.dashboard['title']} "
            f"（{config.dashboard['kind']}）"
        )
    else:
        print("看板：未声明（如需看板，请先添加 .shopops/dashboard.json）")
    print(f"Integration ID：{config.integration_id}")
    print(f"配置文件：{project_dir / '.shopops/integration.yaml'}")
    synced = ProjectSynchronizer(ReporterClient(identity)).sync_one(project_dir)
    status = read_sync_status(project_dir)
    if synced:
        print("项目资料已同步")
        return 0
    if status.get("sync_state") == "unsupported_server":
        print("当前服务端不支持项目资料同步；原接入配置已更新")
        return 0
    if status.get("sync_state") == "pending_migration":
        print("设备迁移待管理员确认；当前设备尚未获得该项目上传权限")
    else:
        print(f"项目资料同步失败：{status.get('error_code', 'sync_failed')}")
    return 1


def manage_result_contract(args: argparse.Namespace) -> dict[str, Any]:
    project_dir = find_project_dir(args.project_dir)
    config = ProjectConfig.load(project_dir)
    snapshot = load_result_contract(project_dir)
    fingerprint = project_fingerprint(project_dir)
    if snapshot.project_fingerprint != fingerprint:
        raise ValueError(
            "结果契约绑定的项目指纹与当前代码不一致，请重新生成并审核契约"
        )
    _validate_contract_sample_files(snapshot.payload, project_dir)
    if args.contract_action == "validate":
        return {
            "valid": True,
            "digest": snapshot.digest,
            "project_fingerprint": fingerprint,
            "sample_count": len(snapshot.payload["samples"]),
        }
    if args.contract_action == "preview":
        outcome = evaluate_result_contract(snapshot, project_dir)
        if config.result_contract and isinstance(config.result_contract.get("version"), int):
            outcome.result["contract"]["version"] = config.result_contract["version"]
        return {"result": outcome.result, "warnings": list(outcome.warnings)}

    response = ReporterClient(IdentityStore().load()).signed_json(
        "POST",
        f"/reporter/v1/integrations/{config.integration_id}/result-contracts",
        {"contract": snapshot.payload, "digest": snapshot.digest},
    )
    config.result_contract = {
        "id": str(response["id"]),
        "version": int(response["version"]),
        "digest": str(response["digest"]),
        "status": str(response["status"]),
        "project_fingerprint": fingerprint,
    }
    config.save(project_dir)
    return {
        "submitted": True,
        "created": bool(response.get("created")),
        **config.result_contract,
    }


def _validate_contract_sample_files(payload: dict[str, Any], project_dir: Path) -> None:
    missing = [
        sample["fixture"]
        for sample in payload["samples"]
        if not (project_dir / sample["fixture"]).is_file()
    ]
    if missing:
        raise ValueError(f"结果契约样例文件不存在: {', '.join(missing)}")


def accept_schedule_mapping(args: argparse.Namespace) -> dict[str, str]:
    project_dir = find_project_dir(args.project_dir)
    config = ProjectConfig.load(project_dir)
    identity = IdentityStore().load()
    ReporterClient(identity).accept_schedule(
        {
            "schedule_key": args.schedule_key,
            "mapping_hash": args.mapping_hash,
            "projects": [
                {
                    "project_fingerprint": args.project_fingerprint,
                    "expected_on_each_run": bool(args.expected_on_each_run),
                }
            ],
        }
    )
    path = accept_mapping(
        project_dir,
        schedule_key=args.schedule_key,
        project_fingerprint=args.project_fingerprint,
        integration_id=config.integration_id,
        task_name=config.display_name,
        mapping_hash_value=args.mapping_hash,
        expected_on_each_run=bool(args.expected_on_each_run),
    )
    return {"schedule_key": args.schedule_key, "mapping_path": str(path)}


def _is_windows() -> bool:
    return os.name == "nt"


def split_command(value: str) -> list[str]:
    """Split a configured command with the native host quoting rules."""
    if not value.strip():
        return []
    if _is_windows():
        return _split_windows_command(value)
    return shlex.split(value)


def _split_windows_command(value: str) -> list[str]:
    """Use CommandLineToArgvW so quoted Windows executable paths stay intact."""
    import ctypes
    from ctypes import wintypes

    shell32 = ctypes.WinDLL("shell32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    command_line_to_argv = shell32.CommandLineToArgvW
    command_line_to_argv.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_int)]
    command_line_to_argv.restype = ctypes.POINTER(wintypes.LPWSTR)
    kernel32.LocalFree.argtypes = [wintypes.HLOCAL]
    kernel32.LocalFree.restype = wintypes.HLOCAL

    argument_count = ctypes.c_int()
    arguments = command_line_to_argv(value, ctypes.byref(argument_count))
    if not arguments:
        raise ValueError("无法解析 Windows 启动命令")
    try:
        return [arguments[index] for index in range(argument_count.value)]
    finally:
        kernel32.LocalFree(arguments)


def start() -> dict[str, dict[str, int | bool]]:
    pid = ensure_daemon_running()
    return {"daemon": {"running": True, "pid": pid}}


def stop() -> dict[str, Any]:
    stopped = stop_daemon()
    return {"daemon": {"running": False}, "stopped": stopped}


def status() -> dict[str, Any]:
    identity = IdentityStore(create=False).load()
    pid = current_daemon_pid(cleanup_stale=False)
    summary = Spool.queue_summary_read_only()
    projects = registered_project_summaries()
    payload = {
        "device": identity.display_name,
        "device_id": identity.device_id,
        "server": identity.server_url,
        "daemon": {"running": bool(pid), "pid": pid},
        "queue": summary,
        "projects": projects,
        "schedule_sync": {
            "pending": (reporter_home() / "schedule-sync.pending.json").exists(),
            "pending_acceptances": (reporter_home() / "schedule-acceptance.pending.json").exists(),
            "interval_seconds": 60,
        },
        "home": str(reporter_home()),
    }
    return payload


def registered_project_summaries() -> list[dict[str, Any]]:
    summaries: list[dict[str, Any]] = []
    for project_dir in registered_projects():
        try:
            config = ProjectConfig.load(project_dir)
        except (OSError, RuntimeError, TypeError, ValueError):
            continue
        summaries.append(
            {
                "project_dir": str(project_dir.resolve()),
                "display_name": config.display_name,
                "integration_id": config.integration_id,
                "sync": read_sync_status(project_dir),
                "dashboard": config.dashboard,
                "windows_wrapper": (
                    project_dir / ".shopops/windows-task-wrapper.ps1"
                ).is_file(),
            }
        )
    return summaries


def flush(timeout: float) -> dict[str, int]:
    uploader = Uploader()
    deadline = time.monotonic() + max(0, timeout)
    while uploader.spool.has_pending() and time.monotonic() < deadline:
        processed = uploader.process_once()
        if not processed:
            time.sleep(0.5)
        else:
            time.sleep(0.1)
    return uploader.spool.queue_summary()
