"""ShopOps Reporter client."""

__version__ = "0.4.1"
