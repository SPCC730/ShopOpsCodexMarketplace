from __future__ import annotations

import ipaddress
import json
from pathlib import Path
from urllib.parse import urlsplit
from typing import Any


DASHBOARD_DESCRIPTOR_PATH = Path(".shopops/dashboard.json")
_ALLOWED_KINDS = {"html", "live_service"}


def read_dashboard_descriptor(project_dir: Path) -> dict[str, Any] | None:
    """Read and validate the optional project dashboard declaration."""
    path = project_dir / DASHBOARD_DESCRIPTOR_PATH
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise RuntimeError(f"{DASHBOARD_DESCRIPTOR_PATH} 不是有效 JSON: {error}") from error
    return validate_dashboard_descriptor(payload)


def validate_dashboard_descriptor(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError("dashboard.json 必须是 JSON 对象")
    if value.get("version") != 1:
        raise ValueError("dashboard.json version 必须为 1")
    kind = value.get("kind")
    if kind not in _ALLOWED_KINDS:
        raise ValueError("dashboard.json kind 必须为 html 或 live_service")
    title = value.get("title")
    if not isinstance(title, str) or not title.strip() or len(title.strip()) > 200:
        raise ValueError("dashboard.json title 必须为 1-200 个字符")

    allowed = {"version", "kind", "title", "url", "path"}
    if set(value) - allowed:
        raise ValueError("dashboard.json 包含未知字段")
    if kind == "live_service":
        url = value.get("url")
        if not isinstance(url, str):
            raise ValueError("live_service 看板必须提供 url")
        _validate_live_service_url(url)
        if value.get("path") is not None:
            raise ValueError("live_service 看板不能提供 path")
        return {"version": 1, "kind": kind, "title": title.strip(), "url": url.strip()}

    path = value.get("path")
    if not isinstance(path, str) or not path.strip():
        raise ValueError("html 看板必须提供 path")
    _validate_relative_path(path)
    if value.get("url") is not None:
        raise ValueError("html 看板不能提供 url")
    return {"version": 1, "kind": kind, "title": title.strip(), "path": path.strip()}


def _validate_relative_path(value: str) -> None:
    normalized = value.replace("\\", "/")
    parts = [part for part in normalized.split("/") if part]
    if (
        not parts
        or "\x00" in value
        or normalized.startswith("/")
        or (len(normalized) > 1 and normalized[1] == ":")
        or ".." in parts
    ):
        raise ValueError("dashboard.json path 必须是项目内相对路径")


def _validate_live_service_url(value: str) -> None:
    try:
        parsed = urlsplit(value.strip())
        host = parsed.hostname or ""
        port = parsed.port
        address = ipaddress.ip_address(host) if host.lower() != "localhost" else None
    except ValueError as error:
        raise ValueError("live_service url 格式无效") from error
    valid = (
        parsed.scheme == "http"
        and (
            host.lower() == "localhost"
            or (
                address is not None
                and address.is_private
                and not address.is_multicast
                and not address.is_unspecified
            )
        )
        and port is not None
        and 1 <= port <= 65535
        and parsed.username is None
        and parsed.password is None
        and not parsed.query
        and not parsed.fragment
    )
    if not valid:
        raise ValueError(
            "live_service url 只能使用带端口的 HTTP 私有地址，不能包含凭据、查询参数或片段"
        )
