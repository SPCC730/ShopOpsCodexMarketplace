"""Local, privacy-preserving mapping between Windows tasks and SOP projects.

The map is intentionally small and explicit.  Reporter never uploads command
lines, arguments, environment variables, or the complete Task Scheduler XML.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any, Iterable

from shopops_reporter.config import ensure_private_directory, reporter_home


MAP_PATH = Path(".shopops/schedule-map.json")
REGISTRY_PATH = Path("projects.json")
MAP_VERSION = 1


def _canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def mapping_hash(value: Any) -> str:
    return f"sha256:{hashlib.sha256(_canonical(value)).hexdigest()}"


def load_schedule_map(project_dir: Path) -> dict[str, Any]:
    path = project_dir / MAP_PATH
    if not path.exists():
        return {"version": MAP_VERSION, "mappings": []}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise ValueError(f"{MAP_PATH} 不是有效 JSON: {error}") from error
    return validate_schedule_map(payload)


def validate_schedule_map(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict) or value.get("version") != MAP_VERSION:
        raise ValueError("schedule-map.json version 必须为 1")
    mappings = value.get("mappings", [])
    if not isinstance(mappings, list) or len(mappings) > 200:
        raise ValueError("schedule-map.json mappings 必须是最多 200 项的数组")
    normalized: list[dict[str, Any]] = []
    for item in mappings:
        if not isinstance(item, dict):
            raise ValueError("schedule-map.json mapping 必须是对象")
        allowed = {
            "schedule_key",
            "task_name",
            "project_fingerprint",
            "integration_id",
            "definition_hash",
            "mapping_hash",
            "expected_on_each_run",
            "accepted",
        }
        if set(item) - allowed:
            raise ValueError("schedule-map.json mapping 包含未知字段")
        schedule_key = item.get("schedule_key")
        fingerprint = item.get("project_fingerprint")
        if not isinstance(schedule_key, str) or not schedule_key.strip():
            raise ValueError("schedule-map.json schedule_key 不能为空")
        if not isinstance(fingerprint, str) or not fingerprint.strip():
            raise ValueError("schedule-map.json project_fingerprint 不能为空")
        normalized.append(
            {
                "schedule_key": schedule_key.strip(),
                "task_name": str(item.get("task_name") or "").strip()[:200],
                "project_fingerprint": fingerprint.strip(),
                "integration_id": item.get("integration_id"),
                "definition_hash": item.get("definition_hash"),
                "mapping_hash": item.get("mapping_hash"),
                "expected_on_each_run": bool(item.get("expected_on_each_run", False)),
                "accepted": bool(item.get("accepted", False)),
            }
        )
    return {"version": MAP_VERSION, "mappings": normalized}


def save_schedule_map(project_dir: Path, value: dict[str, Any]) -> Path:
    normalized = validate_schedule_map(value)
    path = project_dir / MAP_PATH
    ensure_private_directory(path.parent)
    if path.exists():
        backup = path.with_suffix(path.suffix + ".bak")
        shutil.copy2(path, backup)
    fd, temporary = tempfile.mkstemp(prefix="schedule-map-", suffix=".json", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(normalized, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)
    return path


def register_project(project_dir: Path) -> None:
    """Remember initialized projects so the daemon can scan their mappings."""
    home = ensure_private_directory(reporter_home())
    path = home / REGISTRY_PATH
    projects: list[str] = []
    if path.exists():
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(payload, list):
                projects = [item for item in payload if isinstance(item, str)]
        except (OSError, ValueError):
            projects = []
    resolved = str(project_dir.resolve())
    if resolved not in projects:
        projects.append(resolved)
    _atomic_json_write(path, projects)


def registered_projects() -> list[Path]:
    path = reporter_home() / REGISTRY_PATH
    if not path.exists():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    if not isinstance(payload, list):
        return []
    return [Path(item) for item in payload if isinstance(item, str) and Path(item).is_dir()]


def mappings_for_schedule(project_dirs: Iterable[Path], schedule_key: str) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for project_dir in project_dirs:
        try:
            payload = load_schedule_map(project_dir)
        except ValueError:
            continue
        for mapping in payload["mappings"]:
            if mapping["schedule_key"] == schedule_key:
                result.append({**mapping, "project_dir": str(project_dir.resolve())})
    return result


def accept_mapping(
    project_dir: Path,
    *,
    schedule_key: str,
    project_fingerprint: str,
    integration_id: str | None = None,
    task_name: str | None = None,
    definition_hash: str | None = None,
    mapping_hash_value: str | None = None,
    expected_on_each_run: bool = False,
) -> Path:
    """Persist an explicitly accepted developer mapping atomically."""
    payload = load_schedule_map(project_dir)
    mappings = [
        item
        for item in payload["mappings"]
        if not (
            item["schedule_key"] == schedule_key
            and item["project_fingerprint"] == project_fingerprint
        )
    ]
    mappings.append(
        {
            "schedule_key": schedule_key,
            "task_name": task_name or "",
            "project_fingerprint": project_fingerprint,
            "integration_id": integration_id,
            "definition_hash": definition_hash,
            "mapping_hash": mapping_hash_value,
            "expected_on_each_run": expected_on_each_run,
            "accepted": True,
        }
    )
    return save_schedule_map(project_dir, {"version": MAP_VERSION, "mappings": mappings})


def _atomic_json_write(path: Path, value: Any) -> None:
    fd, temporary = tempfile.mkstemp(prefix=f"{path.stem}-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)
