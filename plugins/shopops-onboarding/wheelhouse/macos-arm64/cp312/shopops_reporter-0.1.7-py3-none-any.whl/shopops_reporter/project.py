from __future__ import annotations

import hashlib
import json
import os
import platform
import secrets
import shlex
import subprocess
from pathlib import Path
from typing import Any, Iterable
from uuid import uuid4

from shopops_reporter import __version__
from shopops_reporter.client import ReporterClient
from shopops_reporter.config import ProjectConfig
from shopops_reporter.dashboard import read_dashboard_descriptor
from shopops_reporter.schedule_map import register_project


EXCLUDED_PARTS = {
    ".git",
    ".shopops",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "dist",
    "build",
    "output",
    "outputs",
    "reports",
    "logs",
    "downloads",
    "tmp",
    "temp",
}
SENSITIVE_NAMES = {".env", ".env.local", "credentials.json", "secrets.json"}
FINGERPRINT_SUFFIXES = {
    ".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".ps1", ".r",
    ".json", ".yaml", ".yml", ".toml", ".lock", ".txt",
}
ARTIFACT_TYPES = {
    ".csv": "csv",
    ".xlsx": "xlsx",
    ".json": "json",
    ".txt": "text",
    ".log": "log",
    ".png": "image",
    ".jpg": "image",
    ".jpeg": "image",
    ".webp": "image",
    ".pdf": "pdf",
}


def project_fingerprint(project_dir: Path) -> str:
    digest = hashlib.sha256()
    count = 0
    for path in sorted(_fingerprint_files(project_dir), key=lambda item: item.as_posix()):
        relative = path.relative_to(project_dir).as_posix()
        digest.update(relative.encode("utf-8"))
        try:
            with path.open("rb") as handle:
                while chunk := handle.read(1024 * 1024):
                    digest.update(chunk)
        except OSError:
            continue
        count += 1
    if count == 0:
        digest.update(str(project_dir).encode("utf-8"))
    return f"sha256:{digest.hexdigest()}"


def _fingerprint_files(project_dir: Path) -> Iterable[Path]:
    for root, dirs, files in os.walk(project_dir):
        dirs[:] = [name for name in dirs if name not in EXCLUDED_PARTS]
        root_path = Path(root)
        for name in files:
            path = root_path / name
            if name in SENSITIVE_NAMES or name.startswith(".env."):
                continue
            if path.suffix.lower() not in FINGERPRINT_SUFFIXES:
                continue
            try:
                if path.is_symlink() or path.stat().st_size > 10 * 1024 * 1024:
                    continue
            except OSError:
                continue
            yield path


def git_metadata(project_dir: Path) -> dict[str, Any]:
    def run(*args: str) -> str | None:
        try:
            result = subprocess.run(
                ["git", "-C", str(project_dir), *args],
                check=True,
                capture_output=True,
                text=True,
                timeout=5,
            )
        except (OSError, subprocess.SubprocessError):
            return None
        return result.stdout.strip()

    commit = run("rev-parse", "HEAD")
    if not commit:
        return {"available": False}
    return {
        "available": True,
        "branch": run("branch", "--show-current") or "detached",
        "commit": commit,
        "dirty": bool(run("status", "--porcelain")),
    }


def environment_metadata() -> dict[str, Any]:
    return {
        "os": f"{platform.system()} {platform.release()}",
        "python": platform.python_version(),
        "runtime": f"Python {platform.python_version()}",
        "reporter_version": __version__,
    }


def initialize_project(
    *,
    client: ReporterClient,
    project_dir: Path,
    display_name: str,
    platform_name: str,
    command: list[str],
    artifacts: list[str],
    html_reports: list[str],
    result_json: str | None,
) -> tuple[ProjectConfig, bool]:
    project_dir = project_dir.resolve()
    existing: ProjectConfig | None = None
    try:
        existing = ProjectConfig.load(project_dir)
    except RuntimeError:
        pass
    fingerprint = project_fingerprint(project_dir)
    dashboard = read_dashboard_descriptor(project_dir)
    project_key = existing.project_key if existing else str(uuid4())
    payload: dict[str, Any] = {
        "project_key": project_key,
        "display_name": display_name,
        "platform": platform_name,
        "initial_discovery_fingerprint": (
            existing.initial_discovery_fingerprint if existing else fingerprint
        ),
        "project_fingerprint": fingerprint,
        "command_summary": redact_command(command),
        "upload_policy": {
            "artifacts": artifacts,
            "html_reports": html_reports,
            "dashboard": dashboard,
        },
    }
    if existing:
        payload["descriptor"] = existing.descriptor
        payload["descriptor_signature"] = existing.descriptor_signature
    response = client.signed_json("POST", "/reporter/v1/integrations/resolve", payload)
    config = ProjectConfig(
        version=1,
        project_key=project_key,
        integration_id=str(response["integration_id"]),
        display_name=display_name,
        platform=platform_name,
        working_directory=".",
        command=command,
        initial_discovery_fingerprint=payload["initial_discovery_fingerprint"],
        descriptor=response["descriptor"],
        descriptor_signature=response["descriptor_signature"],
        artifacts=artifacts,
        html_reports=html_reports,
        result_json=result_json,
        dashboard=dashboard,
    )
    config.save(project_dir)
    write_launchers(project_dir)
    register_project(project_dir)
    return config, bool(response.get("created"))


def redact_command(command: list[str]) -> str:
    sensitive = {"password", "token", "secret", "cookie", "authorization"}
    result: list[str] = []
    redact_next = False
    for part in command:
        lowered = part.lower().lstrip("-")
        if redact_next:
            result.append("[REDACTED]")
            redact_next = False
        elif lowered in sensitive:
            result.append(part)
            redact_next = True
        elif any(lowered.startswith(f"{key}=") for key in sensitive):
            result.append(f"{part.split('=', 1)[0]}=[REDACTED]")
        else:
            result.append(part)
    return shlex.join(result)[:500]


def write_launchers(project_dir: Path) -> None:
    directory = project_dir / ".shopops"
    directory.mkdir(parents=True, exist_ok=True)
    command = directory / "run.command"
    command.write_text(
        "#!/bin/sh\n"
        "set -eu\n"
        "cd \"$(dirname \"$0\")/..\"\n"
        "REPORTER_HOME=${SHOPOPS_REPORTER_HOME:-\"$HOME/.shopops-reporter\"}\n"
        "exec \"$REPORTER_HOME/bin/shopops-report\" run\n",
        encoding="utf-8",
    )
    if os.name != "nt":
        command.chmod(0o755)
    (directory / "run.ps1").write_text(
        "$ErrorActionPreference = 'Stop'\n"
        "Set-Location (Join-Path $PSScriptRoot '..')\n"
        "$ReporterHome = if ($env:SHOPOPS_REPORTER_HOME) {\n"
        "  $env:SHOPOPS_REPORTER_HOME\n"
        "} else {\n"
        "  Join-Path $env:LOCALAPPDATA 'ShopOps\\Reporter'\n"
        "}\n"
        "$Reporter = Join-Path $ReporterHome 'bin\\shopops-report.cmd'\n"
        "& $Reporter run @args\n"
        "exit $LASTEXITCODE\n",
        encoding="utf-8",
    )
    (directory / "windows-task-wrapper.ps1").write_text(
        "param(\n"
        "  [string]$TaskKey,\n"
        "  [string]$TaskPath,\n"
        "  [string]$TriggerInstanceId,\n"
        "  [Parameter(ValueFromRemainingArguments = $true)]\n"
        "  [string[]]$ArgumentList\n"
        ")\n"
        "$ErrorActionPreference = 'Stop'\n"
        "$env:SHOPOPS_WINDOWS_TASK_KEY = $TaskKey\n"
        "$env:SHOPOPS_WINDOWS_TASK_PATH = $TaskPath\n"
        "$env:SHOPOPS_TRIGGER_INSTANCE_ID = if ($TriggerInstanceId) { $TriggerInstanceId } else { [guid]::NewGuid().ToString() }\n"
        "$env:SHOPOPS_TRIGGER_KIND = 'scheduled'\n"
        "$run = Join-Path $PSScriptRoot 'run.ps1'\n"
        "& $run @ArgumentList\n"
        "exit $LASTEXITCODE\n",
        encoding="utf-8",
    )


def read_result(config: ProjectConfig, project_dir: Path) -> dict[str, Any]:
    if not config.result_json:
        return {}
    target = safe_project_path(project_dir, config.result_json)
    if not target.is_file():
        return {"reporter_warning": f"结果文件不存在: {config.result_json}"}
    try:
        value = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        return {"reporter_warning": f"结果文件解析失败: {error}"}
    return value if isinstance(value, dict) else {"value": value}


def matching_files(project_dir: Path, patterns: list[str]) -> list[Path]:
    matched: dict[Path, None] = {}
    root = project_dir.resolve()
    for pattern in patterns:
        for candidate in root.glob(pattern):
            try:
                if candidate.is_symlink():
                    continue
                resolved = candidate.resolve(strict=True)
                resolved.relative_to(root)
            except (OSError, ValueError):
                continue
            if resolved.is_file():
                matched[resolved] = None
    return sorted(matched)


def safe_project_path(project_dir: Path, relative: str) -> Path:
    root = project_dir.resolve()
    target = (root / relative).resolve()
    try:
        target.relative_to(root)
    except ValueError as error:
        raise RuntimeError(f"项目路径越界: {relative}") from error
    return target


def artifact_type(path: Path) -> str | None:
    return ARTIFACT_TYPES.get(path.suffix.lower())


def artifact_digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def artifact_key(path: Path, project_dir: Path) -> str:
    relative = path.relative_to(project_dir.resolve()).as_posix()
    return f"file-{hashlib.sha256(relative.encode()).hexdigest()[:24]}"


def new_report_token() -> str:
    return secrets.token_urlsafe(24)
