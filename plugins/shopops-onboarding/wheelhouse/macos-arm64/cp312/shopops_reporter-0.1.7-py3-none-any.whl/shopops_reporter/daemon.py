from __future__ import annotations

import json
import ipaddress
import os
import signal
import socket
import subprocess
import sys
import threading
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit, urlunsplit

from shopops_reporter.client import ReporterApiError, ReporterClient
from shopops_reporter.config import IdentityStore, ProjectConfig, ensure_private_directory, reporter_home
from shopops_reporter.dashboard import validate_dashboard_descriptor
from shopops_reporter.html_server import ReportServer
from shopops_reporter.project import artifact_digest, artifact_key, artifact_type, matching_files
from shopops_reporter.scheduler import WindowsTaskScheduler
from shopops_reporter.spool import Spool


DEFAULT_REPORT_PORT = 18765
SCHEDULE_SYNC_INTERVAL_SECONDS = 60


def daemon_pid_path() -> Path:
    return reporter_home() / "reporter.pid"


def daemon_log_path() -> Path:
    return reporter_home() / "reporter.log"


def report_port() -> int:
    return int(os.environ.get("SHOPOPS_REPORTER_PORT", DEFAULT_REPORT_PORT))


def _is_windows() -> bool:
    return os.name == "nt"


def _windows_process_running(pid: int) -> bool:
    """Query a Windows process handle without sending it a signal."""
    import ctypes
    from ctypes import wintypes

    process_query_limited_information = 0x1000
    still_active = 259
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
    kernel32.GetExitCodeProcess.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL

    handle = kernel32.OpenProcess(process_query_limited_information, False, pid)
    if not handle:
        return False
    try:
        exit_code = wintypes.DWORD()
        return bool(kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code))) and (
            exit_code.value == still_active
        )
    finally:
        kernel32.CloseHandle(handle)


def process_running(pid: int) -> bool:
    if pid <= 0:
        return False
    if _is_windows():
        return _windows_process_running(pid)
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def current_daemon_pid(*, cleanup_stale: bool = True) -> int | None:
    path = daemon_pid_path()
    if not path.exists():
        return None
    try:
        pid = int(path.read_text(encoding="ascii").strip())
    except (OSError, ValueError):
        if cleanup_stale:
            path.unlink(missing_ok=True)
        return None
    if not process_running(pid):
        if cleanup_stale:
            path.unlink(missing_ok=True)
        return None
    return pid


def ensure_daemon_running() -> int:
    existing = current_daemon_pid()
    if existing:
        return existing
    home = ensure_private_directory(reporter_home())
    log = (home / "reporter.log").open("ab", buffering=0)
    kwargs: dict[str, Any] = {
        "stdin": subprocess.DEVNULL,
        "stdout": log,
        "stderr": log,
        "cwd": str(home),
    }
    if os.name == "nt":
        kwargs["creationflags"] = (
            subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
        )
    else:
        kwargs["start_new_session"] = True
    process = subprocess.Popen(
        [sys.executable, "-m", "shopops_reporter", "serve"],
        **kwargs,
    )
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        pid = current_daemon_pid()
        if pid:
            return pid
        if process.poll() is not None:
            break
        time.sleep(0.1)
    raise RuntimeError(f"Reporter 后台服务未能启动，请查看 {daemon_log_path()}")


def stop_daemon() -> bool:
    pid = current_daemon_pid()
    if not pid:
        return False
    try:
        os.kill(pid, signal.SIGTERM)
    except OSError:
        daemon_pid_path().unlink(missing_ok=True)
        return False
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline and process_running(pid):
        time.sleep(0.1)
    daemon_pid_path().unlink(missing_ok=True)
    return True


class Uploader:
    def __init__(self, spool: Spool | None = None, client: ReporterClient | None = None):
        self.spool = spool or Spool()
        self.client = client or ReporterClient(IdentityStore().load())
        self.last_device_ping = 0.0
        self.last_device_error: str | None = None

    def process_once(self) -> int:
        self._ping_device_if_due()
        processed = 0
        for run in self.spool.pending_runs():
            try:
                self._process_run(run)
                processed += 1
            except Exception as error:
                self.spool.record_error(run["local_run_key"], error)
        return processed

    def _ping_device_if_due(self) -> None:
        now = time.monotonic()
        if now - self.last_device_ping < 30:
            return
        try:
            self.client.signed_get("/reporter/v1/devices/self")
            self.last_device_error = None
        except Exception as error:
            self.last_device_error = str(error)
        finally:
            self.last_device_ping = now

    def _process_run(self, run: dict[str, Any]) -> None:
        local_key = run["local_run_key"]
        server_run_id = run["server_run_id"]
        if not server_run_id:
            started = self.client.signed_json(
                "POST",
                "/reporter/v1/runs/start",
                {
                    "integration_id": run["integration_id"],
                    "external_run_key": local_key,
                    "project_fingerprint": run["project_fingerprint"],
                    "git_metadata": json.loads(run["git_json"]),
                    "environment_metadata": json.loads(run["environment_json"]),
                    "started_at": run["started_at"],
                    "inputs": {},
                    "windows_task_key": run.get("windows_task_key"),
                    "windows_task_path": run.get("windows_task_path"),
                    "trigger_instance_id": run.get("trigger_instance_id"),
                    "trigger_kind": run.get("trigger_kind"),
                },
            )
            server_run_id = str(started["run_id"])
            self.spool.set_server_run(local_key, server_run_id)
            run = self.spool.get_run(local_key) or run

        after = int(run["last_uploaded_sequence"])
        for _ in range(10):
            records = self.spool.log_batch(local_key, after)
            if not records:
                break
            response = self.client.signed_json(
                "POST",
                f"/reporter/v1/runs/{server_run_id}/logs:batch",
                {"records": records},
            )
            after = int(response["last_log_sequence"])
            self.spool.acknowledge_logs(local_key, after)
            if len(records) < 100:
                break

        run = self.spool.get_run(local_key) or run
        if run["local_status"] == "running":
            last_heartbeat = float(run["last_heartbeat_at"] or 0)
            if time.time() - last_heartbeat >= 15:
                self.client.signed_json(
                    "POST",
                    f"/reporter/v1/runs/{server_run_id}/heartbeat",
                    {
                        "environment_metadata": json.loads(run["environment_json"]),
                        "queue_summary": self.spool.queue_summary(),
                    },
                )
                self.spool.heartbeat_sent(local_key)
            return

        if self.spool.log_batch(local_key, after, limit=1):
            return
        self._prepare_and_upload_artifacts(run, server_run_id)
        run = self.spool.get_run(local_key) or run
        if run.get("logs_partial"):
            completeness = "logs_partial"
        elif self.spool.artifact_incomplete(local_key):
            completeness = "artifacts_partial"
        else:
            completeness = "complete"
        live_report_url, live_report_kind = self._live_report(run)
        completion = {
            "status": run["local_status"],
            "exit_code": int(run["exit_code"]),
            "ended_at": run["ended_at"],
            "result": json.loads(run["result_json"]),
            "report_completeness": completeness,
            "live_report_url": live_report_url,
        }
        if live_report_url and live_report_kind == "live_service":
            completion["live_report_kind"] = live_report_kind
        self.client.signed_json(
            "POST",
            f"/reporter/v1/runs/{server_run_id}/complete",
            completion,
        )
        self.spool.complete_upload(local_key)

    def _prepare_and_upload_artifacts(self, run: dict[str, Any], server_run_id: str) -> None:
        config = ProjectConfig(**json.loads(run["config_json"]))
        project_dir = Path(run["project_dir"])
        for path in matching_files(project_dir, config.artifacts):
            kind = artifact_type(path)
            if not kind:
                continue
            self.spool.add_artifact(
                run["local_run_key"],
                artifact_key=artifact_key(path, project_dir),
                path=path,
                artifact_type=kind,
                sha256=artifact_digest(path),
            )
        for artifact in self.spool.pending_artifacts(run["local_run_key"]):
            path = Path(artifact["path"])
            if not path.is_file() or artifact_digest(path) != artifact["sha256"]:
                self.spool.artifact_finished(
                    run["local_run_key"],
                    artifact["artifact_key"],
                    accepted=False,
                    error="附件在运行结束后发生变化或已不存在",
                )
                continue
            try:
                self.client.upload_artifact(
                    run_id=server_run_id,
                    artifact_key=artifact["artifact_key"],
                    path=path,
                    artifact_type=artifact["artifact_type"],
                )
            except ReporterApiError as error:
                if 400 <= error.status_code < 500 and error.status_code not in {408, 429}:
                    self.spool.artifact_finished(
                        run["local_run_key"],
                        artifact["artifact_key"],
                        accepted=False,
                        error=str(error),
                    )
                    continue
                raise
            self.spool.artifact_finished(
                run["local_run_key"],
                artifact["artifact_key"],
                accepted=True,
            )

    def _live_report_url(self, run: dict[str, Any]) -> str | None:
        return self._live_report(run)[0]

    def _live_report(self, run: dict[str, Any]) -> tuple[str | None, str | None]:
        try:
            config = ProjectConfig(**json.loads(run["config_json"]))
        except (KeyError, TypeError, ValueError):
            config = None
        if config and config.dashboard:
            try:
                dashboard = validate_dashboard_descriptor(config.dashboard)
            except ValueError:
                dashboard = None
            if dashboard and dashboard["kind"] == "live_service":
                return resolve_live_service_url(
                    dashboard["url"],
                    self.client.identity.server_url,
                ), "live_service"
        token = run.get("live_report_token")
        path = run.get("live_report_path")
        if not token or not path or not Path(path).is_file():
            return None, None
        return (
            f"http://{local_ipv4(self.client.identity.server_url)}:{report_port()}/reports/{token}/",
            "reporter_snapshot",
        )


class ScheduleSynchronizer:
    """Push a redacted Windows Task Scheduler mirror once per minute."""

    def __init__(
        self,
        client: ReporterClient,
        *,
        scanner: WindowsTaskScheduler | None = None,
        pending_path: Path | None = None,
    ):
        self.client = client
        self.scanner = scanner or WindowsTaskScheduler()
        self.pending_path = pending_path or reporter_home() / "schedule-sync.pending.json"
        self.acceptance_path = self.pending_path.with_name("schedule-acceptance.pending.json")
        self.last_error: str | None = None

    def process_once(self) -> bool:
        scan = self.scanner.scan()
        if not scan.complete:
            self.last_error = scan.error
            return False
        payload = {
            "observed_at": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
            "scan_complete": True,
            "tasks": scan.tasks,
        }
        queued = self._load_pending()
        try:
            # Flush the previous snapshot first. The latest snapshot is then
            # sent in the same cycle, keeping the server eventually current.
            if queued is not None:
                self.client.signed_json("POST", "/reporter/v1/schedules/sync", queued)
                self._clear_pending()
            response = self.client.signed_json("POST", "/reporter/v1/schedules/sync", payload)
            pending_acceptances = response.get("pending_acceptances", [])
            if pending_acceptances:
                self._save_acceptances(pending_acceptances)
            else:
                self.acceptance_path.unlink(missing_ok=True)
            self.last_error = None
            return True
        except Exception as error:
            self.last_error = str(error)
            self._save_pending(payload)
            return False

    def _load_pending(self) -> dict[str, Any] | None:
        try:
            payload = json.loads(self.pending_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
        return payload if isinstance(payload, dict) else None

    def _save_pending(self, payload: dict[str, Any]) -> None:
        ensure_private_directory(self.pending_path.parent)
        temporary = self.pending_path.with_suffix(self.pending_path.suffix + ".tmp")
        temporary.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        temporary.replace(self.pending_path)

    def _clear_pending(self) -> None:
        self.pending_path.unlink(missing_ok=True)

    def _save_acceptances(self, value: Any) -> None:
        ensure_private_directory(self.acceptance_path.parent)
        temporary = self.acceptance_path.with_suffix(self.acceptance_path.suffix + ".tmp")
        temporary.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
        temporary.replace(self.acceptance_path)


def local_ipv4(server_url: str) -> str:
    parsed = urlsplit(server_url)
    host = parsed.hostname or "127.0.0.1"
    port = parsed.port or 80

    def is_loopback(value: str) -> bool:
        try:
            address = ipaddress.ip_address(value)
        except ValueError:
            return True
        return address.version != 4 or address.is_loopback or address.is_unspecified

    def route_address(target: str, target_port: int) -> str | None:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.connect((target, target_port))
            address = sock.getsockname()[0]
        except OSError:
            return None
        finally:
            sock.close()
        return address if not is_loopback(address) else None

    # A LAN ShopOps endpoint gives the most accurate interface selection.
    try:
        server_address = ipaddress.ip_address(host)
    except ValueError:
        server_address = None
    if server_address is None or not server_address.is_loopback:
        address = route_address(host, port)
        if address:
            return address

    # When ShopOps itself is configured on localhost, ask the routing table for
    # the active interface without sending a packet to the probe address.
    for target in ("192.0.2.1", "198.51.100.1"):
        address = route_address(target, 9)
        if address:
            return address

    try:
        infos = socket.getaddrinfo(socket.gethostname(), 0, socket.AF_INET, socket.SOCK_DGRAM)
    except OSError:
        infos = []
    for _family, _socktype, _proto, _canonname, sockaddr in infos:
        address = sockaddr[0]
        if not is_loopback(address):
            return address

    try:
        address = socket.gethostbyname(socket.gethostname())
    except OSError:
        address = "127.0.0.1"
    return address


def resolve_live_service_url(url: str, server_url: str) -> str:
    """Expose loopback dashboard declarations through the developer LAN IP."""
    parsed = urlsplit(url)
    host = parsed.hostname or ""
    try:
        is_loopback = ipaddress.ip_address(host).is_loopback
    except ValueError:
        is_loopback = False
    if host.lower() == "localhost" or is_loopback:
        host = local_ipv4(server_url)
        netloc = f"{host}:{parsed.port}"
        return urlunsplit((parsed.scheme, netloc, parsed.path, "", ""))
    return url


def serve(*, once: bool = False) -> int:
    ensure_private_directory(reporter_home())
    pid_path = daemon_pid_path()
    existing = current_daemon_pid()
    if existing and existing != os.getpid():
        raise RuntimeError(f"Reporter 已在运行，PID {existing}")
    pid_path.write_text(str(os.getpid()), encoding="ascii")
    uploader = Uploader()
    schedule_sync = ScheduleSynchronizer(uploader.client)
    if once:
        try:
            schedule_sync.process_once()
            return uploader.process_once()
        finally:
            pid_path.unlink(missing_ok=True)

    stopped = threading.Event()

    def request_stop(_signum: int, _frame: object) -> None:
        stopped.set()

    signal.signal(signal.SIGTERM, request_stop)
    if hasattr(signal, "SIGINT"):
        signal.signal(signal.SIGINT, request_stop)

    report_server: ReportServer | None = None
    try:
        report_server = ReportServer(("0.0.0.0", report_port()), uploader.spool)
        threading.Thread(target=report_server.serve_forever, daemon=True).start()
    except OSError as error:
        print(f"[ShopOps Reporter] HTML 服务未启动: {error}", file=sys.stderr)

    try:
        last_schedule_sync = 0.0
        while not stopped.is_set():
            try:
                uploader.process_once()
                now = time.monotonic()
                if now - last_schedule_sync >= SCHEDULE_SYNC_INTERVAL_SECONDS:
                    schedule_sync.process_once()
                    last_schedule_sync = now
            except Exception as error:
                print(f"[ShopOps Reporter] 后台循环异常: {error}", file=sys.stderr)
            stopped.wait(0.5)
    finally:
        if report_server:
            report_server.shutdown()
            report_server.server_close()
        pid_path.unlink(missing_ok=True)
    return 0
