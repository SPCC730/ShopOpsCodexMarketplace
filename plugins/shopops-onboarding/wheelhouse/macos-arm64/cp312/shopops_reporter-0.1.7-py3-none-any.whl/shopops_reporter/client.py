from __future__ import annotations

import base64
import hashlib
import json
import time
from pathlib import Path
from typing import Any
from urllib.parse import quote
from uuid import uuid4

import httpx
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from shopops_reporter import __version__
from shopops_reporter.config import DeviceIdentity


class ReporterApiError(RuntimeError):
    def __init__(self, status_code: int, detail: object):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"ShopOps Reporter API {status_code}: {detail}")


def base64url(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).decode("ascii").rstrip("=")


def generate_private_key() -> tuple[str, str]:
    private_key = Ed25519PrivateKey.generate()
    private_raw = private_key.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_raw = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return base64url(private_raw), base64url(public_raw)


def load_private_key(value: str) -> Ed25519PrivateKey:
    padded = value + "=" * (-len(value) % 4)
    return Ed25519PrivateKey.from_private_bytes(base64.urlsafe_b64decode(padded))


def json_body(payload: dict[str, Any]) -> bytes:
    return json.dumps(
        payload,
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode("utf-8")


class ReporterClient:
    def __init__(self, identity: DeviceIdentity, *, timeout: float = 15.0):
        self.identity = identity
        self.private_key = load_private_key(identity.private_key)
        self.http = httpx.Client(timeout=timeout, trust_env=False)

    @staticmethod
    def enroll(
        *,
        server_url: str,
        pairing_code: str,
        installation_id: str,
        display_name: str,
        declared_operator: str | None,
        public_key: str,
    ) -> dict[str, Any]:
        with httpx.Client(timeout=15, trust_env=False) as client:
            response = client.post(
                f"{server_url}/reporter/v1/devices/enroll",
                json={
                    "pairing_code": pairing_code,
                    "installation_id": installation_id,
                    "display_name": display_name,
                    "declared_operator": declared_operator,
                    "public_key": public_key,
                    "reporter_version": __version__,
                },
            )
        return _response_json(response)

    def signed_json(
        self,
        method: str,
        path: str,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        body = json_body(payload)
        return self._request(
            method,
            path,
            body,
            {"Content-Type": "application/json"},
        )

    def signed_get(self, path: str) -> dict[str, Any]:
        return self._request("GET", path, b"", {})

    def sync_schedules(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.signed_json("POST", "/reporter/v1/schedules/sync", payload)

    def accept_schedule(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.signed_json("POST", "/reporter/v1/schedules/accept", payload)

    def upload_artifact(
        self,
        *,
        run_id: str,
        artifact_key: str,
        path: Path,
        artifact_type: str,
    ) -> dict[str, Any]:
        api_path = f"/reporter/v1/runs/{run_id}/artifacts/{quote(artifact_key, safe='')}"
        digest = _file_digest(path)
        headers = self._signed_headers("POST", api_path, digest)
        headers.update(
            {
                "Content-Type": "application/octet-stream",
                "X-ShopOps-Artifact-Name": quote(path.name, safe=""),
                "X-ShopOps-Artifact-Type": artifact_type,
            }
        )
        with path.open("rb") as handle:
            response = self.http.request(
                "POST",
                f"{self.identity.server_url}{api_path}",
                content=handle,
                headers=headers,
            )
        return _response_json(response)

    def _request(
        self,
        method: str,
        path: str,
        body: bytes,
        extra_headers: dict[str, str],
    ) -> dict[str, Any]:
        digest = hashlib.sha256(body).hexdigest()
        headers = self._signed_headers(method, path, digest)
        headers.update(extra_headers)
        response = self.http.request(
            method,
            f"{self.identity.server_url}{path}",
            content=body,
            headers=headers,
        )
        return _response_json(response)

    def _signed_headers(self, method: str, path: str, digest: str) -> dict[str, str]:
        timestamp = str(int(time.time()))
        nonce = uuid4().hex
        canonical = (
            f"v1\n{method.upper()}\n{path}\n{timestamp}\n{nonce}\n{digest}"
        ).encode("utf-8")
        return {
            "X-ShopOps-Device-Id": self.identity.device_id,
            "X-ShopOps-Timestamp": timestamp,
            "X-ShopOps-Nonce": nonce,
            "X-ShopOps-Content-SHA256": digest,
            "X-ShopOps-Signature": base64url(self.private_key.sign(canonical)),
        }


def _response_json(response: httpx.Response) -> dict[str, Any]:
    try:
        payload = response.json()
    except ValueError:
        payload = {"detail": response.text or response.reason_phrase}
    if response.is_error:
        raise ReporterApiError(response.status_code, payload.get("detail", payload))
    if not isinstance(payload, dict):
        raise ReporterApiError(response.status_code, "invalid_response")
    return payload


def _file_digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()
