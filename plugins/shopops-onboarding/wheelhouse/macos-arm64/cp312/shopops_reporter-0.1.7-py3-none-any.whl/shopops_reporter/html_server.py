from __future__ import annotations

import mimetypes
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit

from shopops_reporter.spool import Spool


class ReportServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address: tuple[str, int], spool: Spool):
        super().__init__(address, ReportHandler)
        self.spool = spool


class ReportHandler(BaseHTTPRequestHandler):
    server: ReportServer

    def do_GET(self) -> None:  # noqa: N802
        parts = [unquote(part) for part in urlsplit(self.path).path.split("/") if part]
        if len(parts) < 2 or parts[0] != "reports":
            self.send_error(404)
            return
        entry = self.server.spool.report_for_token(parts[1])
        if entry is None or not entry.is_file() or entry.is_symlink():
            self.send_error(404)
            return
        root = entry.parent.resolve()
        relative = parts[2:]
        candidate = entry if not relative else root / Path(*relative)
        if candidate.is_symlink():
            self.send_error(404)
            return
        target = candidate.resolve()
        try:
            target.relative_to(root)
        except ValueError:
            self.send_error(404)
            return
        if not target.is_file():
            self.send_error(404)
            return
        try:
            body = target.read_bytes()
        except OSError:
            self.send_error(404)
            return
        content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, _format: str, *_args: object) -> None:
        return
