"""ShopOps Reporter client."""

__version__ = "0.1.1"
