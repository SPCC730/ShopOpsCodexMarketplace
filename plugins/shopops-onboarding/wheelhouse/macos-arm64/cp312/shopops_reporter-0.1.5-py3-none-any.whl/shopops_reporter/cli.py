from __future__ import annotations

import argparse
import contextlib
import getpass
import json
import os
import shlex
import sys
import time
from pathlib import Path
from typing import Any
from uuid import uuid4

from shopops_reporter.client import ReporterApiError, ReporterClient, generate_private_key
from shopops_reporter.config import (
    IdentityStore,
    NotPairedError,
    ProjectConfig,
    default_device_name,
    find_project_dir,
    normalize_server_url,
    reporter_home,
)
from shopops_reporter.daemon import (
    Uploader,
    current_daemon_pid,
    ensure_daemon_running,
    serve,
    stop_daemon,
)
from shopops_reporter.project import initialize_project
from shopops_reporter.protocol import emit_error, emit_success
from shopops_reporter.runner import run_project
from shopops_reporter.spool import Spool


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(
        prog="shopops-report",
        description="在开发者电脑运行原脚本，并向 ShopOps 上报运行记录。",
    )
    root.add_argument("--json", action="store_true", dest="json_output")
    commands = root.add_subparsers(dest="action", required=True)

    enroll = commands.add_parser("enroll", help="使用一次性配对码登记这台电脑")
    enroll.add_argument("--server", required=True, help="ShopOps 后端地址")
    enroll.add_argument("--pairing-code", help="管理台生成的一次性配对码")
    enroll.add_argument("--name", default=default_device_name(), help="设备显示名称")
    enroll.add_argument("--operator", help="开发者声明名称")
    enroll.add_argument("--force", action="store_true", help="覆盖本机已有设备身份")

    init = commands.add_parser("init", help="接入当前脚本项目")
    init.add_argument("--name", required=True, help="SOP/项目名称")
    init.add_argument("--platform", default="通用", help="业务平台")
    init.add_argument("--command", required=True, help="原脚本启动命令")
    init.add_argument("--artifact", action="append", default=[], help="附件相对 glob，可重复")
    init.add_argument("--html-report", action="append", default=[], help="HTML 相对 glob，可重复")
    init.add_argument("--result-json", help="结构化结果 JSON 相对路径")
    init.add_argument("--project-dir", type=Path, default=Path.cwd())

    run = commands.add_parser("run", help="运行当前项目并上报")
    run.add_argument("command", nargs=argparse.REMAINDER, help="可选命令覆盖，写在 -- 后")

    commands.add_parser("start", help="启动 Reporter 后台服务")
    commands.add_parser("stop", help="停止 Reporter 后台服务")
    commands.add_parser("status", help="查看设备、后台服务和离线队列状态")
    serve_parser = commands.add_parser("serve", help=argparse.SUPPRESS)
    serve_parser.add_argument("--once", action="store_true")
    flush = commands.add_parser("flush", help="立即补传本地队列")
    flush.add_argument("--timeout", type=float, default=30)
    return root


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        return dispatch(args)
    except ReporterApiError as error:
        if args.json_output:
            emit_error(args.action, "api_error", str(error.detail))
            return 2
        print(f"Reporter API 请求失败：{error.detail}（HTTP {error.status_code}）", file=sys.stderr)
        return 2
    except NotPairedError as error:
        if args.json_output:
            emit_error(args.action, "not_paired", str(error))
            return 2
        print(f"ShopOps Reporter：{error}", file=sys.stderr)
        return 2
    except (OSError, RuntimeError, ValueError) as error:
        if args.json_output:
            code = "validation_error" if isinstance(error, ValueError) else "runtime_error"
            emit_error(args.action, code, str(error))
            return 2
        print(f"ShopOps Reporter：{error}", file=sys.stderr)
        return 2


def dispatch(args: argparse.Namespace) -> int:
    if args.action == "enroll":
        data = enroll(args)
        if args.json_output:
            emit_success("enroll", data)
        else:
            print(f"设备配对成功：{data['device']}")
            print(f"设备 ID：{data['device_id']}")
            print(f"私钥存储：{data['private_key_storage']}")
        return 0
    if args.action == "init":
        if args.json_output:
            with contextlib.redirect_stdout(sys.stderr):
                exit_code = init_project(args)
            emit_success("init", {"exit_code": exit_code})
            return exit_code
        return init_project(args)
    if args.action == "run":
        project_dir = find_project_dir()
        config = ProjectConfig.load(project_dir)
        override = list(args.command)
        if override and override[0] == "--":
            override.pop(0)
        if args.json_output:
            exit_code = run_project(
                project_dir=project_dir,
                config=config,
                command_override=override or None,
                output_stream=sys.stderr.buffer,
            )
            emit_success("run", {"exit_code": exit_code})
            return exit_code
        return run_project(project_dir=project_dir, config=config, command_override=override or None)
    if args.action == "start":
        data = start()
        if args.json_output:
            emit_success("start", data)
        else:
            print(f"Reporter 已启动，PID {data['daemon']['pid']}")
        return 0
    if args.action == "stop":
        data = stop()
        if args.json_output:
            emit_success("stop", data)
        else:
            print("Reporter 已停止" if data["stopped"] else "Reporter 当前未运行")
        return 0
    if args.action == "status":
        data = status()
        if args.json_output:
            emit_success("status", data)
        else:
            print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0
    if args.action == "serve":
        serve(once=args.once)
        if args.json_output:
            emit_success("serve", {"exit_code": 0})
        return 0
    if args.action == "flush":
        data = flush(args.timeout)
        if args.json_output:
            emit_success("flush", data)
        else:
            print(json.dumps(data, ensure_ascii=False))
        return 0 if data["pending_runs"] == 0 else 1
    raise RuntimeError(f"未知命令: {args.action}")


def enroll(args: argparse.Namespace) -> dict[str, Any]:
    store = IdentityStore()
    if store.exists() and not args.force:
        raise RuntimeError("这台电脑已经配对；如需替换身份请使用 --force")
    pairing_code = args.pairing_code or getpass.getpass("一次性配对码：").strip()
    if not pairing_code:
        raise ValueError("配对码不能为空")
    server_url = normalize_server_url(args.server)
    installation_id = str(uuid4())
    private_key, public_key = generate_private_key()
    response = ReporterClient.enroll(
        server_url=server_url,
        pairing_code=pairing_code,
        installation_id=installation_id,
        display_name=args.name,
        declared_operator=args.operator,
        public_key=public_key,
    )
    identity = store.save(
        server_url=server_url,
        device_id=str(response["id"]),
        installation_id=installation_id,
        display_name=args.name,
        declared_operator=args.operator,
        private_key=private_key,
    )
    return {
        "device": identity.display_name,
        "device_id": identity.device_id,
        "private_key_storage": identity.private_key_storage,
    }


def init_project(args: argparse.Namespace) -> int:
    identity = IdentityStore().load()
    command = split_command(args.command)
    if not command:
        raise ValueError("启动命令不能为空")
    config, created = initialize_project(
        client=ReporterClient(identity),
        project_dir=args.project_dir,
        display_name=args.name,
        platform_name=args.platform,
        command=command,
        artifacts=args.artifact,
        html_reports=args.html_report,
        result_json=args.result_json,
    )
    print("已创建待确认 SOP" if created else "已更新现有外部 SOP 接入")
    print(f"Integration ID：{config.integration_id}")
    print(f"配置文件：{args.project_dir.resolve() / '.shopops/integration.yaml'}")
    return 0


def _is_windows() -> bool:
    return os.name == "nt"


def split_command(value: str) -> list[str]:
    """Split a configured command with the native host quoting rules."""
    if not value.strip():
        return []
    if _is_windows():
        return _split_windows_command(value)
    return shlex.split(value)


def _split_windows_command(value: str) -> list[str]:
    """Use CommandLineToArgvW so quoted Windows executable paths stay intact."""
    import ctypes
    from ctypes import wintypes

    shell32 = ctypes.WinDLL("shell32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    command_line_to_argv = shell32.CommandLineToArgvW
    command_line_to_argv.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_int)]
    command_line_to_argv.restype = ctypes.POINTER(wintypes.LPWSTR)
    kernel32.LocalFree.argtypes = [wintypes.HLOCAL]
    kernel32.LocalFree.restype = wintypes.HLOCAL

    argument_count = ctypes.c_int()
    arguments = command_line_to_argv(value, ctypes.byref(argument_count))
    if not arguments:
        raise ValueError("无法解析 Windows 启动命令")
    try:
        return [arguments[index] for index in range(argument_count.value)]
    finally:
        kernel32.LocalFree(arguments)


def start() -> dict[str, dict[str, int | bool]]:
    pid = ensure_daemon_running()
    return {"daemon": {"running": True, "pid": pid}}


def stop() -> dict[str, Any]:
    stopped = stop_daemon()
    return {"daemon": {"running": False}, "stopped": stopped}


def status() -> dict[str, Any]:
    identity = IdentityStore(create=False).load()
    pid = current_daemon_pid(cleanup_stale=False)
    summary = Spool.queue_summary_read_only()
    payload = {
        "device": identity.display_name,
        "device_id": identity.device_id,
        "server": identity.server_url,
        "daemon": {"running": bool(pid), "pid": pid},
        "queue": summary,
        "home": str(reporter_home()),
    }
    return payload


def flush(timeout: float) -> dict[str, int]:
    uploader = Uploader()
    deadline = time.monotonic() + max(0, timeout)
    while uploader.spool.has_pending() and time.monotonic() < deadline:
        processed = uploader.process_once()
        if not processed:
            time.sleep(0.5)
        else:
            time.sleep(0.1)
    return uploader.spool.queue_summary()
