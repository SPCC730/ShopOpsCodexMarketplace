from __future__ import annotations

import subprocess
import sys
import threading
from datetime import UTC, datetime
from pathlib import Path
from typing import BinaryIO
from uuid import uuid4

from shopops_reporter.config import ProjectConfig
from shopops_reporter.daemon import ensure_daemon_running
from shopops_reporter.project import (
    environment_metadata,
    git_metadata,
    matching_files,
    new_report_token,
    project_fingerprint,
    read_result,
)
from shopops_reporter.spool import Spool


def utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def run_project(
    *,
    project_dir: Path,
    config: ProjectConfig,
    command_override: list[str] | None = None,
    spool: Spool | None = None,
    start_daemon: bool = True,
    output_stream: BinaryIO | None = None,
) -> int:
    command = command_override or config.command
    if not command:
        raise RuntimeError("项目未配置启动命令")
    spool = spool or Spool()
    output_stream = output_stream or sys.stdout.buffer
    local_run_key = uuid4().hex
    working_dir = config.resolved_working_directory(project_dir)
    spool.create_run(
        local_run_key=local_run_key,
        config=config,
        project_dir=project_dir,
        project_fingerprint=project_fingerprint(project_dir),
        git_metadata=git_metadata(project_dir),
        environment_metadata=environment_metadata(),
        started_at=utc_now(),
    )
    if start_daemon:
        try:
            ensure_daemon_running()
        except Exception as error:  # Reporter failure must not block the script.
            print(f"[ShopOps Reporter] 后台服务启动失败，将保留本地队列: {error}", file=sys.stderr)

    try:
        process = subprocess.Popen(
            command,
            cwd=working_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            bufsize=0,
        )
    except OSError as error:
        message = f"原脚本启动失败: {error}"
        print(message, file=sys.stderr)
        spool.append_log(
            local_run_key,
            timestamp=utc_now(),
            stream="stderr",
            level="error",
            message=message,
        )
        spool.finish_run(
            local_run_key,
            status="failed",
            exit_code=127,
            ended_at=utc_now(),
            result={"reporter_warning": message},
        )
        return 127

    def forward(source, target, stream: str) -> None:
        assert source is not None
        while chunk := source.readline():
            target.write(chunk)
            target.flush()
            text = chunk.decode("utf-8", errors="replace").rstrip("\r\n")
            if not text:
                continue
            for offset in range(0, len(text), 50_000):
                spool.append_log(
                    local_run_key,
                    timestamp=utc_now(),
                    stream=stream,
                    level="warning" if stream == "stderr" else "info",
                    message=text[offset : offset + 50_000],
                )

    threads = [
        threading.Thread(
            target=forward,
            args=(process.stdout, output_stream, "stdout"),
            daemon=True,
        ),
        threading.Thread(
            target=forward,
            args=(process.stderr, sys.stderr.buffer, "stderr"),
            daemon=True,
        ),
    ]
    for thread in threads:
        thread.start()
    interrupted = False
    try:
        exit_code = process.wait()
    except KeyboardInterrupt:
        interrupted = True
        process.terminate()
        process.wait()
        exit_code = 130
    for thread in threads:
        thread.join(timeout=5)

    html_files = matching_files(project_dir, config.html_reports)
    report_path = html_files[0] if html_files else None
    spool.finish_run(
        local_run_key,
        status="cancelled" if interrupted else "success" if exit_code == 0 else "failed",
        exit_code=exit_code,
        ended_at=utc_now(),
        result=read_result(config, project_dir),
        live_report_token=new_report_token() if report_path else None,
        live_report_path=report_path,
    )
    return exit_code
