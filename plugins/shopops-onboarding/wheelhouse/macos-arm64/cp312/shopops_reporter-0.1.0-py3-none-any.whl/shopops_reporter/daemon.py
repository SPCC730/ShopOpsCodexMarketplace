from __future__ import annotations

import json
import os
import signal
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from shopops_reporter.client import ReporterApiError, ReporterClient
from shopops_reporter.config import IdentityStore, ProjectConfig, ensure_private_directory, reporter_home
from shopops_reporter.html_server import ReportServer
from shopops_reporter.project import artifact_digest, artifact_key, artifact_type, matching_files
from shopops_reporter.spool import Spool


DEFAULT_REPORT_PORT = 18765


def daemon_pid_path() -> Path:
    return reporter_home() / "reporter.pid"


def daemon_log_path() -> Path:
    return reporter_home() / "reporter.log"


def report_port() -> int:
    return int(os.environ.get("SHOPOPS_REPORTER_PORT", DEFAULT_REPORT_PORT))


def process_running(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def current_daemon_pid() -> int | None:
    path = daemon_pid_path()
    if not path.exists():
        return None
    try:
        pid = int(path.read_text(encoding="ascii").strip())
    except (OSError, ValueError):
        path.unlink(missing_ok=True)
        return None
    if not process_running(pid):
        path.unlink(missing_ok=True)
        return None
    return pid


def ensure_daemon_running() -> int:
    existing = current_daemon_pid()
    if existing:
        return existing
    home = ensure_private_directory(reporter_home())
    log = (home / "reporter.log").open("ab", buffering=0)
    kwargs: dict[str, Any] = {
        "stdin": subprocess.DEVNULL,
        "stdout": log,
        "stderr": log,
        "cwd": str(home),
    }
    if os.name == "nt":
        kwargs["creationflags"] = (
            subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
        )
    else:
        kwargs["start_new_session"] = True
    process = subprocess.Popen(
        [sys.executable, "-m", "shopops_reporter", "serve"],
        **kwargs,
    )
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        pid = current_daemon_pid()
        if pid:
            return pid
        if process.poll() is not None:
            break
        time.sleep(0.1)
    raise RuntimeError(f"Reporter 后台服务未能启动，请查看 {daemon_log_path()}")


def stop_daemon() -> bool:
    pid = current_daemon_pid()
    if not pid:
        return False
    try:
        os.kill(pid, signal.SIGTERM)
    except OSError:
        daemon_pid_path().unlink(missing_ok=True)
        return False
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline and process_running(pid):
        time.sleep(0.1)
    daemon_pid_path().unlink(missing_ok=True)
    return True


class Uploader:
    def __init__(self, spool: Spool | None = None, client: ReporterClient | None = None):
        self.spool = spool or Spool()
        self.client = client or ReporterClient(IdentityStore().load())
        self.last_device_ping = 0.0
        self.last_device_error: str | None = None

    def process_once(self) -> int:
        self._ping_device_if_due()
        processed = 0
        for run in self.spool.pending_runs():
            try:
                self._process_run(run)
                processed += 1
            except Exception as error:
                self.spool.record_error(run["local_run_key"], error)
        return processed

    def _ping_device_if_due(self) -> None:
        now = time.monotonic()
        if now - self.last_device_ping < 30:
            return
        try:
            self.client.signed_get("/reporter/v1/devices/self")
            self.last_device_error = None
        except Exception as error:
            self.last_device_error = str(error)
        finally:
            self.last_device_ping = now

    def _process_run(self, run: dict[str, Any]) -> None:
        local_key = run["local_run_key"]
        server_run_id = run["server_run_id"]
        if not server_run_id:
            started = self.client.signed_json(
                "POST",
                "/reporter/v1/runs/start",
                {
                    "integration_id": run["integration_id"],
                    "external_run_key": local_key,
                    "project_fingerprint": run["project_fingerprint"],
                    "git_metadata": json.loads(run["git_json"]),
                    "environment_metadata": json.loads(run["environment_json"]),
                    "started_at": run["started_at"],
                    "inputs": {},
                },
            )
            server_run_id = str(started["run_id"])
            self.spool.set_server_run(local_key, server_run_id)
            run = self.spool.get_run(local_key) or run

        after = int(run["last_uploaded_sequence"])
        for _ in range(10):
            records = self.spool.log_batch(local_key, after)
            if not records:
                break
            response = self.client.signed_json(
                "POST",
                f"/reporter/v1/runs/{server_run_id}/logs:batch",
                {"records": records},
            )
            after = int(response["last_log_sequence"])
            self.spool.acknowledge_logs(local_key, after)
            if len(records) < 100:
                break

        run = self.spool.get_run(local_key) or run
        if run["local_status"] == "running":
            last_heartbeat = float(run["last_heartbeat_at"] or 0)
            if time.time() - last_heartbeat >= 15:
                self.client.signed_json(
                    "POST",
                    f"/reporter/v1/runs/{server_run_id}/heartbeat",
                    {
                        "environment_metadata": json.loads(run["environment_json"]),
                        "queue_summary": self.spool.queue_summary(),
                    },
                )
                self.spool.heartbeat_sent(local_key)
            return

        if self.spool.log_batch(local_key, after, limit=1):
            return
        self._prepare_and_upload_artifacts(run, server_run_id)
        run = self.spool.get_run(local_key) or run
        if run.get("logs_partial"):
            completeness = "logs_partial"
        elif self.spool.artifact_incomplete(local_key):
            completeness = "artifacts_partial"
        else:
            completeness = "complete"
        self.client.signed_json(
            "POST",
            f"/reporter/v1/runs/{server_run_id}/complete",
            {
                "status": run["local_status"],
                "exit_code": int(run["exit_code"]),
                "ended_at": run["ended_at"],
                "result": json.loads(run["result_json"]),
                "report_completeness": completeness,
                "live_report_url": self._live_report_url(run),
            },
        )
        self.spool.complete_upload(local_key)

    def _prepare_and_upload_artifacts(self, run: dict[str, Any], server_run_id: str) -> None:
        config = ProjectConfig(**json.loads(run["config_json"]))
        project_dir = Path(run["project_dir"])
        for path in matching_files(project_dir, config.artifacts):
            kind = artifact_type(path)
            if not kind:
                continue
            self.spool.add_artifact(
                run["local_run_key"],
                artifact_key=artifact_key(path, project_dir),
                path=path,
                artifact_type=kind,
                sha256=artifact_digest(path),
            )
        for artifact in self.spool.pending_artifacts(run["local_run_key"]):
            path = Path(artifact["path"])
            if not path.is_file() or artifact_digest(path) != artifact["sha256"]:
                self.spool.artifact_finished(
                    run["local_run_key"],
                    artifact["artifact_key"],
                    accepted=False,
                    error="附件在运行结束后发生变化或已不存在",
                )
                continue
            try:
                self.client.upload_artifact(
                    run_id=server_run_id,
                    artifact_key=artifact["artifact_key"],
                    path=path,
                    artifact_type=artifact["artifact_type"],
                )
            except ReporterApiError as error:
                if 400 <= error.status_code < 500 and error.status_code not in {408, 429}:
                    self.spool.artifact_finished(
                        run["local_run_key"],
                        artifact["artifact_key"],
                        accepted=False,
                        error=str(error),
                    )
                    continue
                raise
            self.spool.artifact_finished(
                run["local_run_key"],
                artifact["artifact_key"],
                accepted=True,
            )

    def _live_report_url(self, run: dict[str, Any]) -> str | None:
        token = run.get("live_report_token")
        path = run.get("live_report_path")
        if not token or not path or not Path(path).is_file():
            return None
        return f"http://{local_ipv4(self.client.identity.server_url)}:{report_port()}/reports/{token}/"


def local_ipv4(server_url: str) -> str:
    host = urlsplit(server_url).hostname or "127.0.0.1"
    port = urlsplit(server_url).port or 80
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect((host, port))
        address = sock.getsockname()[0]
    except OSError:
        address = socket.gethostbyname(socket.gethostname())
    finally:
        sock.close()
    return address


def serve(*, once: bool = False) -> int:
    ensure_private_directory(reporter_home())
    pid_path = daemon_pid_path()
    existing = current_daemon_pid()
    if existing and existing != os.getpid():
        raise RuntimeError(f"Reporter 已在运行，PID {existing}")
    pid_path.write_text(str(os.getpid()), encoding="ascii")
    uploader = Uploader()
    if once:
        try:
            return uploader.process_once()
        finally:
            pid_path.unlink(missing_ok=True)

    stopped = threading.Event()

    def request_stop(_signum: int, _frame: object) -> None:
        stopped.set()

    signal.signal(signal.SIGTERM, request_stop)
    if hasattr(signal, "SIGINT"):
        signal.signal(signal.SIGINT, request_stop)

    report_server: ReportServer | None = None
    try:
        report_server = ReportServer(("0.0.0.0", report_port()), uploader.spool)
        threading.Thread(target=report_server.serve_forever, daemon=True).start()
    except OSError as error:
        print(f"[ShopOps Reporter] HTML 服务未启动: {error}", file=sys.stderr)

    try:
        while not stopped.is_set():
            try:
                uploader.process_once()
            except Exception as error:
                print(f"[ShopOps Reporter] 后台循环异常: {error}", file=sys.stderr)
            stopped.wait(0.5)
    finally:
        if report_server:
            report_server.shutdown()
            report_server.server_close()
        pid_path.unlink(missing_ok=True)
    return 0
