from __future__ import annotations

import json
from typing import Any


CLI_SCHEMA = "shopops.reporter.cli.v1"


def emit_success(action: str, data: dict[str, Any]) -> None:
    print(
        json.dumps(
            {"schema": CLI_SCHEMA, "ok": True, "action": action, "data": data},
            ensure_ascii=False,
        )
    )


def emit_error(action: str | None, code: str, message: str) -> None:
    print(
        json.dumps(
            {
                "schema": CLI_SCHEMA,
                "ok": False,
                "action": action,
                "error": {"code": code, "message": message},
            },
            ensure_ascii=False,
        )
    )
